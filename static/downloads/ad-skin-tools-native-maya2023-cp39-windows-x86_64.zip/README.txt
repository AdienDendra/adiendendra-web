AD Skin Tools 1.0 - Customer Installation
==========================================

Compatibility
-------------
Use only the archive whose filename matches your Maya release, operating
system, and CPU architecture. Each archive contains a different native Python
runtime and is not interchangeable with another target.

Do not merge or overwrite several Maya-target archives into one shared
ad_skin_tools directory. If you use more than one Maya release, keep every
target installation separate and follow the target-specific path instructions
published with the final release.

Installation
------------
1. Extract the complete ZIP. Do not move only selected files.
2. In Maya's Python Script Editor, run:

       import maya.cmds as cmds
       print(cmds.internalVar(userScriptDir=True))

3. Copy every extracted item into that user scripts directory. The
   ad_skin_tools directory must remain intact. Maya 2023 packages also include
   a top-level NumPy runtime; keep it beside ad_skin_tools.
4. Restart Maya.
5. In Maya's Python Script Editor, run:

       import ad_skin_tools.launch as ad_skin_tools
       ad_skin_tools.show(reload=False, auto_refresh=False)

Licensing
---------
The 48-hour full-featured trial starts only when you click Start 48-Hour
Trial. A paid perpetual individual license supports at most two active
devices. Online validation normally occurs every seven days, with a hard
offline limit of 30 days after the last successful paid validation.

Refund policy
-------------
All sales are final. AD Skin Tools does not provide refunds for change of
mind, project completion, no longer needing the software, or failure to
evaluate the product during the available 48-hour trial. This does not affect
rights that cannot legally be excluded.

Troubleshooting
---------------
If import or launch fails, confirm that the archive matches the exact Maya,
OS, and CPU target and that all extracted items were copied together. Retain
your original ZIP and purchase receipt when requesting seller support.
