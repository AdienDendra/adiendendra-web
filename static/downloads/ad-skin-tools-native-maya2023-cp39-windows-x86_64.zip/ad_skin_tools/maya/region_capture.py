"""Capture Maya scene data required by Region ownership solving."""

import time
from typing import Sequence, Tuple

import maya.api.OpenMaya as om
import maya.cmds as cmds
import numpy as np

from ad_skin_tools.region.data import (
    ClosedLoopCapture,
    MeshOwnershipContext,
    SecondarySurfaceCapture,
)


def build_mesh_ownership_context(
    mesh: str,
    joints: Sequence[str],
) -> MeshOwnershipContext:
    """Capture positions and direct vertex adjacency exactly once."""

    started = time.perf_counter()
    mesh_shape, mesh_transform = _resolve_mesh(mesh)
    influences = _normalize_joint_paths(joints)
    if len(influences) < 2:
        raise RuntimeError("Ownership solving requires at least two joints.")

    selection = om.MSelectionList()
    selection.add(mesh_shape)
    dag_path = selection.getDagPath(0)
    mesh_fn = om.MFnMesh(dag_path)

    capture_started = time.perf_counter()
    points = mesh_fn.getPoints(om.MSpace.kWorld)
    vertex_positions = np.empty((len(points), 3), dtype=np.float64)
    for index, point in enumerate(points):
        vertex_positions[index] = (point.x, point.y, point.z)

    influence_positions = np.empty((len(influences), 3), dtype=np.float64)
    influence_uuids = []
    for index, joint in enumerate(influences):
        influence_positions[index] = cmds.xform(
            joint,
            query=True,
            worldSpace=True,
            translation=True,
        )
        uuid_matches = cmds.ls(joint, uuid=True) or []
        if len(uuid_matches) != 1:
            raise RuntimeError(
                "Unable to resolve one stable Maya UUID for joint:\n{}".format(joint)
            )
        influence_uuids.append(str(uuid_matches[0]))
    scene_capture_seconds = time.perf_counter() - capture_started

    adjacency_started = time.perf_counter()
    adjacency_sets = [set() for _ in range(int(mesh_fn.numVertices))]
    edge_iterator = om.MItMeshEdge(dag_path)
    while not edge_iterator.isDone():
        first = int(edge_iterator.vertexId(0))
        second = int(edge_iterator.vertexId(1))
        adjacency_sets[first].add(second)
        adjacency_sets[second].add(first)
        edge_iterator.next()
    adjacency = tuple(
        tuple(sorted(int(value) for value in neighbours))
        for neighbours in adjacency_sets
    )
    adjacency_seconds = time.perf_counter() - adjacency_started

    return MeshOwnershipContext(
        mesh_shape=mesh_shape,
        mesh_transform=mesh_transform,
        influences=influences,
        influence_uuids=tuple(influence_uuids),
        vertex_positions=vertex_positions,
        influence_positions=influence_positions,
        adjacency=adjacency,
        face_count=int(mesh_fn.numPolygons),
        edge_count=int(mesh_fn.numEdges),
        scene_capture_seconds=float(scene_capture_seconds),
        adjacency_seconds=float(adjacency_seconds),
        elapsed_seconds=float(time.perf_counter() - started),
    )


def capture_secondary_surface_data(
    context: MeshOwnershipContext,
    anchor_vertex_ids: Sequence[int],
) -> SecondarySurfaceCapture:
    """Capture incident faces and world normals for exact anchor vertices."""

    anchor_ids = tuple(sorted(int(value) for value in anchor_vertex_ids))
    anchor_started = time.perf_counter()
    selection = om.MSelectionList()
    selection.add(context.mesh_shape)
    dag_path = selection.getDagPath(0)
    mesh_fn = om.MFnMesh(dag_path)

    incident_faces = {}
    iterator = om.MItMeshVertex(dag_path)
    for vertex_id in anchor_ids:
        iterator.setIndex(int(vertex_id))
        incident_faces[int(vertex_id)] = tuple(
            sorted(int(face_id) for face_id in iterator.getConnectedFaces())
        )
    anchor_query_seconds = time.perf_counter() - anchor_started

    unique_face_ids = tuple(
        sorted(
            {
                face_id
                for face_ids in incident_faces.values()
                for face_id in face_ids
            }
        )
    )
    normal_started = time.perf_counter()
    face_normals = {}
    for face_id in unique_face_ids:
        value = mesh_fn.getPolygonNormal(int(face_id), om.MSpace.kWorld)
        face_normals[int(face_id)] = np.asarray(
            (value.x, value.y, value.z),
            dtype=np.float64,
        )
    normal_query_seconds = time.perf_counter() - normal_started

    return SecondarySurfaceCapture(
        anchor_vertex_ids=anchor_ids,
        incident_face_ids=incident_faces,
        queried_face_ids=unique_face_ids,
        face_normals=face_normals,
        anchor_query_seconds=float(anchor_query_seconds),
        normal_query_seconds=float(normal_query_seconds),
    )


def capture_closed_loop_data(
    context: MeshOwnershipContext,
    owner_indices: np.ndarray,
) -> ClosedLoopCapture:
    """Capture only edge loops reached from ownership-boundary edges."""

    owners = np.asarray(owner_indices, dtype=np.int32)
    edge_scan_started = time.perf_counter()
    edge_endpoints, boundary_edge_ids = _scan_edges(
        context.mesh_shape,
        owners,
    )
    edge_scan_seconds = time.perf_counter() - edge_scan_started

    loop_query_started = time.perf_counter()
    discovered, unresolved, open_seeds, polyselect_calls = _discover_relevant_loops(
        mesh_transform=context.mesh_transform,
        boundary_edge_ids=boundary_edge_ids,
        edge_endpoints=edge_endpoints,
    )
    loop_query_seconds = time.perf_counter() - loop_query_started

    return ClosedLoopCapture(
        discovered_loops=discovered,
        boundary_edge_ids=boundary_edge_ids,
        unresolved_seed_edge_ids=tuple(sorted(unresolved)),
        open_loop_seed_edge_ids=tuple(sorted(open_seeds)),
        edge_scan_seconds=float(edge_scan_seconds),
        loop_query_seconds=float(loop_query_seconds),
        maya_polyselect_call_count=int(polyselect_calls),
    )


def _scan_edges(mesh_shape, owners):
    selection = om.MSelectionList()
    selection.add(mesh_shape)
    dag_path = selection.getDagPath(0)
    mesh_fn = om.MFnMesh(dag_path)
    endpoints = [None] * int(mesh_fn.numEdges)
    boundary = []

    iterator = om.MItMeshEdge(dag_path)
    while not iterator.isDone():
        edge_id = int(iterator.index())
        first = int(iterator.vertexId(0))
        second = int(iterator.vertexId(1))
        endpoints[edge_id] = (first, second)
        if int(owners[first]) != int(owners[second]):
            boundary.append(edge_id)
        iterator.next()

    if any(value is None for value in endpoints):
        raise RuntimeError("Failed to capture every mesh edge endpoint.")
    return tuple(endpoints), tuple(boundary)


def _discover_relevant_loops(
    mesh_transform,
    boundary_edge_ids,
    edge_endpoints,
):
    pending = set(int(value) for value in boundary_edge_ids)
    seen_loop_keys = set()
    discovered = []
    unresolved = []
    open_seeds = []
    calls = 0

    while pending:
        seed = min(pending)
        calls += 1
        raw_ids = cmds.polySelect(
            mesh_transform,
            edgeLoop=int(seed),
            noSelection=True,
        ) or []
        unique_ids = tuple(sorted({int(value) for value in raw_ids}))
        if not unique_ids or seed not in unique_ids:
            unresolved.append(seed)
            pending.remove(seed)
            continue

        pending.difference_update(unique_ids)
        if unique_ids in seen_loop_keys:
            continue
        seen_loop_keys.add(unique_ids)

        vertex_ids = _simple_closed_loop_vertices(unique_ids, edge_endpoints)
        if not vertex_ids:
            open_seeds.append(seed)
            continue
        discovered.append((int(seed), unique_ids, vertex_ids))

    discovered.sort(key=lambda value: value[1])
    return tuple(discovered), tuple(unresolved), tuple(open_seeds), calls


def _simple_closed_loop_vertices(edge_ids, edge_endpoints):
    neighbours = {}
    for edge_id in edge_ids:
        first, second = edge_endpoints[int(edge_id)]
        neighbours.setdefault(first, set()).add(second)
        neighbours.setdefault(second, set()).add(first)

    if not neighbours or any(len(values) != 2 for values in neighbours.values()):
        return tuple()
    if len(edge_ids) != len(neighbours):
        return tuple()

    unseen = set(neighbours)
    stack = [min(unseen)]
    unseen.remove(stack[0])
    while stack:
        vertex_id = stack.pop()
        for neighbour_id in neighbours[vertex_id]:
            if neighbour_id in unseen:
                unseen.remove(neighbour_id)
                stack.append(neighbour_id)
    if unseen:
        return tuple()
    return tuple(sorted(int(value) for value in neighbours))


def _resolve_mesh(mesh: str) -> Tuple[str, str]:
    if not mesh:
        raise RuntimeError("No mesh was supplied.")

    matches = cmds.ls(mesh, long=True) or []
    if not matches:
        raise RuntimeError("Mesh does not exist:\n{}".format(mesh))

    node = matches[0]
    node_type = cmds.nodeType(node)
    if node_type == "mesh":
        parents = cmds.listRelatives(
            node,
            parent=True,
            fullPath=True,
        ) or []
        if not parents:
            raise RuntimeError("Mesh shape has no transform parent:\n{}".format(node))
        return node, parents[0]

    if node_type != "transform":
        raise RuntimeError(
            "Node is not a polygon mesh or mesh transform:\n{}".format(node)
        )

    shapes = cmds.listRelatives(
        node,
        shapes=True,
        noIntermediate=True,
        fullPath=True,
        type="mesh",
    ) or []
    if len(shapes) != 1:
        raise RuntimeError(
            "Geometry transform must contain exactly one non-intermediate mesh.\n\n"
            "Transform: {}\nMesh shapes: {}".format(node, len(shapes))
        )
    return shapes[0], node


def _normalize_joint_paths(joints: Sequence[str]) -> Tuple[str, ...]:
    result = []
    seen = set()
    for joint in joints:
        matches = cmds.ls(joint, long=True, type="joint") or []
        if not matches:
            raise RuntimeError("Joint does not exist:\n{}".format(joint))
        path = matches[0]
        if path in seen:
            continue
        seen.add(path)
        result.append(path)
    return tuple(result)
