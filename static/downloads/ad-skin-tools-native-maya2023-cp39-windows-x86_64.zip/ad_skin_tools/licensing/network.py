"""Small HTTPS JSON client for the Maya licensing API."""

from __future__ import annotations

import json
import socket
from typing import Any, Dict, Mapping, Optional
from urllib import error, request


MAX_REQUEST_BYTES = 8 * 1024
MAX_RESPONSE_BYTES = 16 * 1024
DEFAULT_TIMEOUT_SECONDS = 8


class LicensingApiError(Exception):
    """Base safe client error."""

    code = "LICENSING_SERVICE_ERROR"
    safe_message = "The licensing service is temporarily unavailable."


class LicensingServiceUnavailableError(LicensingApiError):
    """Raised for network, dependency, or malformed service responses."""


class LicensingRequestRejectedError(LicensingApiError):
    """A structured HTTP rejection safe to display without request data."""

    def __init__(self, code: str, safe_message: str, status_code: int) -> None:
        super().__init__(safe_message)
        self.code = code
        self.safe_message = safe_message
        self.status_code = status_code

    def __str__(self) -> str:
        return self.safe_message


class LicensingApiClient:
    """POST JSON over HTTPS with a fixed timeout and bounded responses."""

    def __init__(
        self,
        api_base_url: str,
        *,
        timeout_seconds: int = DEFAULT_TIMEOUT_SECONDS,
        opener: Optional[Any] = None,
    ) -> None:
        if not isinstance(api_base_url, str) or not api_base_url.startswith(
            "https://"
        ):
            raise ValueError("A secure licensing API URL is required.")
        if not isinstance(timeout_seconds, int) or timeout_seconds <= 0:
            raise ValueError("The licensing timeout must be positive.")
        self._base_url = api_base_url.rstrip("/")
        self._timeout = timeout_seconds
        self._opener = opener or request.urlopen

    def post(self, path: str, payload: Mapping[str, Any]) -> Dict[str, Any]:
        try:
            body = json.dumps(
                dict(payload),
                separators=(",", ":"),
                sort_keys=True,
            ).encode("utf-8")
        except (TypeError, ValueError) as exc:
            raise ValueError("The licensing request is invalid.") from exc
        if not body or len(body) > MAX_REQUEST_BYTES:
            raise ValueError("The licensing request is too large.")

        return self._request_json("POST", path, body)

    def get(self, path: str) -> Dict[str, Any]:
        """GET one bounded public API document."""

        return self._request_json("GET", path, None)

    def _request_json(
        self,
        method: str,
        path: str,
        body: Optional[bytes],
    ) -> Dict[str, Any]:
        if not isinstance(path, str) or not path.startswith("/v1/"):
            raise ValueError("The licensing route is invalid.")

        headers = {"Accept": "application/json"}
        if body is not None:
            headers["Content-Type"] = "application/json"

        http_request = request.Request(
            self._base_url + path,
            data=body,
            headers=headers,
            method=method,
        )

        try:
            response = self._opener(http_request, timeout=self._timeout)
            with response:
                status_code = int(response.getcode())
                raw_response = _bounded_read(response)
        except error.HTTPError as exc:
            _raise_http_error(exc)
        except (error.URLError, socket.timeout, TimeoutError, OSError) as exc:
            raise LicensingServiceUnavailableError() from exc
        except LicensingApiError:
            raise
        except Exception as exc:
            raise LicensingServiceUnavailableError() from exc

        if status_code != 200:
            raise LicensingServiceUnavailableError()
        return _decode_json_object(raw_response)


def _raise_http_error(exc: error.HTTPError) -> None:
    try:
        raw_response = _bounded_read(exc)
        value = _decode_json_object(raw_response)
        error_value = value.get("error")
        if not isinstance(error_value, Mapping):
            raise LicensingServiceUnavailableError()
        code = error_value.get("code")
        message = error_value.get("message")
        if (
            not isinstance(code, str)
            or not code
            or len(code) > 80
            or not isinstance(message, str)
            or not message
            or len(message) > 300
        ):
            raise LicensingServiceUnavailableError()
    except LicensingApiError:
        raise
    except Exception as parse_error:
        raise LicensingServiceUnavailableError() from parse_error

    status_code = int(exc.code)
    if status_code in {408, 425, 429}:
        raise LicensingServiceUnavailableError()
    if 400 <= status_code < 500:
        raise LicensingRequestRejectedError(code, message, status_code)
    raise LicensingServiceUnavailableError()


def _bounded_read(response: Any) -> bytes:
    value = response.read(MAX_RESPONSE_BYTES + 1)
    if not isinstance(value, bytes) or len(value) > MAX_RESPONSE_BYTES:
        raise LicensingServiceUnavailableError()
    return value


def _decode_json_object(value: bytes) -> Dict[str, Any]:
    try:
        decoded = json.loads(value.decode("utf-8"))
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise LicensingServiceUnavailableError() from exc
    if not isinstance(decoded, dict):
        raise LicensingServiceUnavailableError()
    return decoded
