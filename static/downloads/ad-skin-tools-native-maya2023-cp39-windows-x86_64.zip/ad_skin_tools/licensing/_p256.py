"""Small verify-only implementation for KMS P-256 signatures."""

from __future__ import annotations

import hashlib
from typing import Optional, Tuple


_P = 0xFFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFF
_A = _P - 3
_B = 0x5AC635D8AA3A93E7B3EBBD55769886BC651D06B0CC53B0F63BCE3C3E27D2604B
_N = 0xFFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551
_G = (
    0x6B17D1F2E12C4247F8BCE6E563A440F277037D812DEB33A0F4A13945D898C296,
    0x4FE342E2FE1A7F9B8EE7EB4A7C0F9E162BCE33576B315ECECBB6406837BF51F5,
)
_SPKI_PREFIX = bytes.fromhex(
    "3059301306072a8648ce3d020106082a8648ce3d03010703420004"
)

Point = Optional[Tuple[int, int]]


def verify_p256_sha256(
    public_key_der: bytes,
    message: bytes,
    signature_der: bytes,
) -> bool:
    """Verify one DER ECDSA signature using an SPKI P-256 public key."""

    try:
        public_point = _decode_public_point(public_key_der)
        r, s = _decode_signature(signature_der)
    except ValueError:
        return False

    digest = hashlib.sha256(message).digest()
    z = int.from_bytes(digest, "big")
    inverse = pow(s, _N - 2, _N)
    point = _point_add(
        _scalar_multiply((z * inverse) % _N, _G),
        _scalar_multiply((r * inverse) % _N, public_point),
    )

    return point is not None and point[0] % _N == r


def validate_p256_public_key_der(public_key_der: bytes) -> None:
    """Fail when bytes are not one valid P-256 SubjectPublicKeyInfo key."""

    _decode_public_point(public_key_der)


def _decode_public_point(public_key_der: bytes) -> tuple[int, int]:
    if (
        not isinstance(public_key_der, bytes)
        or len(public_key_der) != len(_SPKI_PREFIX) + 64
        or not public_key_der.startswith(_SPKI_PREFIX)
    ):
        raise ValueError("invalid P-256 public key")

    point_bytes = public_key_der[len(_SPKI_PREFIX) :]
    point = (
        int.from_bytes(point_bytes[:32], "big"),
        int.from_bytes(point_bytes[32:], "big"),
    )

    if not _point_is_valid(point):
        raise ValueError("invalid P-256 public point")

    return point


def _decode_signature(signature_der: bytes) -> tuple[int, int]:
    if (
        not isinstance(signature_der, bytes)
        or len(signature_der) < 8
        or len(signature_der) > 72
        or signature_der[0] != 0x30
        or signature_der[1] != len(signature_der) - 2
    ):
        raise ValueError("invalid ECDSA sequence")

    r, offset = _decode_integer(signature_der, 2)
    s, offset = _decode_integer(signature_der, offset)

    if offset != len(signature_der) or not (1 <= r < _N and 1 <= s < _N):
        raise ValueError("invalid ECDSA values")

    return r, s


def _decode_integer(value: bytes, offset: int) -> tuple[int, int]:
    if offset + 2 > len(value) or value[offset] != 0x02:
        raise ValueError("invalid DER integer")

    length = value[offset + 1]
    start = offset + 2
    end = start + length

    if length < 1 or length > 33 or end > len(value):
        raise ValueError("invalid DER integer length")

    integer = value[start:end]

    if integer[0] & 0x80:
        raise ValueError("negative DER integer")

    if (
        length > 1
        and integer[0] == 0
        and not integer[1] & 0x80
    ):
        raise ValueError("non-minimal DER integer")

    return int.from_bytes(integer, "big"), end


def _point_is_valid(point: tuple[int, int]) -> bool:
    x, y = point
    return (
        0 <= x < _P
        and 0 <= y < _P
        and (y * y - (x * x * x + _A * x + _B)) % _P == 0
    )


def _point_add(left: Point, right: Point) -> Point:
    if left is None:
        return right

    if right is None:
        return left

    x1, y1 = left
    x2, y2 = right

    if x1 == x2 and (y1 + y2) % _P == 0:
        return None

    if left == right:
        slope = (3 * x1 * x1 + _A) * pow(2 * y1, _P - 2, _P)
    else:
        slope = (y2 - y1) * pow(x2 - x1, _P - 2, _P)

    slope %= _P
    x3 = (slope * slope - x1 - x2) % _P
    y3 = (slope * (x1 - x3) - y1) % _P
    return x3, y3


def _scalar_multiply(scalar: int, point: Point) -> Point:
    result: Point = None
    addend = point

    while scalar:
        if scalar & 1:
            result = _point_add(result, addend)

        addend = _point_add(addend, addend)
        scalar >>= 1

    return result
