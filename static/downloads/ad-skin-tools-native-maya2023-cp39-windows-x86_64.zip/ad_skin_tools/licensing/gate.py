"""One fail-closed policy boundary for every protected Maya action."""

from __future__ import annotations

from dataclasses import dataclass
from functools import wraps
from typing import Callable, Optional


BIND_SKIN = "BIND_SKIN"
ADD_INFLUENCE = "ADD_INFLUENCE"
FLOOD = "FLOOD"
SMOOTH = "SMOOTH"
SKIN_WEIGHT_VISUAL = "SKIN_WEIGHT_VISUAL"
MIRROR_PREVIEW = "MIRROR_PREVIEW"
MIRROR_REGISTER = "MIRROR_REGISTER"
MIRROR_APPLY = "MIRROR_APPLY"
TRANSFER_PREVIEW = "TRANSFER_PREVIEW"
TRANSFER_APPLY = "TRANSFER_APPLY"

PROTECTED_ACTIONS = (
    BIND_SKIN,
    ADD_INFLUENCE,
    FLOOD,
    SMOOTH,
    SKIN_WEIGHT_VISUAL,
    MIRROR_PREVIEW,
    MIRROR_REGISTER,
    MIRROR_APPLY,
    TRANSFER_PREVIEW,
    TRANSFER_APPLY,
)


@dataclass(frozen=True)
class GateDecision:
    allowed: bool
    state: str
    message: str
    request_validation: bool = False


_AUTHORIZER = None  # type: Optional[Callable[[str], GateDecision]]
_DENIED_CALLBACK = None  # type: Optional[Callable[[str, GateDecision], None]]


def configure(
    authorizer: Callable[[str], GateDecision],
    denied_callback: Callable[[str, GateDecision], None],
) -> None:
    if not callable(authorizer) or not callable(denied_callback):
        raise TypeError("Licensing gate callbacks must be callable.")
    global _AUTHORIZER, _DENIED_CALLBACK
    _AUTHORIZER = authorizer
    _DENIED_CALLBACK = denied_callback


def reset() -> None:
    global _AUTHORIZER, _DENIED_CALLBACK
    _AUTHORIZER = None
    _DENIED_CALLBACK = None


def require(action: str) -> bool:
    """Authorize one protected action and notify the UI on denial."""

    if action not in PROTECTED_ACTIONS:
        raise ValueError("Unknown protected action.")
    if _AUTHORIZER is None:
        decision = GateDecision(
            allowed=False,
            state="CONFIGURATION_ERROR",
            message="License checking is not ready.",
        )
    else:
        decision = _AUTHORIZER(action)
        if not isinstance(decision, GateDecision):
            decision = GateDecision(
                allowed=False,
                state="CONFIGURATION_ERROR",
                message="License checking is not ready.",
            )

    if decision.allowed:
        return True
    if _DENIED_CALLBACK is not None:
        _DENIED_CALLBACK(action, decision)
    return False


def protected(action: str):
    """Decorate a Maya entry point without duplicating policy logic."""

    if action not in PROTECTED_ACTIONS:
        raise ValueError("Unknown protected action.")

    def decorator(function):
        @wraps(function)
        def guarded(*args, **kwargs):
            if not require(action):
                return None
            return function(*args, **kwargs)

        guarded.licensing_action = action
        return guarded

    return decorator
