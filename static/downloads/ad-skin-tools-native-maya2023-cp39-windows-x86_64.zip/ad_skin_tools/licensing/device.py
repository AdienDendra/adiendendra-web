"""Stable, pseudonymous device identity for licensing requests."""

from __future__ import annotations

import hashlib
from pathlib import Path
import re
import subprocess
from typing import Callable, Optional

from ad_skin_tools.runtime import platform as runtime_platform


FINGERPRINT_DOMAIN = b"AD_SKIN_TOOLS_DEVICE:1\x00"
_IO_PLATFORM_UUID = re.compile(
    r'"IOPlatformUUID"\s*=\s*"([^"]+)"',
    re.IGNORECASE,
)


class DeviceIdentityError(Exception):
    """Raised when a stable operating-system identity is unavailable."""


def device_fingerprint(
    *,
    operating_system: Optional[str] = None,
    identity_reader: Optional[Callable[[str], str]] = None,
) -> str:
    """Return a stable SHA-256 digest without exposing the raw identifier."""

    os_name = operating_system or runtime_platform.operating_system()
    reader = identity_reader or _read_platform_identity

    if os_name not in {
        runtime_platform.WINDOWS,
        runtime_platform.MACOS,
        runtime_platform.LINUX,
    }:
        raise DeviceIdentityError("This operating system is not supported.")

    raw_identity = reader(os_name)
    normalized = _normalize_identity(raw_identity)
    material = (
        FINGERPRINT_DOMAIN
        + os_name.encode("ascii")
        + b"\x00"
        + normalized.encode("utf-8")
    )
    return hashlib.sha256(material).hexdigest()


def _read_platform_identity(os_name: str) -> str:
    if os_name == runtime_platform.WINDOWS:
        return _read_windows_machine_guid()
    if os_name == runtime_platform.MACOS:
        return _read_macos_platform_uuid()
    if os_name == runtime_platform.LINUX:
        return _read_linux_machine_id()
    raise DeviceIdentityError("This operating system is not supported.")


def _read_windows_machine_guid() -> str:
    try:
        import winreg

        access = winreg.KEY_READ
        access |= getattr(winreg, "KEY_WOW64_64KEY", 0)
        with winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE,
            r"SOFTWARE\Microsoft\Cryptography",
            0,
            access,
        ) as key:
            value, _value_type = winreg.QueryValueEx(key, "MachineGuid")
    except Exception as exc:
        raise DeviceIdentityError(
            "The Windows device identity is unavailable."
        ) from exc
    return str(value)


def _read_macos_platform_uuid() -> str:
    try:
        completed = subprocess.run(
            ["/usr/sbin/ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=3,
        )
        output = completed.stdout.decode("utf-8", errors="strict")
        match = _IO_PLATFORM_UUID.search(output)
    except Exception as exc:
        raise DeviceIdentityError(
            "The macOS device identity is unavailable."
        ) from exc

    if match is None:
        raise DeviceIdentityError("The macOS device identity is unavailable.")
    return match.group(1)


def _read_linux_machine_id() -> str:
    for path in (Path("/etc/machine-id"), Path("/var/lib/dbus/machine-id")):
        try:
            value = path.read_text(encoding="utf-8")
        except (OSError, UnicodeError):
            continue
        if value.strip():
            return value
    raise DeviceIdentityError("The Linux device identity is unavailable.")


def _normalize_identity(value: object) -> str:
    if not isinstance(value, str):
        raise DeviceIdentityError("The device identity is invalid.")

    normalized = value.strip().casefold()
    if normalized.startswith("{") and normalized.endswith("}"):
        normalized = normalized[1:-1].strip()

    if (
        len(normalized) < 8
        or len(normalized) > 512
        or any(ord(character) < 32 for character in normalized)
    ):
        raise DeviceIdentityError("The device identity is invalid.")
    return normalized
