"""Strict, atomic local persistence for Maya licensing state."""

from __future__ import annotations

from dataclasses import dataclass
import json
import os
from pathlib import Path
import tempfile
from typing import Any, Dict, Mapping, Optional

from ad_skin_tools.runtime import platform as runtime_platform


SCHEMA_VERSION = 1
MAX_STATE_BYTES = 16 * 1024
MAX_LICENSE_KEY_CHARACTERS = 1024
_STATE_FIELDS = {
    "schema_version",
    "trial_entitlement",
    "paid_entitlement",
    "license_key",
    "last_seen_epoch",
    "validation_retry_not_before_epoch",
    "authoritative_status",
}
_AUTHORITATIVE_STATUSES = {
    "TRIAL_EXPIRED",
    "LICENSE_REVOKED",
    "LICENSE_UNKNOWN",
    "DEVICE_NOT_ACTIVE",
}


class LocalStateError(Exception):
    """Base local persistence error."""


class CorruptLocalStateError(LocalStateError):
    """Raised when the local state cannot be trusted."""


@dataclass
class LocalLicenseState:
    """Minimum state required for offline verification and device lifecycle."""

    trial_entitlement: Optional[Dict[str, str]] = None
    paid_entitlement: Optional[Dict[str, str]] = None
    license_key: Optional[str] = None
    last_seen_epoch: int = 0
    validation_retry_not_before_epoch: int = 0
    authoritative_status: Optional[str] = None

    def as_dict(self) -> Dict[str, Any]:
        return {
            "schema_version": SCHEMA_VERSION,
            "trial_entitlement": self.trial_entitlement,
            "paid_entitlement": self.paid_entitlement,
            "license_key": self.license_key,
            "last_seen_epoch": self.last_seen_epoch,
            "validation_retry_not_before_epoch": (
                self.validation_retry_not_before_epoch
            ),
            "authoritative_status": self.authoritative_status,
        }


class LocalStateStore:
    """Read and replace one private JSON state file."""

    def __init__(self, path: Optional[Path] = None) -> None:
        self.path = Path(path) if path is not None else default_state_path()

    def load(self) -> LocalLicenseState:
        try:
            size = self.path.stat().st_size
        except FileNotFoundError:
            return LocalLicenseState()
        except OSError as exc:
            raise CorruptLocalStateError() from exc

        if size <= 0 or size > MAX_STATE_BYTES:
            raise CorruptLocalStateError()

        try:
            raw = self.path.read_bytes()
            value = json.loads(raw.decode("utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError) as exc:
            raise CorruptLocalStateError() from exc

        return _parse_state(value)

    def save(self, state: LocalLicenseState) -> None:
        payload = json.dumps(
            _parse_state(state.as_dict()).as_dict(),
            separators=(",", ":"),
            sort_keys=True,
        ).encode("utf-8")
        if len(payload) > MAX_STATE_BYTES:
            raise LocalStateError("The local license state is too large.")

        directory = self.path.parent
        try:
            directory.mkdir(mode=0o700, parents=True, exist_ok=True)
            _restrict_permissions(directory, 0o700)
            descriptor, temporary_name = tempfile.mkstemp(
                prefix=".licensing-",
                suffix=".tmp",
                dir=str(directory),
            )
        except OSError as exc:
            raise LocalStateError(
                "The local license state could not be prepared."
            ) from exc

        temporary_path = Path(temporary_name)
        try:
            _restrict_descriptor(descriptor)
            with os.fdopen(descriptor, "wb") as handle:
                descriptor = -1
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(str(temporary_path), str(self.path))
            _restrict_permissions(self.path, 0o600)
            _sync_directory(directory)
        except OSError as exc:
            raise LocalStateError(
                "The local license state could not be saved."
            ) from exc
        finally:
            if descriptor >= 0:
                try:
                    os.close(descriptor)
                except OSError:
                    pass
            try:
                temporary_path.unlink()
            except FileNotFoundError:
                pass
            except OSError:
                pass

    def reset(self) -> None:
        try:
            self.path.unlink()
        except FileNotFoundError:
            return
        except OSError as exc:
            raise LocalStateError(
                "The local license state could not be reset."
            ) from exc


def default_state_path(
    *,
    operating_system: Optional[str] = None,
    environment: Optional[Mapping[str, str]] = None,
    home: Optional[Path] = None,
) -> Path:
    """Return the per-user state location without using Maya-version paths."""

    os_name = operating_system or runtime_platform.operating_system()
    values = environment if environment is not None else os.environ
    home_path = Path(home) if home is not None else Path.home()

    if os_name == runtime_platform.WINDOWS:
        base = values.get("LOCALAPPDATA")
        root = Path(base) if base else home_path / "AppData" / "Local"
        return root / "AD Skin Tools" / "licensing-state.json"
    if os_name == runtime_platform.MACOS:
        return (
            home_path
            / "Library"
            / "Application Support"
            / "AD Skin Tools"
            / "licensing-state.json"
        )
    if os_name == runtime_platform.LINUX:
        base = values.get("XDG_STATE_HOME")
        root = Path(base) if base else home_path / ".local" / "state"
        return root / "ad-skin-tools" / "licensing-state.json"
    raise LocalStateError("This operating system is not supported.")


def _parse_state(value: object) -> LocalLicenseState:
    if not isinstance(value, Mapping) or set(value) != _STATE_FIELDS:
        raise CorruptLocalStateError()
    if value.get("schema_version") != SCHEMA_VERSION:
        raise CorruptLocalStateError()

    trial = _parse_entitlement(value.get("trial_entitlement"))
    paid = _parse_entitlement(value.get("paid_entitlement"))
    license_key = value.get("license_key")
    if license_key is not None:
        if (
            not isinstance(license_key, str)
            or license_key != license_key.strip()
            or not license_key
            or len(license_key) > MAX_LICENSE_KEY_CHARACTERS
        ):
            raise CorruptLocalStateError()

    last_seen = _epoch(value.get("last_seen_epoch"))
    retry_at = _epoch(value.get("validation_retry_not_before_epoch"))
    authoritative_status = value.get("authoritative_status")
    if (
        authoritative_status is not None
        and authoritative_status not in _AUTHORITATIVE_STATUSES
    ):
        raise CorruptLocalStateError()
    if paid is not None and license_key is None:
        raise CorruptLocalStateError()

    return LocalLicenseState(
        trial_entitlement=trial,
        paid_entitlement=paid,
        license_key=license_key,
        last_seen_epoch=last_seen,
        validation_retry_not_before_epoch=retry_at,
        authoritative_status=authoritative_status,
    )


def _parse_entitlement(value: object) -> Optional[Dict[str, str]]:
    if value is None:
        return None
    if not isinstance(value, Mapping) or set(value) != {"payload", "signature"}:
        raise CorruptLocalStateError()
    payload = value.get("payload")
    signature = value.get("signature")
    if (
        not isinstance(payload, str)
        or not isinstance(signature, str)
        or not payload
        or not signature
        or len(payload) > 4096
        or len(signature) > 256
    ):
        raise CorruptLocalStateError()
    return {"payload": payload, "signature": signature}


def _epoch(value: object) -> int:
    if (
        not isinstance(value, int)
        or isinstance(value, bool)
        or value < 0
        or value > 2**63 - 1
    ):
        raise CorruptLocalStateError()
    return value


def _restrict_descriptor(descriptor: int) -> None:
    try:
        os.fchmod(descriptor, 0o600)
    except (AttributeError, OSError):
        pass


def _restrict_permissions(path: Path, mode: int) -> None:
    try:
        os.chmod(str(path), mode)
    except OSError:
        if os.name != "nt":
            raise


def _sync_directory(directory: Path) -> None:
    if os.name == "nt":
        return
    descriptor = -1
    try:
        descriptor = os.open(str(directory), os.O_RDONLY)
        os.fsync(descriptor)
    except OSError:
        pass
    finally:
        if descriptor >= 0:
            try:
                os.close(descriptor)
            except OSError:
                pass
