"""Local licensing state machine and proportional offline policy."""

from __future__ import annotations

from dataclasses import dataclass, replace
import threading
import time
from typing import Any, Callable, Dict, Mapping, Optional

from ad_skin_tools.licensing.device import DeviceIdentityError, device_fingerprint
from ad_skin_tools.licensing.entitlement import (
    ClockRollbackError,
    DeviceMismatchError,
    InvalidEntitlementError,
    verify_entitlement,
)
from ad_skin_tools.licensing.gate import GateDecision
from ad_skin_tools.licensing.network import (
    LicensingApiClient,
    LicensingRequestRejectedError,
    LicensingServiceUnavailableError,
)
from ad_skin_tools.licensing.release import (
    ReleaseAction,
    ReleaseConfigurationError,
    load_release_settings,
    parse_release_catalog,
)
from ad_skin_tools.licensing.storage import (
    CorruptLocalStateError,
    LocalLicenseState,
    LocalStateError,
    LocalStateStore,
)


RETRY_COOLDOWN_SECONDS = 60 * 60

TRIAL_AVAILABLE = "TRIAL_AVAILABLE"
TRIAL_ACTIVE = "TRIAL_ACTIVE"
TRIAL_EXPIRED = "TRIAL_EXPIRED"
PAID_ACTIVE = "PAID_ACTIVE"
VALIDATION_DUE = "VALIDATION_DUE"
OFFLINE_GRACE = "OFFLINE_GRACE"
HARD_EXPIRED = "HARD_EXPIRED"
LICENSE_REVOKED = "LICENSE_REVOKED"
LICENSE_UNKNOWN = "LICENSE_UNKNOWN"
DEVICE_INACTIVE = "DEVICE_INACTIVE"
SERVICE_UNAVAILABLE = "SERVICE_UNAVAILABLE"
CORRUPT_LOCAL_STATE = "CORRUPT_LOCAL_STATE"
CLOCK_ROLLBACK = "CLOCK_ROLLBACK"
CONFIGURATION_ERROR = "CONFIGURATION_ERROR"

_DENIAL_STATE = {
    "LICENSE_REVOKED": LICENSE_REVOKED,
    "LICENSE_UNKNOWN": LICENSE_UNKNOWN,
    "DEVICE_NOT_ACTIVE": DEVICE_INACTIVE,
}


class LicensingStateError(Exception):
    """Safe local error suitable for the License window."""

    def __init__(self, safe_message: str) -> None:
        super().__init__(safe_message)
        self.safe_message = safe_message


@dataclass(frozen=True)
class LicenseStatus:
    state: str
    title: str
    message: str
    access_allowed: bool
    expires_at_epoch: Optional[int] = None
    request_validation: bool = False
    can_start_trial: bool = False
    can_activate: bool = True
    can_retry: bool = False
    can_deactivate: bool = False
    can_reset: bool = False


class LicensingService:
    """Own local state, signed-time evaluation, and API state transitions."""

    def __init__(
        self,
        *,
        store: LocalStateStore,
        api_client: Optional[LicensingApiClient],
        public_key_der: bytes,
        fingerprint: str,
        clock: Callable[[], float] = time.time,
        configuration_error: Optional[str] = None,
    ) -> None:
        self._store = store
        self._api = api_client
        self._public_key = public_key_der
        self._fingerprint = fingerprint
        self._clock = clock
        self._configuration_error = configuration_error
        self._lock = threading.RLock()
        self._corrupt = False
        self._invalid_entitlement = False
        self._transient_error = False

        try:
            self._state = store.load()
        except CorruptLocalStateError:
            self._state = LocalLicenseState()
            self._corrupt = True

    @classmethod
    def disabled(
        cls,
        store: LocalStateStore,
        message: str,
        *,
        clock: Callable[[], float] = time.time,
    ) -> "LicensingService":
        return cls(
            store=store,
            api_client=None,
            public_key_der=b"",
            fingerprint="",
            clock=clock,
            configuration_error=message,
        )

    def status(self) -> LicenseStatus:
        with self._lock:
            return self._status_locked(persist_high_water=True)

    def authorize(self, _action: str) -> GateDecision:
        with self._lock:
            status = self._status_locked(persist_high_water=True)
            return GateDecision(
                allowed=status.access_allowed,
                state=status.state,
                message=status.message,
                request_validation=status.request_validation,
            )

    def should_validate(self) -> bool:
        with self._lock:
            return self._status_locked(
                persist_high_water=True
            ).request_validation

    def check_releases(
        self,
    ) -> tuple[Optional[ReleaseAction], Optional[ReleaseAction]]:
        """Fetch public manual-update notices without changing license state."""

        with self._lock:
            self._require_configured_locked()
            api = self._api
        return parse_release_catalog(api.get("/v1/releases/latest"))

    def start_trial(self) -> LicenseStatus:
        """Start or retrieve a trial only after the explicit UI action."""

        with self._lock:
            self._require_configured_locked()
        try:
            response = self._api.post(
                "/v1/trial/start",
                {"device_fingerprint": self._fingerprint},
            )
        except LicensingServiceUnavailableError:
            self._record_transient_failure()
            raise
        except LicensingRequestRejectedError as exc:
            self._record_rejection(exc)
            raise

        with self._lock:
            result = _require_result(response, {
                "outcome",
                "status",
                "started_at_epoch",
                "trial_expires_at_epoch",
                "server_time_epoch",
                "entitlement",
            })
            status = result.get("status")
            if status == "EXPIRED":
                if result.get("entitlement") is not None:
                    raise LicensingStateError(
                        "The trial response could not be verified."
                    )
                _require_epoch(result.get("server_time_epoch"))
                _require_epoch(result.get("started_at_epoch"))
                _require_epoch(result.get("trial_expires_at_epoch"))
                self._state.trial_entitlement = None
                self._state.authoritative_status = "TRIAL_EXPIRED"
                self._state.validation_retry_not_before_epoch = 0
                self._transient_error = False
                self._save_locked()
                return self._status_locked(persist_high_water=True)
            if status != "ACTIVE":
                raise LicensingStateError(
                    "The trial response could not be verified."
                )

            entitlement = _require_envelope(result.get("entitlement"))
            evaluation = self._verify_new_entitlement_locked(
                entitlement,
                expected_type="TRIAL",
            )
            if (
                evaluation.issued_at_epoch != result.get("server_time_epoch")
                or evaluation.expires_at_epoch
                != result.get("trial_expires_at_epoch")
            ):
                raise LicensingStateError(
                    "The trial response could not be verified."
                )
            self._state.trial_entitlement = entitlement
            self._state.last_seen_epoch = max(
                self._state.last_seen_epoch,
                evaluation.next_last_seen_epoch,
            )
            self._state.authoritative_status = None
            self._state.validation_retry_not_before_epoch = 0
            self._transient_error = False
            self._invalid_entitlement = False
            self._save_locked()
            return self._status_locked(persist_high_water=False)

    def activate(self, license_key: str) -> LicenseStatus:
        normalized_key = _normalize_license_key(license_key)
        with self._lock:
            self._require_configured_locked()
            if self._state.paid_entitlement is not None:
                raise LicensingStateError(
                    "Deactivate the current license before activating another key."
                )
        try:
            response = self._api.post(
                "/v1/license/activate",
                {
                    "device_fingerprint": self._fingerprint,
                    "license_key": normalized_key,
                },
            )
        except LicensingServiceUnavailableError:
            self._record_transient_failure()
            raise
        except LicensingRequestRejectedError:
            # A rejected replacement key must not destroy an existing grant.
            raise

        with self._lock:
            result = _require_paid_result(response, allow_entitlement=True)
            if result.get("outcome") not in {
                "LICENSE_ACTIVATED",
                "LICENSE_ALREADY_ACTIVE",
            } or result.get("device_status") != "ACTIVE":
                raise LicensingStateError(
                    "The activation response could not be verified."
                )
            entitlement = _require_envelope(result.get("entitlement"))
            evaluation = self._verify_new_entitlement_locked(
                entitlement,
                expected_type="PAID",
            )
            if evaluation.issued_at_epoch != result.get("server_time_epoch"):
                raise LicensingStateError(
                    "The activation response could not be verified."
                )
            self._state.paid_entitlement = entitlement
            self._state.license_key = normalized_key
            self._state.last_seen_epoch = max(
                self._state.last_seen_epoch,
                evaluation.next_last_seen_epoch,
            )
            self._state.authoritative_status = None
            self._state.validation_retry_not_before_epoch = 0
            self._transient_error = False
            self._invalid_entitlement = False
            self._save_locked()
            return self._status_locked(persist_high_water=False)

    def validate_paid(self) -> LicenseStatus:
        with self._lock:
            self._require_configured_locked()
            license_key = self._state.license_key
            if not license_key or self._state.paid_entitlement is None:
                raise LicensingStateError("No paid license is stored on this device.")
        try:
            response = self._api.post(
                "/v1/license/validate",
                {
                    "device_fingerprint": self._fingerprint,
                    "license_key": license_key,
                },
            )
        except LicensingServiceUnavailableError:
            self._record_transient_failure()
            raise
        except LicensingRequestRejectedError as exc:
            if exc.code in _DENIAL_STATE:
                self._record_rejection(exc)
            else:
                self._record_transient_failure()
            raise

        try:
            with self._lock:
                result = _require_paid_result(response, allow_entitlement=True)
                if (
                    result.get("outcome") != "LICENSE_VALIDATED"
                    or result.get("device_status") != "ACTIVE"
                ):
                    raise LicensingStateError(
                        "The validation response could not be verified."
                    )
                entitlement = _require_envelope(result.get("entitlement"))
                evaluation = self._verify_new_entitlement_locked(
                    entitlement,
                    expected_type="PAID",
                )
                if evaluation.issued_at_epoch != result.get("server_time_epoch"):
                    raise LicensingStateError(
                        "The validation response could not be verified."
                    )
                self._state.paid_entitlement = entitlement
                self._state.last_seen_epoch = max(
                    self._state.last_seen_epoch,
                    evaluation.next_last_seen_epoch,
                )
                self._state.authoritative_status = None
                self._state.validation_retry_not_before_epoch = 0
                self._transient_error = False
                self._invalid_entitlement = False
                self._save_locked()
                return self._status_locked(persist_high_water=False)
        except LicensingStateError:
            self._record_transient_failure()
            raise

    def deactivate_paid(self) -> LicenseStatus:
        with self._lock:
            self._require_configured_locked()
            license_key = self._state.license_key
            if not license_key:
                raise LicensingStateError("No paid license is stored on this device.")
        try:
            response = self._api.post(
                "/v1/license/deactivate",
                {
                    "device_fingerprint": self._fingerprint,
                    "license_key": license_key,
                },
            )
        except LicensingServiceUnavailableError:
            # Ambiguous deactivation must preserve local state for a safe retry.
            self._record_transient_failure()
            raise
        except LicensingRequestRejectedError as exc:
            self._record_rejection(exc)
            raise

        with self._lock:
            result = _require_paid_result(response, allow_entitlement=False)
            if result.get("outcome") not in {
                "LICENSE_DEACTIVATED",
                "LICENSE_ALREADY_DEACTIVATED",
            }:
                raise LicensingStateError(
                    "The deactivation response could not be verified."
                )
            if result.get("device_status") != "DEACTIVATED":
                raise LicensingStateError(
                    "The deactivation response could not be verified."
                )
            self._state.paid_entitlement = None
            self._state.license_key = None
            self._state.authoritative_status = None
            self._state.validation_retry_not_before_epoch = 0
            self._transient_error = False
            self._invalid_entitlement = False
            self._save_locked()
            return self._status_locked(persist_high_water=True)

    def retry(self) -> LicenseStatus:
        with self._lock:
            has_paid = bool(
                self._state.license_key
                and self._state.paid_entitlement is not None
            )
            has_trial = self._state.trial_entitlement is not None
        if has_paid:
            return self.validate_paid()
        if has_trial:
            return self.start_trial()
        raise LicensingStateError("There is no stored license request to retry.")

    def reset_local_state(self) -> LicenseStatus:
        with self._lock:
            self._store.reset()
            self._state = LocalLicenseState()
            self._corrupt = False
            self._invalid_entitlement = False
            self._transient_error = False
            return self._status_locked(persist_high_water=False)

    def _status_locked(self, *, persist_high_water: bool) -> LicenseStatus:
        status = self._classify_status_locked(
            persist_high_water=persist_high_water
        )
        has_paid = self._state.paid_entitlement is not None
        has_retry_state = bool(has_paid or self._state.trial_entitlement)
        can_deactivate_recovery = bool(
            self._state.license_key
            and status.state in {CORRUPT_LOCAL_STATE, CLOCK_ROLLBACK}
        )
        return replace(
            status,
            can_activate=status.can_activate and not has_paid,
            can_retry=status.can_retry and has_retry_state,
            can_deactivate=(
                status.can_deactivate or can_deactivate_recovery
            ),
        )

    def _classify_status_locked(
        self,
        *,
        persist_high_water: bool,
    ) -> LicenseStatus:
        if self._configuration_error:
            return _status(CONFIGURATION_ERROR)
        if self._corrupt or self._invalid_entitlement:
            return _status(CORRUPT_LOCAL_STATE)

        authoritative = self._state.authoritative_status
        if authoritative in _DENIAL_STATE:
            return _status(_DENIAL_STATE[authoritative])
        if authoritative == "TRIAL_EXPIRED":
            return _status(TRIAL_EXPIRED)

        if self._state.paid_entitlement is not None:
            if not self._state.license_key:
                self._invalid_entitlement = True
                return _status(CORRUPT_LOCAL_STATE)
            evaluation = self._evaluate_locked(
                self._state.paid_entitlement,
                persist_high_water=persist_high_water,
            )
            if evaluation is None:
                return self._verification_failure_status_locked()
            if evaluation == CLOCK_ROLLBACK:
                return _status(CLOCK_ROLLBACK)
            if evaluation.entitlement_type != "PAID":
                self._invalid_entitlement = True
                return _status(CORRUPT_LOCAL_STATE)
            if evaluation.state == "HARD_EXPIRED":
                return _status(HARD_EXPIRED, evaluation.expires_at_epoch)
            if evaluation.state == "REVALIDATION_DUE":
                retry_due = (
                    self._now_locked()
                    >= self._state.validation_retry_not_before_epoch
                )
                if self._transient_error or not retry_due:
                    return _status(
                        OFFLINE_GRACE,
                        evaluation.expires_at_epoch,
                        request_validation=retry_due,
                    )
                return _status(
                    VALIDATION_DUE,
                    evaluation.expires_at_epoch,
                    request_validation=True,
                )
            return _status(PAID_ACTIVE, evaluation.expires_at_epoch)

        if self._state.trial_entitlement is not None:
            evaluation = self._evaluate_locked(
                self._state.trial_entitlement,
                persist_high_water=persist_high_water,
            )
            if evaluation is None:
                return self._verification_failure_status_locked()
            if evaluation == CLOCK_ROLLBACK:
                return _status(CLOCK_ROLLBACK)
            if evaluation.entitlement_type != "TRIAL":
                self._invalid_entitlement = True
                return _status(CORRUPT_LOCAL_STATE)
            if evaluation.state == "HARD_EXPIRED":
                return _status(TRIAL_EXPIRED, evaluation.expires_at_epoch)
            return _status(TRIAL_ACTIVE, evaluation.expires_at_epoch)

        if self._transient_error:
            return _status(SERVICE_UNAVAILABLE)
        return _status(TRIAL_AVAILABLE)

    def _evaluate_locked(
        self,
        entitlement: Mapping[str, str],
        *,
        persist_high_water: bool,
    ):
        try:
            evaluation = verify_entitlement(
                entitlement,
                self._public_key,
                self._fingerprint,
                current_time_epoch=self._now_locked(),
                last_seen_epoch=self._state.last_seen_epoch,
            )
        except ClockRollbackError:
            return CLOCK_ROLLBACK
        except (InvalidEntitlementError, DeviceMismatchError):
            self._invalid_entitlement = True
            return None

        if (
            persist_high_water
            and evaluation.next_last_seen_epoch > self._state.last_seen_epoch
        ):
            self._state.last_seen_epoch = evaluation.next_last_seen_epoch
            try:
                self._save_locked()
            except LicensingStateError:
                self._corrupt = True
                return None
        return evaluation

    def _verification_failure_status_locked(self) -> LicenseStatus:
        return _status(CORRUPT_LOCAL_STATE)

    def _verify_new_entitlement_locked(
        self,
        entitlement: Mapping[str, str],
        *,
        expected_type: str,
    ):
        try:
            evaluation = verify_entitlement(
                entitlement,
                self._public_key,
                self._fingerprint,
                current_time_epoch=self._now_locked(),
                last_seen_epoch=self._state.last_seen_epoch,
            )
        except ClockRollbackError as exc:
            raise LicensingStateError(
                "The computer clock must be corrected before licensing can continue."
            ) from exc
        except (InvalidEntitlementError, DeviceMismatchError) as exc:
            raise LicensingStateError(
                "The license response could not be verified."
            ) from exc
        if evaluation.entitlement_type != expected_type:
            raise LicensingStateError(
                "The license response could not be verified."
            )
        return evaluation

    def _record_transient_failure(self) -> None:
        with self._lock:
            self._transient_error = True
            if self._state.paid_entitlement is not None:
                self._state.validation_retry_not_before_epoch = (
                    self._now_locked() + RETRY_COOLDOWN_SECONDS
                )
                self._save_locked()

    def _record_rejection(self, error: LicensingRequestRejectedError) -> None:
        state = _DENIAL_STATE.get(error.code)
        if state is None:
            return
        with self._lock:
            self._state.paid_entitlement = None
            self._state.license_key = None
            self._state.authoritative_status = error.code
            self._state.validation_retry_not_before_epoch = 0
            self._transient_error = False
            self._save_locked()

    def _require_configured_locked(self) -> None:
        if self._configuration_error or self._api is None:
            raise LicensingStateError("License checking is not configured.")

    def _save_locked(self) -> None:
        try:
            self._store.save(self._state)
        except LocalStateError as exc:
            raise LicensingStateError(
                "The local license state could not be saved."
            ) from exc

    def _now_locked(self) -> int:
        value = int(self._clock())
        if value < 0:
            raise LicensingStateError("The computer clock is invalid.")
        return value


def create_default_service() -> LicensingService:
    """Create the runtime service while keeping configuration failures visible."""

    store = LocalStateStore()

    try:
        settings = load_release_settings()
        fingerprint = device_fingerprint()
        client = LicensingApiClient(settings.api_base_url)
    except (ReleaseConfigurationError, DeviceIdentityError, ValueError) as exc:
        return LicensingService.disabled(store, str(exc))

    return LicensingService(
        store=store,
        api_client=client,
        public_key_der=settings.public_key_der,
        fingerprint=fingerprint,
    )


def _status(
    state: str,
    expires_at_epoch: Optional[int] = None,
    *,
    request_validation: bool = False,
) -> LicenseStatus:
    values = {
        TRIAL_AVAILABLE: (
            "Trial available",
            "Start the 48-hour trial when you are ready. Opening the tool or "
            "a locked action will not start it.",
            False,
        ),
        TRIAL_ACTIVE: (
            "Trial active",
            "All tool actions are available until the trial ends.",
            True,
        ),
        TRIAL_EXPIRED: (
            "Trial ended",
            "Activate a license to continue using protected tool actions.",
            False,
        ),
        PAID_ACTIVE: (
            "License active",
            "This device is licensed and ready to use.",
            True,
        ),
        VALIDATION_DUE: (
            "Checking license",
            "Protected actions remain available while the license is checked.",
            True,
        ),
        OFFLINE_GRACE: (
            "Working offline",
            "Protected actions remain available until the stored offline period ends.",
            True,
        ),
        HARD_EXPIRED: (
            "Online check required",
            "Connect to the internet and retry before using protected actions.",
            False,
        ),
        LICENSE_REVOKED: (
            "License inactive",
            "This license is no longer active. Use another license or contact support.",
            False,
        ),
        LICENSE_UNKNOWN: (
            "License not found",
            "Check the license key or use another license.",
            False,
        ),
        DEVICE_INACTIVE: (
            "Device inactive",
            "Activate this device again before using protected actions.",
            False,
        ),
        SERVICE_UNAVAILABLE: (
            "Temporarily unavailable",
            "License checking could not connect. Check the internet connection and retry.",
            False,
        ),
        CORRUPT_LOCAL_STATE: (
            "Local license data needs repair",
            "Reset the local license data, then start or activate again.",
            False,
        ),
        CLOCK_ROLLBACK: (
            "Computer clock needs attention",
            "Correct the computer date and time, then retry online.",
            False,
        ),
        CONFIGURATION_ERROR: (
            "License checking unavailable",
            "This installation is missing its license configuration. Reinstall the tool or contact support.",
            False,
        ),
    }
    title, message, allowed = values[state]
    return LicenseStatus(
        state=state,
        title=title,
        message=message,
        access_allowed=allowed,
        expires_at_epoch=expires_at_epoch,
        request_validation=request_validation,
        can_start_trial=state in {TRIAL_AVAILABLE, SERVICE_UNAVAILABLE},
        can_activate=state != CONFIGURATION_ERROR,
        can_retry=state in {
            VALIDATION_DUE,
            OFFLINE_GRACE,
            HARD_EXPIRED,
            SERVICE_UNAVAILABLE,
            CLOCK_ROLLBACK,
        },
        can_deactivate=state in {
            PAID_ACTIVE,
            VALIDATION_DUE,
            OFFLINE_GRACE,
            HARD_EXPIRED,
        },
        can_reset=state in {CORRUPT_LOCAL_STATE, CLOCK_ROLLBACK},
    )


def _require_result(
    response: object,
    expected_fields: set,
) -> Mapping[str, Any]:
    if not isinstance(response, Mapping) or set(response) != {"result"}:
        raise LicensingStateError("The license response could not be verified.")
    result = response.get("result")
    if not isinstance(result, Mapping) or set(result) != expected_fields:
        raise LicensingStateError("The license response could not be verified.")
    return result


def _require_paid_result(
    response: object,
    *,
    allow_entitlement: bool,
) -> Mapping[str, Any]:
    fields = {
        "outcome",
        "license_status",
        "device_status",
        "server_time_epoch",
    }
    if allow_entitlement:
        fields.add("entitlement")
    result = _require_result(response, fields)
    if result.get("license_status") != "ACTIVE":
        raise LicensingStateError("The license response could not be verified.")
    _require_epoch(result.get("server_time_epoch"))
    return result


def _require_envelope(value: object) -> Dict[str, str]:
    if not isinstance(value, Mapping) or set(value) != {"payload", "signature"}:
        raise LicensingStateError("The license response could not be verified.")
    payload = value.get("payload")
    signature = value.get("signature")
    if not isinstance(payload, str) or not isinstance(signature, str):
        raise LicensingStateError("The license response could not be verified.")
    return {"payload": payload, "signature": signature}


def _require_epoch(value: object) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise LicensingStateError("The license response could not be verified.")
    return value


def _normalize_license_key(value: object) -> str:
    if not isinstance(value, str):
        raise LicensingStateError("Enter a license key.")
    normalized = value.strip()
    if not normalized or len(normalized) > 1024:
        raise LicensingStateError("Enter a valid license key.")
    return normalized
