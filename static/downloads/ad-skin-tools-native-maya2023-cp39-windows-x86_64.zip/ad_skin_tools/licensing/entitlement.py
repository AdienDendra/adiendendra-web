"""Verify signed offline entitlements and evaluate their time bounds."""

from __future__ import annotations

import base64
import binascii
import hashlib
import hmac
import json
import re
from dataclasses import dataclass
from typing import Any, Mapping

from ._p256 import verify_p256_sha256


SIGNING_DOMAIN = b"AD_SKIN_TOOLS_ENTITLEMENT:1\x00"
DEVICE_BINDING_DOMAIN = b"AD_SKIN_TOOLS_ENTITLEMENT_DEVICE:1\x00"
TRIAL_DURATION_SECONDS = 48 * 60 * 60
PAID_VALIDATION_INTERVAL_SECONDS = 7 * 24 * 60 * 60
PAID_OFFLINE_EXPIRY_SECONDS = 30 * 24 * 60 * 60
MAX_PAYLOAD_BYTES = 2 * 1024
MAX_SIGNATURE_BYTES = 80
_BASE64URL_PATTERN = re.compile(r"[A-Za-z0-9_-]+\Z")
_FINGERPRINT_PATTERN = re.compile(r"[0-9a-fA-F]{64}\Z")
_HEX_PATTERN = re.compile(r"[0-9a-f]{64}\Z")


class EntitlementVerificationError(Exception):
    """Base fail-closed verification error."""


class InvalidEntitlementError(EntitlementVerificationError):
    """Raised when an envelope, signature, or claim is invalid."""


class DeviceMismatchError(EntitlementVerificationError):
    """Raised when a valid entitlement belongs to another device."""


class ClockRollbackError(EntitlementVerificationError):
    """Raised when local time moved behind the stored high-water mark."""


@dataclass(frozen=True)
class EntitlementEvaluation:
    """Verified claims plus the state needed by Phase 5.6 integration."""

    entitlement_type: str
    state: str
    issued_at_epoch: int
    validate_after_epoch: int | None
    expires_at_epoch: int
    next_last_seen_epoch: int


def verify_entitlement(
    envelope: Mapping[str, Any],
    public_key_der: bytes,
    device_fingerprint: str,
    *,
    current_time_epoch: int,
    last_seen_epoch: int = 0,
) -> EntitlementEvaluation:
    """Verify signature, device binding, fixed policy, and local time."""

    if not isinstance(envelope, Mapping) or set(envelope) != {
        "payload",
        "signature",
    }:
        raise InvalidEntitlementError()

    payload_bytes = _decode_base64url(
        envelope.get("payload"),
        maximum_bytes=MAX_PAYLOAD_BYTES,
    )
    signature = _decode_base64url(
        envelope.get("signature"),
        maximum_bytes=MAX_SIGNATURE_BYTES,
    )

    if not verify_p256_sha256(
        public_key_der,
        SIGNING_DOMAIN + payload_bytes,
        signature,
    ):
        raise InvalidEntitlementError()

    claims = _parse_claims(payload_bytes)
    expected_binding = _device_binding(device_fingerprint)

    if not hmac.compare_digest(claims["device_binding"], expected_binding):
        raise DeviceMismatchError()

    _require_epoch(current_time_epoch)
    _require_epoch(last_seen_epoch)

    if (
        current_time_epoch < last_seen_epoch
        and claims["issued_at_epoch"] <= last_seen_epoch
    ):
        raise ClockRollbackError()

    issued_at_epoch = claims["issued_at_epoch"]
    expires_at_epoch = claims["expires_at_epoch"]
    effective_now = max(
        current_time_epoch,
        last_seen_epoch,
        issued_at_epoch,
    )
    next_last_seen = effective_now

    if effective_now >= expires_at_epoch:
        state = "HARD_EXPIRED"
    elif claims["entitlement_type"] == "PAID":
        state = (
            "VALID"
            if effective_now < claims["validate_after_epoch"]
            else "REVALIDATION_DUE"
        )
    else:
        state = "VALID"

    return EntitlementEvaluation(
        entitlement_type=claims["entitlement_type"],
        state=state,
        issued_at_epoch=issued_at_epoch,
        validate_after_epoch=claims.get("validate_after_epoch"),
        expires_at_epoch=expires_at_epoch,
        next_last_seen_epoch=next_last_seen,
    )


def _parse_claims(payload_bytes: bytes) -> dict[str, Any]:
    try:
        claims = json.loads(payload_bytes.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise InvalidEntitlementError() from exc

    if not isinstance(claims, dict):
        raise InvalidEntitlementError()

    entitlement_type = claims.get("entitlement_type")
    common_fields = {
        "device_binding",
        "entitlement_type",
        "expires_at_epoch",
        "issued_at_epoch",
        "schema_version",
    }

    if entitlement_type == "TRIAL":
        expected_fields = common_fields | {"trial_started_at_epoch"}
    elif entitlement_type == "PAID":
        expected_fields = common_fields | {"validate_after_epoch"}
    else:
        raise InvalidEntitlementError()

    schema_version = claims.get("schema_version")

    if (
        set(claims) != expected_fields
        or not isinstance(schema_version, int)
        or isinstance(schema_version, bool)
        or schema_version != 1
    ):
        raise InvalidEntitlementError()

    device_binding = claims.get("device_binding")

    if (
        not isinstance(device_binding, str)
        or _HEX_PATTERN.fullmatch(device_binding) is None
    ):
        raise InvalidEntitlementError()

    issued_at_epoch = claims.get("issued_at_epoch")
    expires_at_epoch = claims.get("expires_at_epoch")
    _require_epoch(issued_at_epoch)
    _require_epoch(expires_at_epoch)

    if issued_at_epoch >= expires_at_epoch:
        raise InvalidEntitlementError()

    if entitlement_type == "TRIAL":
        started_at_epoch = claims.get("trial_started_at_epoch")
        _require_epoch(started_at_epoch)

        if (
            started_at_epoch > issued_at_epoch
            or expires_at_epoch
            != started_at_epoch + TRIAL_DURATION_SECONDS
        ):
            raise InvalidEntitlementError()
    else:
        validate_after_epoch = claims.get("validate_after_epoch")
        _require_epoch(validate_after_epoch)

        if (
            validate_after_epoch
            != issued_at_epoch + PAID_VALIDATION_INTERVAL_SECONDS
            or expires_at_epoch
            != issued_at_epoch + PAID_OFFLINE_EXPIRY_SECONDS
        ):
            raise InvalidEntitlementError()

    return claims


def _decode_base64url(value: object, *, maximum_bytes: int) -> bytes:
    if (
        not isinstance(value, str)
        or _BASE64URL_PATTERN.fullmatch(value) is None
    ):
        raise InvalidEntitlementError()

    try:
        decoded = base64.urlsafe_b64decode(
            value + "=" * (-len(value) % 4)
        )
    except (ValueError, binascii.Error) as exc:
        raise InvalidEntitlementError() from exc

    if (
        not decoded
        or len(decoded) > maximum_bytes
        or base64.urlsafe_b64encode(decoded)
        .rstrip(b"=")
        .decode("ascii")
        != value
    ):
        raise InvalidEntitlementError()

    return decoded


def _device_binding(device_fingerprint: str) -> str:
    if (
        not isinstance(device_fingerprint, str)
        or _FINGERPRINT_PATTERN.fullmatch(device_fingerprint) is None
    ):
        raise InvalidEntitlementError()

    return hashlib.sha256(
        DEVICE_BINDING_DOMAIN + bytes.fromhex(device_fingerprint)
    ).hexdigest()


def _require_epoch(value: object) -> None:
    if (
        not isinstance(value, int)
        or isinstance(value, bool)
        or value < 0
    ):
        raise InvalidEntitlementError()
