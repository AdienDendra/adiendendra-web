"""Controlled licensing configuration and manual-release actions."""

from __future__ import annotations

import base64
import binascii
from dataclasses import dataclass
import os
from typing import Any, Mapping, Optional, Tuple
from urllib.parse import urlsplit

from ad_skin_tools.licensing._p256 import validate_p256_public_key_der


INSTALLED_VERSION = (1, 0, 0)
PRODUCT_MAJOR_VERSION = 1
# The sole customer-facing configuration source. The signing key below is
# public verification material; the corresponding private key stays in KMS.
BUY_URL = (
    "https://adiendendra.lemonsqueezy.com/checkout/buy/"
    "0171eb42-6ef8-43ac-9d30-a27f54456d8f"
)
BUY_HOSTNAME = "adiendendra.lemonsqueezy.com"
BUY_PATH_PREFIX = "/checkout/buy/"
# The URL shape does not reveal the provider mode; this marker records review.
BUY_URL_MODE = "live"
PRODUCTION_API_HOST_SUFFIX = ".execute-api.ap-southeast-2.amazonaws.com"

# Environment overrides are accepted only by an explicit development
# deployment carrying _dev_reload, which is excluded from customer packages.
PINNED_API_BASE_URL = "https://omuv86irek.execute-api.ap-southeast-2.amazonaws.com"
PINNED_PUBLIC_KEY_DER_BASE64 = (
    "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAESX+3Mpp+SrxK8pmqyDLfvs+U9Jsn"
    "9aD7syh1vMwmzowjWkIDeM5X9KKNDuQJ8I970+Ln7qrnejR+7JYxwkupkQ=="
)


class ReleaseConfigurationError(Exception):
    """Raised when controlled licensing configuration is unavailable."""


@dataclass(frozen=True)
class ReleaseAction:
    """One notification-only release action rendered by the License window."""

    kind: str
    version: Tuple[int, int, int]
    url: str

    @property
    def label(self) -> str:
        prefix = "Update to" if self.kind == "UPDATE" else "Upgrade to"
        return "{} {}".format(prefix, format_version(self.version))


@dataclass(frozen=True)
class ReleaseSettings:
    api_base_url: str
    public_key_der: bytes
    buy_url: str
    installed_version: Tuple[int, int, int]
    product_major_version: int


def validate_release_action(action: ReleaseAction) -> ReleaseAction:
    """Validate a future notification-only action before showing it."""

    if not isinstance(action, ReleaseAction):
        raise ReleaseConfigurationError("The release action is invalid.")
    format_version(action.version)
    _validate_official_url(action.url)
    if action.version <= INSTALLED_VERSION:
        raise ReleaseConfigurationError("The release action is not newer.")
    if action.kind == "UPDATE":
        if action.version[0] != PRODUCT_MAJOR_VERSION:
            raise ReleaseConfigurationError("The update version is invalid.")
    elif action.kind == "UPGRADE":
        if action.version[0] <= PRODUCT_MAJOR_VERSION:
            raise ReleaseConfigurationError("The upgrade version is invalid.")
    else:
        raise ReleaseConfigurationError("The release action kind is invalid.")
    return action


def parse_release_catalog(
    response: object,
) -> Tuple[Optional[ReleaseAction], Optional[ReleaseAction]]:
    """Parse the exact public catalog and hide offers not newer than this build."""

    if not isinstance(response, Mapping) or set(response) != {"result"}:
        raise ReleaseConfigurationError("The release catalog is invalid.")
    result = response.get("result")
    if not isinstance(result, Mapping) or set(result) != {
        "latest_update",
        "latest_upgrade",
    }:
        raise ReleaseConfigurationError("The release catalog is invalid.")
    return (
        _parse_release_offer("UPDATE", result.get("latest_update")),
        _parse_release_offer("UPGRADE", result.get("latest_upgrade")),
    )


def load_release_settings(
    environment: Optional[Mapping[str, str]] = None,
    *,
    allow_development_overrides: Optional[bool] = None,
) -> ReleaseSettings:
    """Load the pinned configuration with narrow development overrides."""

    values = environment if environment is not None else os.environ
    api_url = PINNED_API_BASE_URL
    public_key_text = PINNED_PUBLIC_KEY_DER_BASE64

    overrides_allowed = (
        _is_development_deployment()
        if allow_development_overrides is None
        else bool(allow_development_overrides)
    )
    if overrides_allowed:
        api_url = values.get("AD_SKIN_TOOLS_LICENSE_API_URL", api_url)
        public_key_text = values.get(
            "AD_SKIN_TOOLS_LICENSE_PUBLIC_KEY_DER_BASE64",
            public_key_text,
        )

    return ReleaseSettings(
        api_base_url=_validate_https_url(api_url, "licensing API"),
        public_key_der=_decode_public_key(public_key_text),
        buy_url=_validate_buy_url(BUY_URL),
        installed_version=INSTALLED_VERSION,
        product_major_version=PRODUCT_MAJOR_VERSION,
    )


def validate_customer_release_configuration() -> ReleaseSettings:
    """Reject a shipping build until all production pins are explicit."""

    if BUY_URL_MODE != "live":
        raise ReleaseConfigurationError(
            "The reusable checkout has not been marked as Live Mode."
        )
    settings = load_release_settings(
        environment={},
        allow_development_overrides=False,
    )
    api_hostname = urlsplit(settings.api_base_url).hostname or ""
    if not api_hostname.endswith(PRODUCTION_API_HOST_SUFFIX):
        raise ReleaseConfigurationError(
            "The licensing API is not the production ap-southeast-2 endpoint."
        )
    return settings


def _is_development_deployment() -> bool:
    try:
        __import__("ad_skin_tools._dev_reload")
    except ImportError:
        return False
    return True


def format_version(version: Tuple[int, int, int]) -> str:
    if (
        not isinstance(version, tuple)
        or len(version) != 3
        or any(
            not isinstance(value, int) or isinstance(value, bool) or value < 0
            for value in version
        )
    ):
        raise ReleaseConfigurationError("The release version is invalid.")
    return ".".join(str(value) for value in version)


def _parse_release_offer(
    kind: str,
    value: Any,
) -> Optional[ReleaseAction]:
    if value is None:
        return None
    if not isinstance(value, Mapping) or set(value) != {"version", "url"}:
        raise ReleaseConfigurationError("The release offer is invalid.")
    version = _parse_version(value.get("version"))
    url = _validate_official_url(value.get("url"))
    if version <= INSTALLED_VERSION:
        return None
    return validate_release_action(ReleaseAction(kind, version, url))


def _parse_version(value: object) -> Tuple[int, int, int]:
    if not isinstance(value, str):
        raise ReleaseConfigurationError("The release version is invalid.")
    parts = value.split(".")
    if (
        len(parts) != 3
        or any(
            not part.isdigit()
            or len(part) > 9
            or (len(part) > 1 and part.startswith("0"))
            for part in parts
        )
    ):
        raise ReleaseConfigurationError("The release version is invalid.")
    return int(parts[0]), int(parts[1]), int(parts[2])


def _decode_public_key(value: object) -> bytes:
    if not isinstance(value, str) or not value:
        raise ReleaseConfigurationError(
            "The licensing public key is not configured."
        )
    try:
        decoded = base64.b64decode(value, validate=True)
    except (ValueError, binascii.Error) as exc:
        raise ReleaseConfigurationError(
            "The licensing public key is invalid."
        ) from exc
    try:
        validate_p256_public_key_der(decoded)
    except ValueError as exc:
        raise ReleaseConfigurationError(
            "The licensing public key is invalid."
        ) from exc
    return decoded


def _validate_https_url(value: object, label: str) -> str:
    if not isinstance(value, str) or not value:
        raise ReleaseConfigurationError("The {} is not configured.".format(label))
    parsed = urlsplit(value)
    if (
        parsed.scheme != "https"
        or not parsed.hostname
        or parsed.username is not None
        or parsed.password is not None
        or parsed.query
        or parsed.fragment
    ):
        raise ReleaseConfigurationError("The {} is invalid.".format(label))
    return value.rstrip("/")


def _validate_official_url(value: object) -> str:
    url = _validate_https_url(value, "official product URL")
    hostname = urlsplit(url).hostname
    if hostname not in {"adiendendra.com", "www.adiendendra.com"}:
        raise ReleaseConfigurationError("The official product URL is invalid.")
    return url


def _validate_buy_url(value: object) -> str:
    """Accept only the pinned store's reusable hosted checkout shape."""

    url = _validate_https_url(value, "checkout URL")
    parsed = urlsplit(url)
    checkout_identifier = parsed.path[len(BUY_PATH_PREFIX) :]
    if (
        parsed.hostname != BUY_HOSTNAME
        or not parsed.path.startswith(BUY_PATH_PREFIX)
        or not checkout_identifier
        or "/" in checkout_identifier
    ):
        raise ReleaseConfigurationError("The checkout URL is invalid.")
    return url
