"""Persistent Mirror UI and registered skin-weight execution."""

from contextlib import contextmanager

import maya.cmds as cmds

from ad_skin_tools.core.selection import get_selected_mesh_object
from ad_skin_tools.licensing import gate
from ad_skin_tools.mirror import influence_pairing, operation, pairing, reference
from ad_skin_tools.mirror import registered_pairing


CTRL_UTILITIES_FRAME = "adSkin_utilitiesFrame"
CTRL_RESET = "adSkin_mirrorResetButton"
CTRL_MIRROR_MESH_FIELD = "adSkin_mirrorMeshField"
CTRL_LOAD_MIRROR_MESH = "adSkin_mirrorLoadMeshButton"
CTRL_AXIS = "adSkin_mirrorAxis"
CTRL_DIRECTION = "adSkin_mirrorDirection"
CTRL_CENTER_LABEL = "adSkin_mirrorCenterLabel"
CTRL_CENTER_FIELD = "adSkin_mirrorCenterField"
CTRL_REGISTER_CENTER = "adSkin_mirrorRegisterCenterButton"
CTRL_TOLERANCE = "adSkin_mirrorToleranceField"
CTRL_LEFT_MARKER = "adSkin_mirrorLeftMarker"
CTRL_RIGHT_MARKER = "adSkin_mirrorRightMarker"
CTRL_PREVIEW = "adSkin_mirrorPreviewButton"
CTRL_REGISTER_PAIRING = "adSkin_mirrorRegisterPairingButton"
CTRL_MIRROR = "adSkin_mirrorWeightsButton"
CTRL_TRANSFER = "adSkin_transferWeightsButton"
CTRL_STATUS = "adSkin_mirrorStatus"

_AXIS_ORDER = ("YZ", "XZ", "XY")
_AXIS_CENTER_LABEL = {
    "YZ": "Center Plane X",
    "XZ": "Center Plane Y",
    "XY": "Center Plane Z",
}
_AXIS_DIRECTIONS = {
    "YZ": ("+X to -X", "-X to +X"),
    "XZ": ("+Y to -Y", "-Y to +Y"),
    "XY": ("+Z to -Z", "-Z to +Z"),
}
_DEFAULT_CENTERS = {"YZ": 0.0, "XZ": 0.0, "XY": 0.0}
_DEFAULT_TOLERANCE = 0.001

_TOOL_WINDOW = None
_SKIN_OPERATIONS = None


def install(tool_window_module, skin_operations_module) -> None:
    global _TOOL_WINDOW, _SKIN_OPERATIONS

    _TOOL_WINDOW = tool_window_module
    _SKIN_OPERATIONS = skin_operations_module
    _SKIN_OPERATIONS.register_common_enabled_callback(_set_common_enabled)

    state = _state()
    state.setdefault("mirror_mesh_shape", None)
    state.setdefault("mirror_mesh_transform", None)
    state.setdefault("mirror_centers", dict(_DEFAULT_CENTERS))
    state.setdefault("mirror_preflight", None)
    state.setdefault("mirror_left_marker", "")
    state.setdefault("mirror_right_marker", "")


def shutdown() -> None:
    global _TOOL_WINDOW, _SKIN_OPERATIONS

    if _SKIN_OPERATIONS is not None:
        _SKIN_OPERATIONS.unregister_common_enabled_callback(
            _set_common_enabled
        )

    _TOOL_WINDOW = None
    _SKIN_OPERATIONS = None


def _build_title_row() -> None:
    layout = cmds.formLayout(height=24)
    title = cmds.text(
        label="Mirror Skin Weights Posed Mesh",
        align="left",
        font="boldLabelFont",
    )
    reset = cmds.button(
        CTRL_RESET,
        label="Reset",
        width=64,
        height=22,
        command=lambda *_: reset_controls(),
    )
    cmds.formLayout(
        layout,
        edit=True,
        attachForm=[
            (title, "left", 0),
            (title, "top", 3),
            (title, "bottom", 2),
            (reset, "right", 0),
            (reset, "top", 1),
            (reset, "bottom", 1),
        ],
        attachControl=[(title, "right", 8, reset)],
    )
    cmds.setParent("..")


def _build_mirror_mesh_row() -> None:
    layout = cmds.formLayout(height=_TOOL_WINDOW.ROW_HEIGHT)
    label = cmds.text(
        label="Mirror Mesh",
        align="left",
        width=_TOOL_WINDOW.LABEL_WIDTH,
    )
    load = cmds.button(
        CTRL_LOAD_MIRROR_MESH,
        label="Load Mirror Mesh",
        width=118,
        command=lambda *_: load_mirror_mesh(),
    )
    field = cmds.textField(
        CTRL_MIRROR_MESH_FIELD,
        text="<No Mirror Mesh>",
        editable=False,
    )
    cmds.formLayout(
        layout,
        edit=True,
        attachForm=[
            (label, "left", 0),
            (label, "top", 2),
            (label, "bottom", 2),
            (load, "right", 0),
            (load, "top", 1),
            (load, "bottom", 1),
            (field, "top", 1),
            (field, "bottom", 1),
        ],
        attachControl=[
            (field, "left", _TOOL_WINDOW.CONTROL_GAP, label),
            (field, "right", 5, load),
        ],
    )
    cmds.setParent("..")


def _build_center_row() -> None:
    layout = cmds.formLayout(height=_TOOL_WINDOW.ROW_HEIGHT)
    label = cmds.text(
        CTRL_CENTER_LABEL,
        label="Center Plane X",
        align="left",
        width=_TOOL_WINDOW.LABEL_WIDTH,
    )
    register = cmds.button(
        CTRL_REGISTER_CENTER,
        label="Register Selected",
        width=118,
        command=lambda *_: register_selected_center(),
    )
    field = cmds.floatField(
        CTRL_CENTER_FIELD,
        value=0.0,
        precision=6,
        changeCommand=lambda *_: _on_center_edited(),
    )
    cmds.formLayout(
        layout,
        edit=True,
        attachForm=[
            (label, "left", 0),
            (label, "top", 2),
            (label, "bottom", 2),
            (register, "right", 0),
            (register, "top", 1),
            (register, "bottom", 1),
            (field, "top", 1),
            (field, "bottom", 1),
        ],
        attachControl=[
            (field, "left", _TOOL_WINDOW.CONTROL_GAP, label),
            (field, "right", 5, register),
        ],
    )
    cmds.setParent("..")


def _build_side_marker_fields():
    """Build equal-width marker fields with native gray placeholders."""

    layout = cmds.formLayout(height=_TOOL_WINDOW.ROW_HEIGHT)
    left_label = cmds.text(label="Left", align="left", width=34)
    left_field = cmds.textField(
        CTRL_LEFT_MARKER,
        text="",
        placeholderText="L",
        annotation=(
            "Literal left-side marker. It may be a prefix, suffix, or infix, "
            "for example L, LFT, L_, or _l."
        ),
        changeCommand=lambda *_: _on_side_markers_changed(),
    )
    right_label = cmds.text(label="Right", align="left", width=34)
    right_field = cmds.textField(
        CTRL_RIGHT_MARKER,
        text="",
        placeholderText="R",
        annotation=(
            "Literal right-side marker. It may be a prefix, suffix, or infix, "
            "for example R, RGT, R_, or _r."
        ),
        changeCommand=lambda *_: _on_side_markers_changed(),
    )
    cmds.formLayout(
        layout,
        edit=True,
        attachForm=[
            (left_label, "left", 0),
            (left_label, "top", 2),
            (left_label, "bottom", 2),
            (left_field, "top", 1),
            (left_field, "bottom", 1),
            (right_label, "top", 2),
            (right_label, "bottom", 2),
            (right_field, "right", 0),
            (right_field, "top", 1),
            (right_field, "bottom", 1),
        ],
        attachControl=[
            (left_field, "left", 4, left_label),
            (right_field, "left", 4, right_label),
        ],
        attachPosition=[
            (left_field, "right", 0, 49),
            (right_label, "left", 0, 51),
        ],
    )
    cmds.setParent("..")
    return layout


def load_mirror_mesh() -> None:
    try:
        _TOOL_WINDOW._require_not_busy()
        selected = get_selected_mesh_object()
        state = _state()
        state.update(
            {
                "mirror_mesh_shape": selected.mesh_shape,
                "mirror_mesh_transform": selected.mesh_transform,
                "mirror_preflight": None,
            }
        )
        _sync_mirror_mesh_field()

        inspection = registered_pairing.inspect(selected.mesh_shape)
        if inspection.valid:
            record = inspection.record
            state["mirror_centers"][record.axis] = record.center
            _set_axis(record.axis)
            cmds.floatField(
                CTRL_TOLERANCE,
                edit=True,
                value=record.tolerance,
            )
            _sync_axis_controls()
            message = "Loaded {} with {} persistent vertex pairs.".format(
                _short_name(selected.mesh_transform),
                record.pair_count,
            )
        elif inspection.stale:
            message = (
                "Loaded {} with obsolete Mirror registry. Preview and replace "
                "the pairing."
            ).format(_short_name(selected.mesh_transform))
        else:
            message = "Loaded {}. Run Preview Pairing.".format(
                _short_name(selected.mesh_transform)
            )

        _sync_register_pairing_button()
        _set_status(message)
        _TOOL_WINDOW._info(message)
    except Exception as exc:
        _TOOL_WINDOW._show_error(exc)


def reset_controls() -> None:
    try:
        _TOOL_WINDOW._require_not_busy()
        _state().update(
            {
                "mirror_mesh_shape": None,
                "mirror_mesh_transform": None,
                "mirror_centers": dict(_DEFAULT_CENTERS),
                "mirror_preflight": None,
                "mirror_left_marker": "",
                "mirror_right_marker": "",
            }
        )
        cmds.radioButtonGrp(CTRL_AXIS, edit=True, select=1)
        cmds.radioButtonGrp(CTRL_DIRECTION, edit=True, select=1)
        cmds.floatField(
            CTRL_TOLERANCE,
            edit=True,
            value=_DEFAULT_TOLERANCE,
        )
        _sync_axis_controls()
        _sync_mirror_mesh_field()
        _sync_side_marker_fields()
        _sync_register_pairing_button()
        _set_status("")
        _TOOL_WINDOW._info("Mirror controls and active Mirror Mesh reset.")
    except Exception as exc:
        _TOOL_WINDOW._show_error(exc)


def register_selected_center() -> None:
    try:
        _TOOL_WINDOW._require_not_busy()
        _require_mirror_mesh()
        state = _state()
        axis = _query_axis()
        value = reference.register_center_from_selection(
            mesh_shape=state["mirror_mesh_shape"],
            mesh_transform=state["mirror_mesh_transform"],
            axis=axis,
        )
        state["mirror_centers"][axis] = float(value)
        cmds.floatField(
            CTRL_CENTER_FIELD,
            edit=True,
            value=float(value),
        )
        cmds.select(clear=True)
        _invalidate_preview(clear_status=False)
        message = "Registered {} = {:.6f}.".format(
            _AXIS_CENTER_LABEL[axis], value
        )
        _set_status(message)
        _TOOL_WINDOW._info(message)
    except Exception as exc:
        _TOOL_WINDOW._show_error(exc)


@gate.protected(gate.MIRROR_PREVIEW)
def preview_pairing() -> None:
    """Preview only the whole-object persistent geometry registry."""

    try:
        _TOOL_WINDOW._require_not_busy()
        _require_mirror_mesh()
        state = _state()

        _set_mirror_busy(
            True,
            "Calculating bind-reference geometry pairs...",
        )
        with _wait_cursor():
            preflight = operation.build_preflight(
                mesh_shape=state["mirror_mesh_shape"],
                mesh_transform=state["mirror_mesh_transform"],
                options=_query_options(),
            )

        state["mirror_preflight"] = preflight
        operation.print_preflight_report(preflight)
        _set_status(_preflight_status(preflight))
        _select_preview_problems(preflight)
        if preflight.valid:
            _TOOL_WINDOW._info(
                "Geometry preview complete: {} vertex pairs.".format(
                    len(preflight.paired_target_vertex_ids)
                )
            )
        else:
            cmds.warning(_preflight_status(preflight))
    except Exception as exc:
        _state()["mirror_preflight"] = None
        _TOOL_WINDOW._show_error(exc)
    finally:
        _set_mirror_busy(False)


@gate.protected(gate.MIRROR_REGISTER)
def register_pairing() -> None:
    try:
        _TOOL_WINDOW._require_not_busy()
        _require_mirror_mesh()
        state = _state()
        preview = state.get("mirror_preflight")
        if preview is None:
            raise RuntimeError("Run Preview Pairing before Register Pairing.")
        if not preview.valid:
            raise RuntimeError(
                "Preview is incomplete. Resolve unmatched or ambiguous vertices "
                "before registration."
            )

        inspection = registered_pairing.inspect(state["mirror_mesh_shape"])
        replacing = inspection.valid or inspection.stale
        if replacing and not _confirm_replace_pairing(inspection, preview):
            return

        _set_mirror_busy(
            True,
            (
                "Replacing persistent pairing..."
                if replacing
                else "Registering persistent pairing..."
            ),
        )
        with _wait_cursor():
            record = registered_pairing.register_preflight(preview)

        state["mirror_preflight"] = None
        message = "Registered Pairing {}: {} pairs on {}.".format(
            "replaced" if replacing else "created",
            record.pair_count,
            _short_name(preview.mesh_transform),
        )
        _sync_register_pairing_button()
        _set_status(message)
        _TOOL_WINDOW._info(message)
    except Exception as exc:
        _TOOL_WINDOW._show_error(exc)
    finally:
        _set_mirror_busy(False)


@gate.protected(gate.MIRROR_APPLY)
def apply_mirror() -> None:
    """Mirror registered vertex pairs using literal Side Marker identity."""

    try:
        _TOOL_WINDOW._require_not_busy()
        _require_mirror_mesh()
        left_marker, right_marker = _query_side_markers()
        state = _state()

        _set_mirror_busy(
            True,
            "Mirroring registered vertices with name-only influence pairing...",
        )
        with _wait_cursor():
            geometry = registered_pairing.build_preflight(
                mesh_shape=state["mirror_mesh_shape"],
                mesh_transform=state["mirror_mesh_transform"],
                direction=_query_direction(),
            )
            result = operation.mirror_skin_weights(
                geometry,
                left_marker=left_marker,
                right_marker=right_marker,
            )

        operation.print_mirror_report(result)
        _set_status(_mirror_result_status(result))
        _select_unresolved_result_sources(result)
        _TOOL_WINDOW._info(
            "Persistent mirror complete: {} changed target vertices.".format(
                result.mirrored_vertex_count
            )
        )
        _request_weight_preview_refresh()
    except Exception as exc:
        _TOOL_WINDOW._show_error(exc)
    finally:
        _set_mirror_busy(False)


def _confirm_replace_pairing(inspection, preview) -> bool:
    old_description = (
        "{} registered pairs".format(inspection.record.pair_count)
        if inspection.valid
        else "obsolete Registered Pairing data"
    )
    result = cmds.confirmDialog(
        title="Replace Registered Pairing?",
        message=(
            "The loaded Mirror Mesh contains {}.\n\n"
            "Replace it with the current Preview containing {} pairs?"
        ).format(
            old_description,
            len(preview.paired_target_vertex_ids),
        ),
        button=["Cancel", "Replace Pairing"],
        defaultButton="Replace Pairing",
        cancelButton="Cancel",
        dismissString="Cancel",
        icon="warning",
    )
    return result == "Replace Pairing"


def _query_options() -> operation.MirrorOptions:
    tolerance = float(
        cmds.floatField(CTRL_TOLERANCE, query=True, value=True)
    )
    pairing.validate_tolerance(tolerance)
    return operation.MirrorOptions(
        axis=_query_axis(),
        direction=_query_direction(),
        center=float(
            cmds.floatField(
                CTRL_CENTER_FIELD,
                query=True,
                value=True,
            )
        ),
        tolerance=tolerance,
    )


def _query_side_markers():
    left = cmds.textField(CTRL_LEFT_MARKER, query=True, text=True)
    right = cmds.textField(CTRL_RIGHT_MARKER, query=True, text=True)
    left, right = influence_pairing.validate_side_markers(
        left,
        right,
        required=True,
    )
    _state()["mirror_left_marker"] = left
    _state()["mirror_right_marker"] = right
    return left, right


def _query_direction() -> str:
    selected = cmds.radioButtonGrp(
        CTRL_DIRECTION,
        query=True,
        select=True,
    )
    if selected == 1:
        return pairing.DIRECTION_POSITIVE_TO_NEGATIVE
    return pairing.DIRECTION_NEGATIVE_TO_POSITIVE


def _query_axis() -> str:
    selected = int(
        cmds.radioButtonGrp(CTRL_AXIS, query=True, select=True)
    )
    return _AXIS_ORDER[selected - 1]


def _set_axis(axis: str) -> None:
    if cmds.radioButtonGrp(CTRL_AXIS, exists=True):
        cmds.radioButtonGrp(
            CTRL_AXIS,
            edit=True,
            select=_AXIS_ORDER.index(str(axis)) + 1,
        )


def _on_axis_changed() -> None:
    _sync_axis_controls()
    _invalidate_preview()


def _on_direction_changed() -> None:
    _invalidate_preview()


def _on_side_markers_changed() -> None:
    if not cmds.textField(CTRL_LEFT_MARKER, exists=True):
        return
    _state()["mirror_left_marker"] = cmds.textField(
        CTRL_LEFT_MARKER,
        query=True,
        text=True,
    ).strip()
    _state()["mirror_right_marker"] = cmds.textField(
        CTRL_RIGHT_MARKER,
        query=True,
        text=True,
    ).strip()


def _sync_axis_controls() -> None:
    if not cmds.radioButtonGrp(CTRL_AXIS, exists=True):
        return
    axis = _query_axis()
    cmds.text(
        CTRL_CENTER_LABEL,
        edit=True,
        label=_AXIS_CENTER_LABEL[axis],
    )
    cmds.radioButtonGrp(
        CTRL_DIRECTION,
        edit=True,
        labelArray2=_AXIS_DIRECTIONS[axis],
    )
    value = float(
        _state().get("mirror_centers", {}).get(axis, 0.0)
    )
    cmds.floatField(
        CTRL_CENTER_FIELD,
        edit=True,
        value=value,
    )


def _sync_mirror_mesh_field() -> None:
    if cmds.textField(CTRL_MIRROR_MESH_FIELD, exists=True):
        transform = _state().get("mirror_mesh_transform")
        cmds.textField(
            CTRL_MIRROR_MESH_FIELD,
            edit=True,
            text=(
                _short_name(transform)
                if transform
                else "<No Mirror Mesh>"
            ),
        )


def _sync_side_marker_fields() -> None:
    if cmds.textField(CTRL_LEFT_MARKER, exists=True):
        cmds.textField(
            CTRL_LEFT_MARKER,
            edit=True,
            text=str(_state().get("mirror_left_marker", "")),
        )
    if cmds.textField(CTRL_RIGHT_MARKER, exists=True):
        cmds.textField(
            CTRL_RIGHT_MARKER,
            edit=True,
            text=str(_state().get("mirror_right_marker", "")),
        )


def _sync_register_pairing_button() -> None:
    if not cmds.button(CTRL_REGISTER_PAIRING, exists=True):
        return
    mesh_shape = _state().get("mirror_mesh_shape")
    replacing = False
    if mesh_shape:
        inspection = registered_pairing.inspect(mesh_shape)
        replacing = inspection.valid or inspection.stale
    cmds.button(
        CTRL_REGISTER_PAIRING,
        edit=True,
        label=(
            "Replace Pairing..."
            if replacing
            else "Register Pairing"
        ),
    )


def _on_center_edited() -> None:
    _state()["mirror_centers"][_query_axis()] = float(
        cmds.floatField(
            CTRL_CENTER_FIELD,
            query=True,
            value=True,
        )
    )
    _invalidate_preview()


def _invalidate_preview(clear_status=True) -> None:
    if _TOOL_WINDOW is None:
        return
    _state()["mirror_preflight"] = None
    if clear_status:
        _set_status(_registered_status())


def _set_common_enabled(enabled) -> None:
    for control_type, control in (
        (cmds.button, CTRL_RESET),
        (cmds.button, CTRL_LOAD_MIRROR_MESH),
        (cmds.radioButtonGrp, CTRL_AXIS),
        (cmds.radioButtonGrp, CTRL_DIRECTION),
        (cmds.floatField, CTRL_CENTER_FIELD),
        (cmds.button, CTRL_REGISTER_CENTER),
        (cmds.floatField, CTRL_TOLERANCE),
        (cmds.textField, CTRL_LEFT_MARKER),
        (cmds.textField, CTRL_RIGHT_MARKER),
        (cmds.button, CTRL_PREVIEW),
        (cmds.button, CTRL_REGISTER_PAIRING),
        (cmds.button, CTRL_MIRROR),
    ):
        if control_type(control, exists=True):
            control_type(
                control,
                edit=True,
                enable=bool(enabled),
            )
    if cmds.button(CTRL_TRANSFER, exists=True):
        cmds.button(CTRL_TRANSFER, edit=True, enable=False)


def _set_mirror_busy(busy, status="") -> None:
    _state()["busy"] = bool(busy)
    if _SKIN_OPERATIONS is not None:
        _SKIN_OPERATIONS._set_common_enabled(not busy)
    if busy:
        _set_status(status)
    try:
        cmds.refresh(force=True)
    except Exception:
        pass


def _require_mirror_mesh() -> None:
    mesh_shape = _state().get("mirror_mesh_shape")
    if not mesh_shape:
        raise RuntimeError(
            "No Mirror Mesh loaded. Select a polygon mesh or component, "
            "then click Load Mirror Mesh."
        )
    if not cmds.objExists(mesh_shape):
        raise RuntimeError("Loaded Mirror Mesh no longer exists.")


def _registered_status() -> str:
    mesh_shape = _state().get("mirror_mesh_shape")
    if not mesh_shape:
        return ""
    inspection = registered_pairing.inspect(mesh_shape)
    if inspection.stale:
        return "Registered Pairing is obsolete. Preview and replace it."
    if not inspection.valid:
        return ""
    return "Persistent Pairing available: {} pairs on {}.".format(
        inspection.record.pair_count,
        _short_name(_state().get("mirror_mesh_transform")),
    )


def _preflight_status(preflight) -> str:
    protected = registered_pairing.inspect(preflight.mesh_shape).valid
    note = (
        " Existing Registered Pairing remains unchanged."
        if protected
        else ""
    )
    return (
        "Preview: {} legal pairs, {} center, {} unmatched, "
        "{} ambiguous. Max error {:.6f}.{}"
    ).format(
        len(preflight.paired_target_vertex_ids),
        len(preflight.center_vertex_ids),
        len(preflight.unmatched_target_vertex_ids),
        len(preflight.ambiguous_target_vertex_ids),
        preflight.maximum_vertex_pair_distance,
        note,
    )


def _mirror_result_status(result) -> str:
    scope = (
        "Component Source"
        if result.component_mode
        else "Whole Object"
    )
    return "Mirror complete: {} target vertices ({})".format(
        result.mirrored_vertex_count,
        scope,
    )


def _select_preview_problems(preflight) -> None:
    unresolved = tuple(
        sorted(
            set(preflight.unmatched_target_vertex_ids)
            | set(preflight.ambiguous_target_vertex_ids)
        )
    )
    if unresolved:
        _select_mesh_vertices(
            preflight.mesh_transform,
            unresolved,
        )
    else:
        cmds.select(clear=True)


def _select_unresolved_result_sources(result) -> None:
    if result.component_mode and result.unresolved_source_vertex_ids:
        _select_mesh_vertices(
            result.mesh_transform,
            result.unresolved_source_vertex_ids,
        )


def _select_mesh_vertices(mesh_transform: str, vertex_ids) -> None:
    components = _compressed_vertex_components(mesh_transform, vertex_ids)
    if components:
        cmds.select(components, replace=True)


def _compressed_vertex_components(mesh_transform: str, vertex_ids):
    ids = tuple(sorted(set(int(value) for value in vertex_ids)))
    if not ids:
        return ()

    components = []
    start = ids[0]
    end = start
    for vertex_id in ids[1:]:
        if vertex_id == end + 1:
            end = vertex_id
            continue
        components.append(_vertex_component(mesh_transform, start, end))
        start = vertex_id
        end = vertex_id
    components.append(_vertex_component(mesh_transform, start, end))
    return tuple(components)


def _vertex_component(mesh_transform: str, start: int, end: int) -> str:
    if start == end:
        return "{}.vtx[{}]".format(mesh_transform, start)
    return "{}.vtx[{}:{}]".format(mesh_transform, start, end)


def _set_status(message: str) -> None:
    if cmds.text(CTRL_STATUS, exists=True):
        cmds.text(
            CTRL_STATUS,
            edit=True,
            label=str(message),
            visible=bool(message),
        )


def _request_weight_preview_refresh() -> None:
    callback = _state().get("skin_weight_mode_refresh")
    if callable(callback):
        callback()


def _short_name(path) -> str:
    return (
        str(path).rsplit("|", 1)[-1]
        if path
        else "<No Mirror Mesh>"
    )


@contextmanager
def _wait_cursor():
    active = False
    try:
        cmds.waitCursor(state=True)
        active = True
        cmds.refresh(force=True)
        yield
    finally:
        if active:
            try:
                cmds.waitCursor(state=False)
            except Exception:
                pass


def _state():
    return _TOOL_WINDOW._STATE
