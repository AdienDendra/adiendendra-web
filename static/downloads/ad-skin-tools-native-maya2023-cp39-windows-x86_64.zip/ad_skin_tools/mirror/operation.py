"""Persistent Mirror geometry registration and skin-weight execution."""

from dataclasses import dataclass
from typing import Optional, Sequence, Tuple

import maya.cmds as cmds

from ad_skin_tools.core import component_selection
from ad_skin_tools.core.compat import ensure_numpy
from ad_skin_tools.core.influence_lock import locked_influences
from ad_skin_tools.core.skin_cluster import SkinClusterAdapter
from ad_skin_tools.core.undoable_skin_weights import apply_undoable_weights
from ad_skin_tools.mirror import influence_pairing, pairing, reference


np = ensure_numpy()
SCOPE_WHOLE_OBJECT = "whole_object"
SCOPE_COMPONENT_SOURCE = "component_source"
_INFLUENCE_ACTIVITY_EPSILON = 1.0e-12
_WEIGHT_CHANGE_EPSILON = 1.0e-12


@dataclass(frozen=True)
class MirrorOptions:
    axis: str
    direction: str
    center: float
    tolerance: float

    @property
    def signature(self) -> Tuple[str, str, float, float]:
        return (
            str(self.axis),
            str(self.direction),
            float(self.center),
            float(self.tolerance),
        )


@dataclass(frozen=True)
class MirrorPreflight:
    """Geometry-only correspondence suitable for persistent registration."""

    mesh_shape: str
    mesh_transform: str
    options: MirrorOptions
    registration_method: str
    scope: str
    requested_source_vertex_ids: Tuple[int, ...]
    source_component_count: int
    ignored_component_count: int
    source_vertex_ids: Tuple[int, ...]
    target_vertex_ids: Tuple[int, ...]
    center_vertex_ids: Tuple[int, ...]
    paired_target_vertex_ids: Tuple[int, ...]
    paired_source_vertex_ids: Tuple[int, ...]
    unmatched_target_vertex_ids: Tuple[int, ...]
    ambiguous_target_vertex_ids: Tuple[int, ...]
    unmatched_source_vertex_ids: Tuple[int, ...]
    ambiguous_source_vertex_ids: Tuple[int, ...]
    maximum_vertex_pair_distance: float

    @property
    def component_mode(self) -> bool:
        return self.scope == SCOPE_COMPONENT_SOURCE

    @property
    def unresolved_source_vertex_ids(self) -> Tuple[int, ...]:
        return tuple(
            sorted(
                set(self.unmatched_source_vertex_ids)
                | set(self.ambiguous_source_vertex_ids)
            )
        )

    @property
    def unresolved_target_vertex_ids(self) -> Tuple[int, ...]:
        return tuple(
            sorted(
                set(self.unmatched_target_vertex_ids)
                | set(self.ambiguous_target_vertex_ids)
            )
        )

    @property
    def valid(self) -> bool:
        return bool(
            self.paired_target_vertex_ids
            and len(self.paired_target_vertex_ids)
            == len(self.paired_source_vertex_ids)
            and not self.unresolved_target_vertex_ids
            and len(set(self.paired_source_vertex_ids))
            == len(self.paired_source_vertex_ids)
            and len(set(self.paired_target_vertex_ids))
            == len(self.paired_target_vertex_ids)
            and not (
                set(self.paired_source_vertex_ids)
                & set(self.paired_target_vertex_ids)
            )
        )

    @property
    def complete(self) -> bool:
        return self.valid

    @property
    def signature(self):
        return (
            self.mesh_shape,
            self.options.signature,
            self.registration_method,
        )


@dataclass(frozen=True)
class _ExecutionPairs:
    scope: str
    requested_source_vertex_ids: Tuple[int, ...]
    source_component_count: int
    ignored_component_count: int
    source_vertex_ids: Tuple[int, ...]
    target_vertex_ids: Tuple[int, ...]
    center_source_vertex_ids: Tuple[int, ...]
    unmatched_source_vertex_ids: Tuple[int, ...]

    @property
    def component_mode(self) -> bool:
        return self.scope == SCOPE_COMPONENT_SOURCE


@dataclass(frozen=True)
class _ScopedInfluenceResolution:
    mapping: Tuple[int, ...]
    active_columns: Tuple[int, ...]
    active_marker_resolved_columns: Tuple[int, ...]
    active_shared_columns: Tuple[int, ...]
    ignored_inactive_unmatched_columns: Tuple[int, ...]
    ignored_inactive_ambiguous_columns: Tuple[int, ...]
    source_weights: object


@dataclass(frozen=True)
class MirrorResult:
    mesh_shape: str
    mesh_transform: str
    skin_cluster: str
    scope: str
    axis: str
    direction: str
    center: float
    tolerance: float
    requested_source_vertex_ids: Tuple[int, ...]
    center_source_vertex_ids: Tuple[int, ...]
    unmatched_source_vertex_ids: Tuple[int, ...]
    ambiguous_source_vertex_ids: Tuple[int, ...]
    ignored_component_count: int
    writable_vertex_ids: Tuple[int, ...]
    mirrored_vertex_ids: Tuple[int, ...]
    fully_locked_vertex_ids: Tuple[int, ...]
    empty_donor_vertex_ids: Tuple[int, ...]
    locked_influences: Tuple[str, ...]
    influence_count: int
    active_donor_influence_count: int
    marker_resolved_influence_count: int
    shared_active_influence_count: int
    ignored_inactive_unmatched_influence_count: int
    ignored_inactive_ambiguous_influence_count: int

    @property
    def component_mode(self) -> bool:
        return self.scope == SCOPE_COMPONENT_SOURCE

    @property
    def writable_vertex_count(self) -> int:
        return len(self.writable_vertex_ids)

    @property
    def mirrored_vertex_count(self) -> int:
        """Return the number of target rows whose weights actually changed."""

        return len(self.mirrored_vertex_ids)

    @property
    def unresolved_source_vertex_ids(self) -> Tuple[int, ...]:
        return tuple(
            sorted(
                set(self.unmatched_source_vertex_ids)
                | set(self.ambiguous_source_vertex_ids)
            )
        )


def build_preflight(
    mesh_shape: str,
    mesh_transform: str,
    options: MirrorOptions,
    component_source_vertex_ids: Optional[Sequence[int]] = None,
    source_component_count: int = 0,
    ignored_component_count: int = 0,
) -> MirrorPreflight:
    """Build one whole-object geometry pairing for persistent storage."""

    del component_source_vertex_ids, source_component_count, ignored_component_count
    positions, registration_method = reference.registration_mesh_positions(
        mesh_shape
    )
    partition = pairing.partition_vertex_sides(
        positions=positions,
        axis=options.axis,
        center=options.center,
        tolerance=options.tolerance,
        direction=options.direction,
    )
    vertex_pairing = pairing.pair_mirrored_vertices(
        positions=positions,
        source_ids=partition.source_ids,
        target_ids=partition.target_ids,
        axis=options.axis,
        center=options.center,
        tolerance=options.tolerance,
    )
    return MirrorPreflight(
        mesh_shape=mesh_shape,
        mesh_transform=mesh_transform,
        options=options,
        registration_method=registration_method,
        scope=SCOPE_WHOLE_OBJECT,
        requested_source_vertex_ids=(),
        source_component_count=0,
        ignored_component_count=0,
        source_vertex_ids=_tuple_ids(partition.source_ids),
        target_vertex_ids=_tuple_ids(partition.target_ids),
        center_vertex_ids=_tuple_ids(partition.center_ids),
        paired_target_vertex_ids=_tuple_ids(vertex_pairing.target_ids),
        paired_source_vertex_ids=_tuple_ids(vertex_pairing.source_ids),
        unmatched_target_vertex_ids=_tuple_ids(
            vertex_pairing.unmatched_target_ids
        ),
        ambiguous_target_vertex_ids=_tuple_ids(
            vertex_pairing.ambiguous_target_ids
        ),
        unmatched_source_vertex_ids=(),
        ambiguous_source_vertex_ids=(),
        maximum_vertex_pair_distance=float(
            vertex_pairing.maximum_distance
        ),
    )


def mirror_skin_weights(
    preflight: MirrorPreflight,
    left_marker: str = "",
    right_marker: str = "",
) -> MirrorResult:
    """Mirror weights using registered vertex IDs and name-only influence identity."""

    if not preflight.valid:
        raise RuntimeError("Registered geometry pairing is invalid.")
    if not cmds.objExists(preflight.mesh_shape):
        raise RuntimeError("Loaded Mirror Mesh no longer exists.")

    left_marker, right_marker = influence_pairing.validate_side_markers(
        left_marker,
        right_marker,
        required=True,
    )
    execution = _resolve_execution_pairs(preflight)
    source_ids = np.asarray(execution.source_vertex_ids, dtype=np.int32)
    target_ids = np.asarray(execution.target_vertex_ids, dtype=np.int32)
    if not source_ids.size or source_ids.size != target_ids.size:
        raise RuntimeError("Mirror resolved no valid source-to-target rows.")
    if len(set(source_ids.tolist())) != len(source_ids):
        raise RuntimeError("Mirror source vertex IDs are not unique.")
    if len(set(target_ids.tolist())) != len(target_ids):
        raise RuntimeError("Mirror target vertex IDs are not unique.")
    if set(source_ids.tolist()) & set(target_ids.tolist()):
        raise RuntimeError(
            "Selected Component Source contains both sides of the same mirror "
            "region. Select donor components from one side only."
        )

    try:
        adapter = SkinClusterAdapter.from_mesh(preflight.mesh_shape)
    except Exception as exc:
        raise RuntimeError(
            "Mirror Skin Weights requires the loaded Mirror Mesh to have an "
            "existing skinCluster. The Registered Pairing remains available."
        ) from exc

    influences = tuple(adapter.influences())
    if not influences:
        raise RuntimeError("The resolved skinCluster has no influences.")

    source_data = adapter.get_weights(source_ids)
    target_data = adapter.get_weights(target_ids)
    if tuple(source_data.influences) != influences:
        raise RuntimeError("Source weight columns changed during Mirror.")
    if tuple(target_data.influences) != influences:
        raise RuntimeError("Target weight columns changed during Mirror.")
    source_weights = np.asarray(source_data.weights, dtype=np.float64)
    before = np.asarray(target_data.weights, dtype=np.float64).copy()

    resolved_influences = influence_pairing.resolve_mirrored_influences(
        influence_names=influences,
        left_marker=left_marker,
        right_marker=right_marker,
    )
    scoped = _scope_influence_resolution(
        resolved=resolved_influences,
        source_weights=source_weights,
        influences=influences,
    )

    locked = tuple(locked_influences(adapter.skin_cluster, influences))
    column_by_joint = {
        joint: column for column, joint in enumerate(influences)
    }
    locked_columns = tuple(
        column_by_joint[joint]
        for joint in locked
        if joint in column_by_joint
    )
    projection = pairing.project_mirrored_weight_rows(
        source_weights=scoped.source_weights,
        target_before=before,
        target_column_by_source=scoped.mapping,
        locked_columns=locked_columns,
    )

    writable_mask = np.asarray(projection.writable_row_mask, dtype=bool)
    writable_target_ids = target_ids[writable_mask]
    writable_before = before[writable_mask]
    writable_after = np.asarray(
        projection.weights[writable_mask], dtype=np.float64
    )
    if not writable_target_ids.size:
        raise RuntimeError(
            "Mirror found no writable target vertices. All paired rows are "
            "fully locked or contain no mirrored donor weight."
        )

    changed_mask = _changed_weight_row_mask(
        writable_before,
        writable_after,
    )
    changed_target_ids = writable_target_ids[changed_mask]
    changed_before = writable_before[changed_mask]
    changed_after = writable_after[changed_mask]

    if changed_target_ids.size:
        selection_before = cmds.ls(selection=True, long=True) or []
        mutation_recorded = False
        try:
            apply_undoable_weights(
                skin_cluster=adapter.skin_cluster,
                mesh_shape=preflight.mesh_shape,
                vertex_ids=changed_target_ids,
                before_weights=changed_before,
                after_weights=changed_after,
            )
            mutation_recorded = True
            _validate_written_rows(
                adapter,
                changed_target_ids,
                changed_after,
            )
        except Exception:
            if mutation_recorded:
                try:
                    cmds.undo()
                except Exception:
                    pass
            raise
        finally:
            _restore_selection(selection_before)

    fully_locked_ids = target_ids[
        np.asarray(projection.fully_locked_row_mask, dtype=bool)
    ]
    empty_donor_ids = target_ids[
        np.asarray(projection.empty_donor_row_mask, dtype=bool)
    ]
    return MirrorResult(
        mesh_shape=preflight.mesh_shape,
        mesh_transform=preflight.mesh_transform,
        skin_cluster=adapter.skin_cluster,
        scope=execution.scope,
        axis=preflight.options.axis,
        direction=preflight.options.direction,
        center=preflight.options.center,
        tolerance=preflight.options.tolerance,
        requested_source_vertex_ids=execution.requested_source_vertex_ids,
        center_source_vertex_ids=execution.center_source_vertex_ids,
        unmatched_source_vertex_ids=execution.unmatched_source_vertex_ids,
        ambiguous_source_vertex_ids=(),
        ignored_component_count=execution.ignored_component_count,
        writable_vertex_ids=_tuple_ids(writable_target_ids),
        mirrored_vertex_ids=_tuple_ids(changed_target_ids),
        fully_locked_vertex_ids=_tuple_ids(fully_locked_ids),
        empty_donor_vertex_ids=_tuple_ids(empty_donor_ids),
        locked_influences=locked,
        influence_count=len(influences),
        active_donor_influence_count=len(scoped.active_columns),
        marker_resolved_influence_count=len(
            scoped.active_marker_resolved_columns
        ),
        shared_active_influence_count=len(scoped.active_shared_columns),
        ignored_inactive_unmatched_influence_count=len(
            scoped.ignored_inactive_unmatched_columns
        ),
        ignored_inactive_ambiguous_influence_count=len(
            scoped.ignored_inactive_ambiguous_columns
        ),
    )


def print_preflight_report(preflight: MirrorPreflight) -> None:
    print("\n[AD Skin Tool - Persistent Geometry Preview]")
    print("Mesh:", preflight.mesh_transform)
    print("Registration method:", preflight.registration_method)
    print("Scope: Whole Object")
    print("Axis:", preflight.options.axis)
    print("Direction:", preflight.options.direction)
    print("Source vertices:", len(preflight.source_vertex_ids))
    print("Target vertices:", len(preflight.target_vertex_ids))
    print("Center vertices:", len(preflight.center_vertex_ids))
    print("Matched vertices:", len(preflight.paired_target_vertex_ids))
    print("Unmatched vertices:", len(preflight.unmatched_target_vertex_ids))
    print("Ambiguous vertices:", len(preflight.ambiguous_target_vertex_ids))
    print("Center:", preflight.options.center)
    print("Tolerance:", preflight.options.tolerance)
    print("Maximum vertex error:", preflight.maximum_vertex_pair_distance)
    print("Valid:", preflight.valid)
    print("Complete:", preflight.complete)


def print_mirror_report(result: MirrorResult) -> None:
    print("\n[AD Skin Tool - Mirror Skin Weights]")
    print("Mesh:", result.mesh_transform)
    print("SkinCluster:", result.skin_cluster)
    print(
        "Scope:",
        "Component Source" if result.component_mode else "Whole Object",
    )
    print("Axis:", result.axis)
    if result.component_mode:
        print("Direction: ignored - selected components were used as source")
        print(
            "Selected source vertices:",
            len(result.requested_source_vertex_ids),
        )
        print(
            "Center source vertices ignored:",
            len(result.center_source_vertex_ids),
        )
        print(
            "Unmatched selected vertices:",
            len(result.unmatched_source_vertex_ids),
        )
        print(
            "Other/unsupported components ignored:",
            result.ignored_component_count,
        )
    else:
        print("Direction:", result.direction)
    print("Center:", result.center)
    print("Writable target vertices:", result.writable_vertex_count)
    print("Changed target vertices:", result.mirrored_vertex_count)
    print("Influences:", result.influence_count)
    print("Active donor influences:", result.active_donor_influence_count)
    print(
        "Side-marker paired active influences:",
        result.marker_resolved_influence_count,
    )
    print(
        "Shared/self active influences:",
        result.shared_active_influence_count,
    )
    print(
        "Inactive unmatched influences ignored:",
        result.ignored_inactive_unmatched_influence_count,
    )
    print(
        "Inactive ambiguous influences ignored:",
        result.ignored_inactive_ambiguous_influence_count,
    )
    print("Locked influences:", len(result.locked_influences))
    print(
        "Fully locked target vertices:",
        len(result.fully_locked_vertex_ids),
    )
    print(
        "Empty donor target vertices:",
        len(result.empty_donor_vertex_ids),
    )


def _scope_influence_resolution(
    resolved,
    source_weights,
    influences: Sequence[str],
) -> _ScopedInfluenceResolution:
    """Require legal name pairs only for donor-active source columns.

    A skinCluster may contain ambiguous influences that contribute nothing to the
    selected donor rows. Those columns cannot affect the projected result and do
    not block Component Mirror. Tiny unresolved numerical residue is explicitly
    zeroed before projection.
    """

    source = np.asarray(source_weights, dtype=np.float64)
    if source.ndim != 2:
        raise ValueError("Source weights must be a two-dimensional matrix.")
    if source.shape[1] != len(influences):
        raise ValueError(
            "Source weight columns do not match the influence list."
        )
    if not np.all(np.isfinite(source)):
        raise ValueError("Source weights contain non-finite values.")

    activity = np.max(np.abs(source), axis=0)
    active_columns = tuple(
        int(column)
        for column in np.where(
            activity > _INFLUENCE_ACTIVITY_EPSILON
        )[0].tolist()
    )
    if not active_columns:
        raise RuntimeError(
            "Selected donor vertices contain no active skin influences."
        )

    active_set = set(active_columns)
    unmatched_set = set(int(value) for value in resolved.unmatched_columns)
    ambiguous_set = set(int(value) for value in resolved.ambiguous_columns)
    active_unmatched = tuple(sorted(active_set & unmatched_set))
    active_ambiguous = tuple(sorted(active_set & ambiguous_set))

    if active_unmatched or active_ambiguous:
        unresolved = tuple(sorted(set(active_unmatched) | set(active_ambiguous)))
        names = [
            influences[column]
            for column in unresolved[:20]
            if 0 <= column < len(influences)
        ]
        raise RuntimeError(
            "Side-marker influence pairing is incomplete for active donor "
            "weights.\n\n"
            "Active unmatched columns: {}\n"
            "Active ambiguous columns: {}\n"
            "First active influences:\n{}\n\n"
            "Inactive unresolved influences do not block Mirror.\n"
            "No weights were changed.".format(
                len(active_unmatched),
                len(active_ambiguous),
                "\n".join(names),
            )
        )

    ignored_unmatched = tuple(sorted(unmatched_set - active_set))
    ignored_ambiguous = tuple(sorted(ambiguous_set - active_set))
    ignored_unresolved = tuple(
        sorted(set(ignored_unmatched) | set(ignored_ambiguous))
    )

    mapping = [
        int(value) for value in resolved.target_column_by_source
    ]
    scoped_source = source.copy()
    for column in ignored_unresolved:
        mapping[column] = int(column)
        scoped_source[:, column] = 0.0

    invalid_active = tuple(
        column
        for column in active_columns
        if mapping[column] < 0 or mapping[column] >= source.shape[1]
    )
    if invalid_active:
        raise RuntimeError(
            "Active donor influence mapping contains invalid target columns: "
            "{}".format(list(invalid_active[:20]))
        )

    active_marker_resolved = tuple(
        sorted(
            active_set
            & set(int(value) for value in resolved.name_resolved_columns)
        )
    )
    active_shared = tuple(
        sorted(
            active_set
            & set(int(value) for value in resolved.shared_columns)
        )
    )
    return _ScopedInfluenceResolution(
        mapping=tuple(mapping),
        active_columns=active_columns,
        active_marker_resolved_columns=active_marker_resolved,
        active_shared_columns=active_shared,
        ignored_inactive_unmatched_columns=ignored_unmatched,
        ignored_inactive_ambiguous_columns=ignored_ambiguous,
        source_weights=scoped_source,
    )


def _resolve_execution_pairs(
    preflight: MirrorPreflight,
) -> _ExecutionPairs:
    selection = component_selection.collect_selected_mesh_vertices(
        mesh_shape=preflight.mesh_shape,
        mesh_transform=preflight.mesh_transform,
    )
    requested = tuple(
        sorted(set(int(vertex_id) for vertex_id in selection.vertex_ids))
    )
    registered_sources = tuple(
        int(vertex_id) for vertex_id in preflight.paired_source_vertex_ids
    )
    registered_targets = tuple(
        int(vertex_id) for vertex_id in preflight.paired_target_vertex_ids
    )
    all_registered = set(registered_sources) | set(registered_targets)

    if not requested:
        if selection.ignored_components:
            raise RuntimeError(
                "No components from the loaded Mirror Mesh were selected."
            )
        return _ExecutionPairs(
            scope=SCOPE_WHOLE_OBJECT,
            requested_source_vertex_ids=(),
            source_component_count=0,
            ignored_component_count=0,
            source_vertex_ids=registered_sources,
            target_vertex_ids=registered_targets,
            center_source_vertex_ids=(),
            unmatched_source_vertex_ids=(),
        )

    if set(requested) == all_registered:
        return _ExecutionPairs(
            scope=SCOPE_WHOLE_OBJECT,
            requested_source_vertex_ids=(),
            source_component_count=0,
            ignored_component_count=0,
            source_vertex_ids=registered_sources,
            target_vertex_ids=registered_targets,
            center_source_vertex_ids=(),
            unmatched_source_vertex_ids=(),
        )

    pair_by_vertex = {}
    for source_id, target_id in zip(registered_sources, registered_targets):
        pair_by_vertex[source_id] = target_id
        pair_by_vertex[target_id] = source_id

    center_set = set(int(value) for value in preflight.center_vertex_ids)
    matched_sources = []
    matched_targets = []
    center_sources = []
    unmatched_sources = []
    for source_id in requested:
        target_id = pair_by_vertex.get(source_id)
        if target_id is not None:
            matched_sources.append(source_id)
            matched_targets.append(target_id)
        elif source_id in center_set:
            center_sources.append(source_id)
        else:
            unmatched_sources.append(source_id)

    if not matched_sources:
        raise RuntimeError(
            "Selected components contain no registered non-center source "
            "vertices."
        )
    return _ExecutionPairs(
        scope=SCOPE_COMPONENT_SOURCE,
        requested_source_vertex_ids=requested,
        source_component_count=selection.source_component_count,
        ignored_component_count=selection.ignored_component_count,
        source_vertex_ids=tuple(matched_sources),
        target_vertex_ids=tuple(matched_targets),
        center_source_vertex_ids=tuple(center_sources),
        unmatched_source_vertex_ids=tuple(unmatched_sources),
    )


def _changed_weight_row_mask(before, after):
    """Return rows with a meaningful calculated weight change."""

    before = np.asarray(before, dtype=np.float64)
    after = np.asarray(after, dtype=np.float64)
    if before.shape != after.shape or before.ndim != 2:
        raise ValueError(
            "Before/after weight matrices must be matching two-dimensional arrays."
        )
    if not np.all(np.isfinite(before)) or not np.all(np.isfinite(after)):
        raise ValueError("Before/after weight matrices contain non-finite values.")
    if not before.shape[0]:
        return np.zeros(0, dtype=bool)
    return np.any(
        np.abs(after - before) > _WEIGHT_CHANGE_EPSILON,
        axis=1,
    )


def _validate_written_rows(adapter, vertex_ids, expected) -> None:
    stored = np.asarray(
        adapter.get_weights(vertex_ids).weights, dtype=np.float64
    )
    expected = np.asarray(expected, dtype=np.float64)
    tolerance = 1.0e-8
    if not np.all(np.isfinite(stored)):
        raise RuntimeError("Mirror stored non-finite skin weights.")
    if not np.allclose(stored, expected, rtol=0.0, atol=tolerance):
        changed = np.where(
            np.any(np.abs(stored - expected) > tolerance, axis=1)
        )[0][:20]
        raise RuntimeError(
            "Mirror did not store the calculated rows. First vertex IDs: {}"
            .format(vertex_ids[changed].tolist())
        )


def _restore_selection(selection) -> None:
    existing = [item for item in selection if cmds.objExists(item)]
    if existing:
        cmds.select(existing, replace=True)
    else:
        cmds.select(clear=True)


def _tuple_ids(values) -> Tuple[int, ...]:
    return tuple(
        int(value) for value in np.asarray(values).reshape(-1).tolist()
    )
