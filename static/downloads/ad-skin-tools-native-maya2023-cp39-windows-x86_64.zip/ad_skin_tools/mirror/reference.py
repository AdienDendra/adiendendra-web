"""Registration geometry and bind-reference helpers for persistent Mirror."""

import re
from typing import List, Tuple

import maya.api.OpenMaya as om
import maya.cmds as cmds

from ad_skin_tools.core.compat import ensure_numpy
from ad_skin_tools.core.mesh import get_dag_path
from ad_skin_tools.core.skin_cluster import SkinClusterAdapter, has_skin_cluster
from ad_skin_tools.mirror.pairing import axis_index


np = ensure_numpy()
_VERTEX_PATTERN = re.compile(r"\.vtx\[(\d+)\]$")
_SUPPORTED_COMPONENT_MARKERS = (".vtx[", ".e[", ".f[")

REGISTRATION_BIND_REFERENCE = "bind_reference"
REGISTRATION_NEUTRAL_CURRENT = "neutral_current"


def registration_mesh_positions(mesh_shape: str) -> Tuple[object, str]:
    """Use pre-skin positions when bound, otherwise current neutral geometry."""

    if not has_skin_cluster(mesh_shape):
        return current_mesh_positions(mesh_shape), REGISTRATION_NEUTRAL_CURRENT
    adapter = SkinClusterAdapter.from_mesh(mesh_shape)
    return (
        bind_mesh_positions(mesh_shape, adapter.skin_cluster),
        REGISTRATION_BIND_REFERENCE,
    )


def current_mesh_positions(mesh_shape: str):
    dag_path = get_dag_path(mesh_shape)
    points = om.MFnMesh(dag_path).getPoints(om.MSpace.kWorld)
    return np.asarray(
        [[point.x, point.y, point.z] for point in points],
        dtype=np.float64,
    )


def bind_mesh_positions(mesh_shape: str, skin_cluster: str):
    """Return pre-skin vertex positions in bind-time world reference space."""

    adapter = SkinClusterAdapter(skin_cluster, mesh_shape)
    geometry_index = int(
        adapter.skin_fn.indexForOutputShape(adapter.mesh_dag_path.node())
    )
    object_positions = _input_object_positions(adapter, geometry_index)
    bind_matrix = _geometry_bind_matrix(adapter.skin_cluster)
    positions = _transform_positions(object_positions, bind_matrix)
    if positions.shape[0] != adapter.vertex_count():
        raise RuntimeError(
            "Pre-skin reference vertex count does not match the loaded mesh: "
            "{} != {}".format(positions.shape[0], adapter.vertex_count())
        )
    return positions


def register_center_from_selection(
    mesh_shape: str,
    mesh_transform: str,
    axis: str,
) -> float:
    """Average selected mesh components or transform pivots in registration space."""

    selected = cmds.ls(selection=True, flatten=True, long=True) or []
    if not selected:
        raise RuntimeError(
            "Select center vertices, edges, faces, or a transform/locator first."
        )

    positions, method = registration_mesh_positions(mesh_shape)
    component_items = [
        item
        for item in selected
        if any(marker in str(item) for marker in _SUPPORTED_COMPONENT_MARKERS)
    ]
    points: List[List[float]] = []
    accepted = [
        item
        for item in component_items
        if _component_belongs_to_mesh(item, mesh_shape, mesh_transform)
    ]
    if accepted:
        converted = cmds.polyListComponentConversion(accepted, toVertex=True) or []
        flattened = cmds.ls(converted, flatten=True, long=True) or []
        vertex_ids = sorted(
            {
                _vertex_id(item)
                for item in flattened
                if _component_belongs_to_mesh(
                    item, mesh_shape, mesh_transform
                )
                and _VERTEX_PATTERN.search(str(item))
            }
        )
        if vertex_ids:
            points.extend(positions[vertex_ids].tolist())

    component_bases = {str(item).split(".", 1)[0] for item in component_items}
    for item in selected:
        text = str(item)
        if "." in text and "[" in text:
            continue
        matches = cmds.ls(text, long=True) or []
        if not matches:
            continue
        node = matches[0]
        if node in component_bases:
            continue
        try:
            pivot = cmds.xform(
                node,
                query=True,
                worldSpace=True,
                rotatePivot=True,
            )
        except Exception:
            continue
        if not pivot or len(pivot) < 3:
            continue
        if method == REGISTRATION_BIND_REFERENCE:
            adapter = SkinClusterAdapter.from_mesh(mesh_shape)
            point = _current_world_point_to_bind_reference(
                pivot, mesh_shape, adapter.skin_cluster
            )
            points.append(point.tolist())
        else:
            points.append([float(pivot[0]), float(pivot[1]), float(pivot[2])])

    if not points:
        raise RuntimeError(
            "The selection did not contain usable components from the loaded "
            "Mirror Mesh or a valid transform/locator."
        )
    matrix = np.asarray(points, dtype=np.float64)
    return float(np.mean(matrix[:, axis_index(axis)]))


def _input_object_positions(adapter, geometry_index: int):
    try:
        input_object = adapter.skin_fn.inputShapeAtIndex(int(geometry_index))
        points = om.MFnMesh(input_object).getPoints(om.MSpace.kObject)
        return np.asarray(
            [[point.x, point.y, point.z] for point in points],
            dtype=np.float64,
        )
    except Exception:
        pass

    input_plug = "{}.input[{}].inputGeometry".format(
        adapter.skin_cluster, geometry_index
    )
    source_shapes = cmds.listConnections(
        input_plug,
        source=True,
        destination=False,
        shapes=True,
    ) or []
    for node in source_shapes:
        matches = cmds.ls(node, long=True, type="mesh") or []
        if not matches:
            continue
        points = om.MFnMesh(get_dag_path(matches[0])).getPoints(
            om.MSpace.kObject
        )
        return np.asarray(
            [[point.x, point.y, point.z] for point in points],
            dtype=np.float64,
        )
    raise RuntimeError(
        "Unable to resolve the pre-skin input geometry for {}.".format(
            adapter.mesh_shape
        )
    )


def _geometry_bind_matrix(skin_cluster: str):
    attribute = "{}.geomMatrix".format(skin_cluster)
    if not cmds.objExists(attribute):
        raise RuntimeError(
            "The skinCluster does not expose a bind-time geometry matrix:\n{}"
            .format(skin_cluster)
        )
    return om.MMatrix(_flatten_matrix_value(cmds.getAttr(attribute)))


def _transform_positions(positions, matrix):
    source = np.asarray(positions, dtype=np.float64)
    result = np.zeros_like(source)
    for row, value in enumerate(source):
        transformed = om.MPoint(
            float(value[0]), float(value[1]), float(value[2])
        ) * matrix
        result[row] = (transformed.x, transformed.y, transformed.z)
    return result


def _current_world_point_to_bind_reference(
    point,
    mesh_shape: str,
    skin_cluster: str,
):
    current_matrix = get_dag_path(mesh_shape).inclusiveMatrix()
    bind_matrix = _geometry_bind_matrix(skin_cluster)
    world_point = om.MPoint(float(point[0]), float(point[1]), float(point[2]))
    object_point = world_point * current_matrix.inverse()
    bind_point = object_point * bind_matrix
    return np.asarray(
        [bind_point.x, bind_point.y, bind_point.z],
        dtype=np.float64,
    )


def _flatten_matrix_value(value):
    current = value
    while isinstance(current, (list, tuple)) and len(current) == 1:
        current = current[0]
    if not isinstance(current, (list, tuple)) or len(current) != 16:
        raise RuntimeError("Matrix attribute did not return a 4x4 value.")
    return [float(item) for item in current]


def _component_belongs_to_mesh(
    component: str,
    mesh_shape: str,
    mesh_transform: str,
) -> bool:
    base = str(component).split(".", 1)[0]
    matches = cmds.ls(base, long=True) or []
    if not matches:
        return False
    node = matches[0]
    if node in (mesh_shape, mesh_transform):
        return True
    if cmds.nodeType(node) == "mesh":
        parents = cmds.listRelatives(node, parent=True, fullPath=True) or []
        return bool(parents) and parents[0] == mesh_transform
    return False


def _vertex_id(component: str) -> int:
    match = _VERTEX_PATTERN.search(str(component))
    if match is None:
        raise ValueError("Not a flattened vertex component: {}".format(component))
    return int(match.group(1))
