"""Persistent reflected-position vertex correspondence for Mirror weights."""

from dataclasses import dataclass
import hashlib
from typing import Optional, Sequence, Tuple

import maya.api.OpenMaya as om
import maya.cmds as cmds

from ad_skin_tools.mirror import operation, pairing, reference


REGISTRY_ABSENT = "absent"
REGISTRY_VALID = "valid"
REGISTRY_STALE = "stale"
_STORAGE_VERSION = 4

_ATTR_VERSION = "adMirrorPairingVersion"
_ATTR_COMMITTED = "adMirrorPairingCommitted"
_ATTR_METHOD = "adMirrorPairingMethod"
_ATTR_AXIS = "adMirrorPairingAxis"
_ATTR_CENTER = "adMirrorPairingCenter"
_ATTR_TOLERANCE = "adMirrorPairingTolerance"
_ATTR_VERTEX_COUNT = "adMirrorPairingVertexCount"
_ATTR_CENTER_IDS = "adMirrorCenterVertexIds"
_ATTR_POSITIVE_IDS = "adMirrorPositiveVertexIds"
_ATTR_NEGATIVE_IDS = "adMirrorNegativeVertexIds"
_ATTR_CHECKSUM = "adMirrorPairingChecksum"

_CORE_ATTRS = (
    _ATTR_METHOD,
    _ATTR_AXIS,
    _ATTR_CENTER,
    _ATTR_TOLERANCE,
    _ATTR_VERTEX_COUNT,
    _ATTR_CENTER_IDS,
    _ATTR_POSITIVE_IDS,
    _ATTR_NEGATIVE_IDS,
    _ATTR_CHECKSUM,
)
_ALL_ATTRS = (_ATTR_VERSION, _ATTR_COMMITTED) + _CORE_ATTRS
_LEGACY_ATTRS = ("adMirrorSeamEdgeIds",)


@dataclass(frozen=True)
class RegisteredPairing:
    mesh_shape: str
    method: str
    axis: str
    center: float
    tolerance: float
    vertex_count: int
    center_vertex_ids: Tuple[int, ...]
    positive_vertex_ids: Tuple[int, ...]
    negative_vertex_ids: Tuple[int, ...]
    checksum: str

    @property
    def pair_count(self) -> int:
        return len(self.positive_vertex_ids)


@dataclass(frozen=True)
class RegistryInspection:
    status: str
    record: Optional[RegisteredPairing] = None
    detail: str = ""

    @property
    def absent(self) -> bool:
        return self.status == REGISTRY_ABSENT

    @property
    def valid(self) -> bool:
        return self.status == REGISTRY_VALID and self.record is not None

    @property
    def stale(self) -> bool:
        return self.status == REGISTRY_STALE


def register_preflight(
    preflight: operation.MirrorPreflight,
) -> RegisteredPairing:
    """Persist one complete geometry Preview without skin data."""

    if not preflight.valid:
        raise RuntimeError(
            "Geometry Preview is incomplete and cannot be registered."
        )

    if preflight.options.direction == pairing.DIRECTION_POSITIVE_TO_NEGATIVE:
        positive_ids = tuple(preflight.paired_source_vertex_ids)
        negative_ids = tuple(preflight.paired_target_vertex_ids)
    elif preflight.options.direction == pairing.DIRECTION_NEGATIVE_TO_POSITIVE:
        positive_ids = tuple(preflight.paired_target_vertex_ids)
        negative_ids = tuple(preflight.paired_source_vertex_ids)
    else:
        raise ValueError(
            "Unsupported mirror direction: {}".format(
                preflight.options.direction
            )
        )

    vertex_count = int(cmds.polyEvaluate(preflight.mesh_shape, vertex=True))
    checksum = compute_checksum(
        method=preflight.registration_method,
        axis=preflight.options.axis,
        center=preflight.options.center,
        tolerance=preflight.options.tolerance,
        vertex_count=vertex_count,
        center_vertex_ids=preflight.center_vertex_ids,
        positive_vertex_ids=positive_ids,
        negative_vertex_ids=negative_ids,
    )
    record = RegisteredPairing(
        mesh_shape=preflight.mesh_shape,
        method=preflight.registration_method,
        axis=preflight.options.axis,
        center=float(preflight.options.center),
        tolerance=float(preflight.options.tolerance),
        vertex_count=vertex_count,
        center_vertex_ids=tuple(preflight.center_vertex_ids),
        positive_vertex_ids=positive_ids,
        negative_vertex_ids=negative_ids,
        checksum=checksum,
    )
    _write(record)
    return load_strict(preflight.mesh_shape)


def inspect(mesh_shape: str) -> RegistryInspection:
    if not mesh_shape or not cmds.objExists(mesh_shape):
        return RegistryInspection(REGISTRY_ABSENT)

    version_exists = cmds.attributeQuery(
        _ATTR_VERSION, node=mesh_shape, exists=True
    )
    if version_exists:
        try:
            version = int(cmds.getAttr(_plug(mesh_shape, _ATTR_VERSION)))
        except Exception as exc:
            return RegistryInspection(REGISTRY_STALE, detail=str(exc))
        if version != _STORAGE_VERSION:
            return RegistryInspection(
                REGISTRY_STALE,
                detail=(
                    "Obsolete Registered Pairing version {}. Version {} uses "
                    "persistent reflected-position geometry."
                ).format(version, _STORAGE_VERSION),
            )

    existing = tuple(
        name
        for name in _ALL_ATTRS
        if cmds.attributeQuery(name, node=mesh_shape, exists=True)
    )
    if not existing:
        return RegistryInspection(REGISTRY_ABSENT)

    missing = tuple(name for name in _ALL_ATTRS if name not in existing)
    if missing:
        return RegistryInspection(
            REGISTRY_STALE,
            detail="Incomplete Registered Pairing attributes: {}.".format(
                ", ".join(missing)
            ),
        )

    try:
        if not bool(cmds.getAttr(_plug(mesh_shape, _ATTR_COMMITTED))):
            return RegistryInspection(
                REGISTRY_STALE,
                detail="Registered Pairing write was not completed.",
            )
        record = _read_record(mesh_shape)
        _validate_record(record)
    except Exception as exc:
        return RegistryInspection(REGISTRY_STALE, detail=str(exc))
    return RegistryInspection(REGISTRY_VALID, record=record)


def load(mesh_shape: str):
    return inspect(mesh_shape).record


def load_strict(mesh_shape: str) -> RegisteredPairing:
    inspection = inspect(mesh_shape)
    if inspection.valid:
        return inspection.record
    if inspection.stale:
        raise RuntimeError(
            "Registered Pairing is obsolete or invalid.\n\n{}\n\n"
            "Run Preview Pairing and Replace Pairing.".format(
                inspection.detail or "The registry could not be read."
            )
        )
    raise RuntimeError(
        "No persistent Registered Pairing exists on the loaded Mirror Mesh.\n\n"
        "Register the center, run Preview Pairing, then Register Pairing."
    )


def clear_storage(mesh_shape: str) -> None:
    if not mesh_shape or not cmds.objExists(mesh_shape):
        return
    for name in reversed(_ALL_ATTRS + _LEGACY_ATTRS):
        if not cmds.attributeQuery(name, node=mesh_shape, exists=True):
            continue
        plug = _plug(mesh_shape, name)
        try:
            cmds.setAttr(plug, lock=False)
        except Exception:
            pass
        cmds.deleteAttr(plug)


def topology_matches(record: RegisteredPairing) -> bool:
    return bool(
        record
        and cmds.objExists(record.mesh_shape)
        and int(cmds.polyEvaluate(record.mesh_shape, vertex=True))
        == int(record.vertex_count)
    )


def build_preflight(
    mesh_shape: str,
    mesh_transform: str,
    direction: str,
) -> operation.MirrorPreflight:
    """Create execution geometry from registry without recalculating pairs."""

    record = load_strict(mesh_shape)
    current_count = int(cmds.polyEvaluate(mesh_shape, vertex=True))
    if current_count != record.vertex_count:
        raise RuntimeError(
            "Registered Pairing vertex count changed: {} != {}. "
            "Replace Pairing.".format(record.vertex_count, current_count)
        )

    source_ids, target_ids = oriented_vertex_pairs(record, direction)
    options = operation.MirrorOptions(
        axis=record.axis,
        direction=direction,
        center=record.center,
        tolerance=record.tolerance,
    )
    return operation.MirrorPreflight(
        mesh_shape=mesh_shape,
        mesh_transform=mesh_transform,
        options=options,
        registration_method=record.method,
        scope=operation.SCOPE_WHOLE_OBJECT,
        requested_source_vertex_ids=(),
        source_component_count=0,
        ignored_component_count=0,
        source_vertex_ids=source_ids,
        target_vertex_ids=target_ids,
        center_vertex_ids=record.center_vertex_ids,
        paired_target_vertex_ids=target_ids,
        paired_source_vertex_ids=source_ids,
        unmatched_target_vertex_ids=(),
        ambiguous_target_vertex_ids=(),
        unmatched_source_vertex_ids=(),
        ambiguous_source_vertex_ids=(),
        maximum_vertex_pair_distance=0.0,
    )


def oriented_vertex_pairs(
    record: RegisteredPairing,
    direction: str,
) -> Tuple[Tuple[int, ...], Tuple[int, ...]]:
    if direction == pairing.DIRECTION_POSITIVE_TO_NEGATIVE:
        return record.positive_vertex_ids, record.negative_vertex_ids
    if direction == pairing.DIRECTION_NEGATIVE_TO_POSITIVE:
        return record.negative_vertex_ids, record.positive_vertex_ids
    raise ValueError("Unsupported mirror direction: {}".format(direction))


def compute_checksum(
    method: str,
    axis: str,
    center: float,
    tolerance: float,
    vertex_count: int,
    center_vertex_ids: Sequence[int],
    positive_vertex_ids: Sequence[int],
    negative_vertex_ids: Sequence[int],
) -> str:
    digest = hashlib.sha256()
    scalars = (
        str(method),
        str(axis),
        "{:.17g}".format(float(center)),
        "{:.17g}".format(float(tolerance)),
        str(int(vertex_count)),
    )
    digest.update("\x1f".join(scalars).encode("utf-8"))
    for values in (
        center_vertex_ids,
        positive_vertex_ids,
        negative_vertex_ids,
    ):
        digest.update(b"\x1e")
        digest.update(
            ",".join(str(int(value)) for value in values).encode("ascii")
        )
    return digest.hexdigest()


def _write(record: RegisteredPairing) -> None:
    _validate_record(record)
    previous = inspect(record.mesh_shape)
    previous_record = previous.record if previous.valid else None
    replacing = previous.valid or previous.stale

    opened = False
    try:
        cmds.undoInfo(
            openChunk=True,
            chunkName=(
                "AD Replace Mirror Pairing"
                if replacing
                else "AD Register Mirror Pairing"
            ),
        )
        opened = True
        if previous.stale:
            clear_storage(record.mesh_shape)
        _ensure_attributes(record.mesh_shape)
        _set_commit_state(record.mesh_shape, False)
        cmds.setAttr(
            _plug(record.mesh_shape, _ATTR_VERSION),
            int(_STORAGE_VERSION),
        )
        _write_payload(record)
        stored = _read_record(record.mesh_shape)
        _validate_record(stored)
        if not _records_equal(record, stored):
            raise RuntimeError(
                "Registered Pairing verification failed after scene write."
            )
        _set_commit_state(record.mesh_shape, True)
        committed = inspect(record.mesh_shape)
        if not committed.valid or not _records_equal(
            record, committed.record
        ):
            raise RuntimeError(
                "Registered Pairing did not reach a committed valid state."
            )
    except Exception:
        try:
            clear_storage(record.mesh_shape)
            if previous_record is not None:
                _ensure_attributes(record.mesh_shape)
                cmds.setAttr(
                    _plug(record.mesh_shape, _ATTR_VERSION),
                    int(_STORAGE_VERSION),
                )
                _write_payload(previous_record)
                _set_commit_state(record.mesh_shape, True)
        except Exception:
            pass
        raise
    finally:
        if opened:
            cmds.undoInfo(closeChunk=True)


def _write_payload(record: RegisteredPairing) -> None:
    cmds.setAttr(
        _plug(record.mesh_shape, _ATTR_METHOD),
        record.method,
        type="string",
    )
    cmds.setAttr(
        _plug(record.mesh_shape, _ATTR_AXIS),
        record.axis,
        type="string",
    )
    cmds.setAttr(
        _plug(record.mesh_shape, _ATTR_CENTER),
        float(record.center),
    )
    cmds.setAttr(
        _plug(record.mesh_shape, _ATTR_TOLERANCE),
        float(record.tolerance),
    )
    cmds.setAttr(
        _plug(record.mesh_shape, _ATTR_VERTEX_COUNT),
        int(record.vertex_count),
    )
    _set_int_array(
        _plug(record.mesh_shape, _ATTR_CENTER_IDS),
        record.center_vertex_ids,
        allow_empty=True,
    )
    _set_int_array(
        _plug(record.mesh_shape, _ATTR_POSITIVE_IDS),
        record.positive_vertex_ids,
    )
    _set_int_array(
        _plug(record.mesh_shape, _ATTR_NEGATIVE_IDS),
        record.negative_vertex_ids,
    )
    cmds.setAttr(
        _plug(record.mesh_shape, _ATTR_CHECKSUM),
        record.checksum,
        type="string",
    )


def _read_record(mesh_shape: str) -> RegisteredPairing:
    return RegisteredPairing(
        mesh_shape=mesh_shape,
        method=str(cmds.getAttr(_plug(mesh_shape, _ATTR_METHOD))),
        axis=str(cmds.getAttr(_plug(mesh_shape, _ATTR_AXIS))),
        center=float(cmds.getAttr(_plug(mesh_shape, _ATTR_CENTER))),
        tolerance=float(cmds.getAttr(_plug(mesh_shape, _ATTR_TOLERANCE))),
        vertex_count=int(
            cmds.getAttr(_plug(mesh_shape, _ATTR_VERTEX_COUNT))
        ),
        center_vertex_ids=_read_int_array(
            _plug(mesh_shape, _ATTR_CENTER_IDS)
        ),
        positive_vertex_ids=_read_int_array(
            _plug(mesh_shape, _ATTR_POSITIVE_IDS)
        ),
        negative_vertex_ids=_read_int_array(
            _plug(mesh_shape, _ATTR_NEGATIVE_IDS)
        ),
        checksum=str(
            cmds.getAttr(_plug(mesh_shape, _ATTR_CHECKSUM))
        ),
    )


def _ensure_attributes(mesh_shape: str) -> None:
    definitions = (
        (_ATTR_VERSION, {"attributeType": "long"}),
        (_ATTR_COMMITTED, {"attributeType": "bool"}),
        (_ATTR_METHOD, {"dataType": "string"}),
        (_ATTR_AXIS, {"dataType": "string"}),
        (_ATTR_CENTER, {"attributeType": "double"}),
        (_ATTR_TOLERANCE, {"attributeType": "double"}),
        (_ATTR_VERTEX_COUNT, {"attributeType": "long"}),
        (_ATTR_CENTER_IDS, {"dataType": "Int32Array"}),
        (_ATTR_POSITIVE_IDS, {"dataType": "Int32Array"}),
        (_ATTR_NEGATIVE_IDS, {"dataType": "Int32Array"}),
        (_ATTR_CHECKSUM, {"dataType": "string"}),
    )
    for name, kwargs in definitions:
        if not cmds.attributeQuery(name, node=mesh_shape, exists=True):
            cmds.addAttr(mesh_shape, longName=name, **kwargs)


def _set_commit_state(mesh_shape: str, committed: bool) -> None:
    cmds.setAttr(
        _plug(mesh_shape, _ATTR_COMMITTED),
        bool(committed),
    )


def _set_int_array(
    attribute: str,
    values: Sequence[int],
    allow_empty: bool = False,
) -> None:
    payload = tuple(int(value) for value in values)
    if not payload and not allow_empty:
        raise RuntimeError(
            "Cannot store an empty Registered Pairing side array."
        )
    data_object = om.MFnIntArrayData().create(payload)
    _api_plug(attribute).setMObject(data_object)


def _read_int_array(attribute: str) -> Tuple[int, ...]:
    try:
        data_object = _api_plug(attribute).asMObject()
        data = om.MFnIntArrayData(data_object)
    except (RuntimeError, TypeError):
        return ()
    return tuple(int(data[index]) for index in range(len(data)))


def _api_plug(attribute: str):
    selection = om.MSelectionList()
    selection.add(attribute)
    return selection.getPlug(0)


def _validate_record(record: RegisteredPairing) -> None:
    if record.method not in (
        reference.REGISTRATION_BIND_REFERENCE,
        reference.REGISTRATION_NEUTRAL_CURRENT,
    ):
        raise RuntimeError(
            "Registered Pairing method is unsupported: {}.".format(
                record.method
            )
        )
    pairing.axis_index(record.axis)
    pairing.validate_tolerance(record.tolerance)
    if record.vertex_count <= 0:
        raise RuntimeError("Registered Pairing has an invalid vertex count.")
    if not record.positive_vertex_ids:
        raise RuntimeError("Registered Pairing contains no vertex pairs.")
    if len(record.positive_vertex_ids) != len(record.negative_vertex_ids):
        raise RuntimeError("Registered Pairing arrays have different lengths.")

    all_ids = (
        record.center_vertex_ids
        + record.positive_vertex_ids
        + record.negative_vertex_ids
    )
    if all_ids and (
        min(all_ids) < 0 or max(all_ids) >= record.vertex_count
    ):
        raise RuntimeError("Registered Pairing contains invalid vertex IDs.")
    if len(set(record.center_vertex_ids)) != len(record.center_vertex_ids):
        raise RuntimeError("Registered Pairing contains duplicate center IDs.")
    if len(set(record.positive_vertex_ids)) != record.pair_count:
        raise RuntimeError("Registered Pairing contains duplicate positive IDs.")
    if len(set(record.negative_vertex_ids)) != record.pair_count:
        raise RuntimeError("Registered Pairing contains duplicate negative IDs.")

    positive = set(record.positive_vertex_ids)
    negative = set(record.negative_vertex_ids)
    center = set(record.center_vertex_ids)
    if positive & negative or positive & center or negative & center:
        raise RuntimeError("Registered Pairing vertex groups overlap.")

    expected_count = (
        len(record.center_vertex_ids)
        + len(record.positive_vertex_ids)
        + len(record.negative_vertex_ids)
    )
    if expected_count != record.vertex_count:
        raise RuntimeError(
            "Registered Pairing does not cover every vertex: {} != {}."
            .format(expected_count, record.vertex_count)
        )

    expected = compute_checksum(
        method=record.method,
        axis=record.axis,
        center=record.center,
        tolerance=record.tolerance,
        vertex_count=record.vertex_count,
        center_vertex_ids=record.center_vertex_ids,
        positive_vertex_ids=record.positive_vertex_ids,
        negative_vertex_ids=record.negative_vertex_ids,
    )
    if record.checksum != expected:
        raise RuntimeError(
            "Registered Pairing checksum does not match its data."
        )


def _records_equal(
    left: RegisteredPairing,
    right: RegisteredPairing,
) -> bool:
    return bool(
        left.mesh_shape == right.mesh_shape
        and left.method == right.method
        and left.axis == right.axis
        and float(left.center) == float(right.center)
        and float(left.tolerance) == float(right.tolerance)
        and int(left.vertex_count) == int(right.vertex_count)
        and left.center_vertex_ids == right.center_vertex_ids
        and left.positive_vertex_ids == right.positive_vertex_ids
        and left.negative_vertex_ids == right.negative_vertex_ids
        and left.checksum == right.checksum
    )


def _plug(node: str, attribute: str) -> str:
    return "{}.{}".format(node, attribute)
