"""Flood existing bound influences over component or whole-object scopes."""

from dataclasses import dataclass
from typing import Dict, Optional, Sequence, Tuple

import maya.cmds as cmds

from ad_skin_tools.bind_smoothing.diffusion import (
    MAXIMUM_BLEND,
    MAXIMUM_ITERATIONS,
    MINIMUM_BLEND,
    MINIMUM_ITERATIONS,
    WeightDiffusionResult,
)
from ad_skin_tools.components import smooth
from ad_skin_tools.components.flood_solver import solve_flood_rows
from ad_skin_tools.core import mesh
from ad_skin_tools.core.compat import ensure_numpy
from ad_skin_tools.core.influence_lock import locked_influences
from ad_skin_tools.core.skin_cluster import SkinClusterAdapter
from ad_skin_tools.core.undoable_skin_weights import apply_undoable_weights
from ad_skin_tools.core.weight_contract import canonicalize_existing_weights
from ad_skin_tools.region.ownership_pipeline import solve_ownership_pipeline


np = ensure_numpy()
FloodScope = smooth.ComponentSmoothScope


@dataclass(frozen=True)
class FloodResult:
    skin_cluster: str
    mesh_shape: str
    mesh_transform: str
    target_joints: Tuple[str, ...]
    ignored_pending_joints: Tuple[str, ...]
    selected_vertex_ids: Tuple[int, ...]
    assigned_vertex_ids: Tuple[int, ...]
    flooded_vertex_ids: Tuple[int, ...]
    skipped_empty_vertex_ids: Tuple[int, ...]
    skipped_locked_vertex_ids: Tuple[int, ...]
    affected_vertex_ids_by_joint: Dict[str, Tuple[int, ...]]
    locked_influences: Tuple[str, ...]
    blend: float
    iterations: int
    whole_object: bool
    soft_selection_enabled: bool
    soft_selection_used: bool
    ignored_component_count: int
    context_vertex_count: int
    diffusion_result: Optional[WeightDiffusionResult]

    @property
    def target_count(self) -> int:
        return len(self.target_joints)

    @property
    def selected_vertex_count(self) -> int:
        return len(self.selected_vertex_ids)

    @property
    def assigned_vertex_count(self) -> int:
        return len(self.assigned_vertex_ids)

    @property
    def flooded_vertex_count(self) -> int:
        return len(self.flooded_vertex_ids)


def collect_flood_scope(mesh_shape: str, mesh_transform: str) -> FloodScope:
    """Use the proven Smooth selection resolver for component/object scope."""

    return smooth.collect_smooth_scope(mesh_shape, mesh_transform)


def flood_skin_weights(
    scope: FloodScope,
    target_joints: Sequence[str],
    blend: float,
    iterations: int,
    global_owner_joint: Optional[str] = None,
    ignored_pending_joints: Sequence[str] = (),
) -> FloodResult:
    """Flood existing targets and optionally diffuse only their affected rows."""

    blend, iterations = _validated_options(blend, iterations)
    selection_before = cmds.ls(selection=True, long=True) or []
    adapter = SkinClusterAdapter.from_mesh(scope.mesh_shape)
    influences = tuple(adapter.influences())
    targets = _normalize_bound_targets(target_joints, influences)
    active_locked = locked_influences(adapter.skin_cluster, influences)

    locked_targets = tuple(joint for joint in targets if joint in active_locked)
    if locked_targets:
        raise RuntimeError(
            "Unlock the selected Flood target influence(s):\n{}".format(
                "\n".join(locked_targets)
            )
        )

    affected_ids, target_by_vertex, affected_by_joint = _resolve_assignment(
        scope,
        influences,
        targets,
        global_owner_joint,
    )
    context_ids, affected_rows, adjacency = _build_context(
        scope.mesh_shape,
        affected_ids,
        iterations,
    )

    if context_ids.size:
        weight_data = adapter.get_weights(context_ids)
        if tuple(weight_data.influences) != influences:
            raise RuntimeError("Flood influence order changed during the weight read.")
        baseline_before = np.asarray(
            weight_data.weights,
            dtype=np.float64,
        ).copy()
        baseline = canonicalize_existing_weights(
            baseline_before,
            row_ids=context_ids,
            influence_names=influences,
            label="Flood baseline weights",
        )
    else:
        baseline_before = np.empty((0, len(influences)), dtype=np.float64)
        baseline = baseline_before.copy()

    falloff_by_vertex = np.zeros(mesh.get_vertex_count(scope.mesh_shape), dtype=np.float64)
    scope_ids = np.asarray(scope.vertex_ids, dtype=np.int32)
    scope_falloffs = np.asarray(scope.selection_falloffs, dtype=np.float64)
    if scope_ids.size != scope_falloffs.size:
        raise RuntimeError("Flood scope falloff data is inconsistent.")
    falloff_by_vertex[scope_ids] = np.clip(scope_falloffs, 0.0, 1.0)

    locked_columns = tuple(
        influences.index(joint)
        for joint in active_locked
        if joint in influences
    )
    calculation = solve_flood_rows(
        baseline=baseline,
        affected_rows=affected_rows,
        affected_vertex_ids=affected_ids,
        target_columns=target_by_vertex[affected_ids],
        falloff_weights=falloff_by_vertex[affected_ids],
        adjacency=adjacency,
        locked_columns=locked_columns,
        blend=blend,
        iterations=iterations,
    )

    try:
        if calculation.changed_vertex_ids.size:
            changed_rows = smooth._rows_for_vertex_ids(
                context_ids,
                calculation.changed_vertex_ids,
            )
            before_weights = baseline_before[changed_rows].copy()
            after_weights = calculation.weights[changed_rows].copy()
            apply_undoable_weights(
                skin_cluster=adapter.skin_cluster,
                mesh_shape=scope.mesh_shape,
                vertex_ids=calculation.changed_vertex_ids,
                before_weights=before_weights,
                after_weights=after_weights,
                locked_columns=locked_columns,
                enforce_write_contract=True,
                operation_name="Flood",
            )
    finally:
        smooth._restore_selection(selection_before)

    return FloodResult(
        skin_cluster=adapter.skin_cluster,
        mesh_shape=scope.mesh_shape,
        mesh_transform=scope.mesh_transform,
        target_joints=targets,
        ignored_pending_joints=tuple(str(joint) for joint in ignored_pending_joints),
        selected_vertex_ids=scope.vertex_ids,
        assigned_vertex_ids=tuple(int(value) for value in calculation.assigned_vertex_ids.tolist()),
        flooded_vertex_ids=tuple(int(value) for value in calculation.changed_vertex_ids.tolist()),
        skipped_empty_vertex_ids=tuple(
            int(value) for value in calculation.skipped_empty_vertex_ids.tolist()
        ),
        skipped_locked_vertex_ids=tuple(
            int(value) for value in calculation.skipped_locked_vertex_ids.tolist()
        ),
        affected_vertex_ids_by_joint=affected_by_joint,
        locked_influences=active_locked,
        blend=float(blend),
        iterations=int(iterations),
        whole_object=scope.whole_object,
        soft_selection_enabled=scope.soft_selection_enabled,
        soft_selection_used=scope.soft_selection_used,
        ignored_component_count=scope.ignored_component_count,
        context_vertex_count=int(context_ids.size),
        diffusion_result=calculation.diffusion_result,
    )


def print_flood_report(result: FloodResult) -> None:
    print("\n[AD Skin Tool - Flood]")
    print("Mesh:", result.mesh_transform)
    print("Whole object:", result.whole_object)
    print("Targets:", result.target_count)
    for joint in result.target_joints:
        print("  {}: {} assigned".format(
            joint,
            len(result.affected_vertex_ids_by_joint.get(joint, ())),
        ))
    print("Ignored pending joints:", len(result.ignored_pending_joints))
    print("Selected vertices:", result.selected_vertex_count)
    print("Assigned vertices:", result.assigned_vertex_count)
    print("Changed vertices:", result.flooded_vertex_count)
    print("Skipped empty vertices:", len(result.skipped_empty_vertex_ids))
    print("Skipped fully locked vertices:", len(result.skipped_locked_vertex_ids))
    print("Soft Selection used:", result.soft_selection_used)
    print("Blend:", result.blend)
    print("Iterations:", result.iterations)
    print("Context vertices:", result.context_vertex_count)


def _validated_options(blend, iterations):
    blend = float(blend)
    iterations = int(iterations)
    if blend < MINIMUM_BLEND or blend > MAXIMUM_BLEND:
        raise ValueError("Flood Blend must be between 0.0 and 1.0.")
    if iterations < MINIMUM_ITERATIONS or iterations > MAXIMUM_ITERATIONS:
        raise ValueError("Flood Iterations must be between 0 and 10.")
    return blend, iterations


def _normalize_bound_targets(target_joints, influences):
    influence_set = set(influences)
    resolved = []
    for joint in target_joints:
        matches = cmds.ls(joint, long=True, type="joint") or []
        if not matches:
            raise RuntimeError("Flood target joint no longer exists:\n{}".format(joint))
        target = matches[0]
        if target not in influence_set:
            raise RuntimeError(
                "Flood only edits existing bound influences. Use Add Influence for:\n{}"
                .format(target)
            )
        if target not in resolved:
            resolved.append(target)
    if not resolved:
        raise RuntimeError("Select at least one bound influence for Flood.")
    return tuple(resolved)


def _resolve_assignment(scope, influences, targets, global_owner_joint):
    vertex_count = mesh.get_vertex_count(scope.mesh_shape)
    target_by_vertex = np.full(vertex_count, -1, dtype=np.int32)
    column_by_joint = {joint: index for index, joint in enumerate(influences)}

    if scope.whole_object:
        if len(influences) == 1:
            target_by_vertex[:] = 0
        else:
            pipeline = solve_ownership_pipeline(
                mesh=scope.mesh_transform,
                joints=influences,
                global_owner_joint=(
                    global_owner_joint
                    if global_owner_joint in column_by_joint
                    else None
                ),
            )
            owners = np.asarray(pipeline.final_owner_indices, dtype=np.int32)
            if owners.shape != (vertex_count,):
                raise RuntimeError("Flood ownership returned an unexpected vertex count.")
            target_by_vertex[:] = owners
        selected_columns = np.asarray(
            [column_by_joint[joint] for joint in targets],
            dtype=np.int32,
        )
        target_by_vertex[~np.isin(target_by_vertex, selected_columns)] = -1
    else:
        scope_ids = np.asarray(scope.vertex_ids, dtype=np.int32)
        if len(targets) == 1:
            target_by_vertex[scope_ids] = column_by_joint[targets[0]]
        else:
            pipeline = solve_ownership_pipeline(
                mesh=scope.mesh_transform,
                joints=targets,
                global_owner_joint=(
                    global_owner_joint if global_owner_joint in targets else None
                ),
            )
            owners = np.asarray(pipeline.final_owner_indices, dtype=np.int32)
            if owners.shape != (vertex_count,):
                raise RuntimeError("Flood ownership returned an unexpected vertex count.")
            target_columns = np.asarray(
                [column_by_joint[joint] for joint in targets],
                dtype=np.int32,
            )
            target_by_vertex[scope_ids] = target_columns[owners[scope_ids]]

    affected_ids = np.where(target_by_vertex >= 0)[0].astype(np.int32)
    affected_by_joint = {
        joint: tuple(
            int(value)
            for value in np.where(
                target_by_vertex == column_by_joint[joint]
            )[0].astype(np.int32).tolist()
        )
        for joint in targets
    }
    return affected_ids, target_by_vertex, affected_by_joint


def _build_context(mesh_shape, affected_ids, iterations):
    affected = np.asarray(affected_ids, dtype=np.int32)
    if not affected.size:
        return np.empty(0, np.int32), np.empty(0, np.int32), tuple()
    if int(iterations) == 0:
        return (
            affected.copy(),
            np.arange(affected.size, dtype=np.int32),
            tuple(tuple() for _ in range(affected.size)),
        )

    selected_adjacency = mesh.get_vertex_neighbors(mesh_shape, affected)
    context_ids = smooth._build_context_vertex_ids(affected, selected_adjacency)
    affected_rows, neighbour_rows = smooth._build_context_row_mapping(
        mesh_shape,
        context_ids,
        affected,
        selected_adjacency,
    )
    adjacency = [tuple() for _ in range(context_ids.size)]
    for row, neighbours in zip(affected_rows.tolist(), neighbour_rows):
        adjacency[int(row)] = tuple(int(value) for value in neighbours.tolist())
    return context_ids, affected_rows, tuple(adjacency)


