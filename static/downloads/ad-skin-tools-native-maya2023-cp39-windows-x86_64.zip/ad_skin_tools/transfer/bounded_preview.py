"""Bounded exact sampling for captured Transfer Preview."""

import time
from typing import Sequence

from ad_skin_tools.core.compat import ensure_numpy
from ad_skin_tools.transfer import correspondence_reuse
from ad_skin_tools.transfer import nearest
from ad_skin_tools.transfer import operation
from ad_skin_tools.transfer import reference
from ad_skin_tools.transfer.selection import SourceRegistration, TargetRegistration


np = ensure_numpy()
_CULLED_DISTANCE = float(np.finfo(np.float64).max)


class _BoundedCapture:
    """Batch exact source queries per target vertex behind conservative bounds."""

    def __init__(self, build_surface, exact_sample):
        self._build_surface = build_surface
        self._exact_sample = exact_sample
        self.surfaces = []
        self.candidates = []
        self._prepared_samples = ()
        self.exact_query_count = 0
        self.culled_query_count = 0

    def build_source_surface(self, registration):
        surface = self._build_surface(registration)
        self.surfaces.append(surface)
        return surface

    def sample(self, surface, world_position, source_index):
        source_index = int(source_index)
        if source_index == 0:
            self._prepare_vertex(world_position)

        if (
            source_index < 0
            or source_index >= len(self._prepared_samples)
        ):
            raise RuntimeError(
                "Bounded Transfer sampling lost source-query ordering."
            )

        sample = self._prepared_samples[source_index]
        self.candidates.append(
            correspondence_reuse._CapturedCandidate(
                source_index=int(sample.source_index),
                source_mesh_shape=str(sample.source_mesh_shape),
                source_face_id=int(sample.source_face_id),
                source_point=tuple(
                    float(value)
                    for value in sample.source_point
                ),
                distance=float(sample.distance),
            )
        )
        return sample

    def _prepare_vertex(self, world_position):
        if not self.surfaces:
            raise RuntimeError(
                "Bounded Transfer sampling has no source surfaces."
            )

        query = np.asarray(
            world_position,
            dtype=np.float64,
        ).reshape(3)

        source_count = len(self.surfaces)
        if source_count == 1:
            sample = self._exact_sample(
                self.surfaces[0],
                query,
                0,
            )
            self.exact_query_count += 1
            self._prepared_samples = (sample,)
            return

        lower_bounds = np.asarray(
            [
                reference.source_lower_bound(
                    surface,
                    query,
                )
                for surface in self.surfaces
            ],
            dtype=np.float64,
        )

        order = np.lexsort(
            (
                np.arange(
                    source_count,
                    dtype=np.int32,
                ),
                lower_bounds,
            )
        )

        samples = [None] * source_count
        best = None

        for source_index in order.tolist():
            lower_bound = float(
                lower_bounds[source_index]
            )

            if (
                best is not None
                and lower_bound > best.distance
                and not nearest.distance_tied(
                    lower_bound,
                    best.distance,
                )
            ):
                self.culled_query_count += 1
                continue

            sample = self._exact_sample(
                self.surfaces[source_index],
                query,
                source_index,
            )
            self.exact_query_count += 1
            samples[source_index] = sample
            best = _better_sample(best, sample)

        if best is None:
            raise RuntimeError(
                "Bounded Transfer sampling produced no exact source sample."
            )

        for source_index, sample in enumerate(samples):
            if sample is not None:
                continue
            samples[source_index] = _culled_sample(
                self.surfaces[source_index],
                query,
                source_index,
            )

        self._prepared_samples = tuple(samples)


def build_preflight(
    source_registrations: Sequence[SourceRegistration],
    target_registrations: Sequence[TargetRegistration],
    debug_report: bool = False,
) -> correspondence_reuse.CapturedPreflight:
    """Build captured Preview with exact AABB/PCA-OBB source culling."""

    started = time.perf_counter()
    original_build = reference.build_source_surface
    original_sample = reference.closest_surface_sample
    capture = _BoundedCapture(
        build_surface=original_build,
        exact_sample=original_sample,
    )

    reference.build_source_surface = capture.build_source_surface
    reference.closest_surface_sample = capture.sample
    try:
        preflight = operation.build_preflight(
            source_registrations,
            target_registrations,
        )
    finally:
        reference.closest_surface_sample = original_sample
        reference.build_source_surface = original_build

    correspondence = correspondence_reuse._assemble_correspondence(
        preflight,
        tuple(capture.candidates),
    )

    total_candidates = (
        capture.exact_query_count
        + capture.culled_query_count
    )
    reduction = (
        100.0
        * capture.culled_query_count
        / total_candidates
        if total_candidates
        else 0.0
    )
    elapsed = float(time.perf_counter() - started)
    _print_user_summary(preflight, elapsed)
    if debug_report:
        _print_debug_report(capture, reduction)

    return correspondence_reuse.CapturedPreflight(
        preflight=preflight,
        correspondence=correspondence,
    )


def _print_user_summary(preflight, elapsed):
    status = (
        "Partial"
        if preflight.partial
        else "Valid"
        if preflight.valid
        else "Invalid"
    )
    print("\n[AD Skin Tool - Transfer Preview]")
    print(
        "Sources / targets: {} / {}".format(
            len(preflight.sources),
            len(preflight.target_plans),
        )
    )
    print(
        "Target vertices: {} requested | {} writable".format(
            preflight.requested_target_count,
            preflight.writable_target_count,
        )
    )
    print("Preview time: {:.3f}s".format(float(elapsed)))
    print("Status:", status)


def _print_debug_report(capture, reduction):
    print("\n[AD Skin Tool - Transfer Sampling Debug]")
    print("Exact source queries:", capture.exact_query_count)
    print("Safely culled queries:", capture.culled_query_count)
    print("Exact-query reduction: {:.2f}%".format(float(reduction)))


def _better_sample(current, candidate):
    if current is None:
        return candidate

    if nearest.distance_tied(
        candidate.distance,
        current.distance,
    ):
        if candidate.source_index < current.source_index:
            return candidate
        return current

    if candidate.distance < current.distance:
        return candidate

    return current


def _culled_sample(surface, query, source_index):
    return reference.SurfaceSample(
        source_index=int(source_index),
        source_mesh_shape=str(
            surface.registration.mesh_shape
        ),
        source_face_id=-1,
        source_point=tuple(
            float(value)
            for value in query.tolist()
        ),
        triangle_vertex_ids=(0, 0, 0),
        barycentric=(1.0, 0.0, 0.0),
        distance=_CULLED_DISTANCE,
    )
