"""Optimized preparation of the adaptive Transfer smoothing mask.

This implementation preserves the established detector and mask decisions while
removing Python work that is not needed by Component Smooth:

* source skin weights are never read because diagnostics only need geometry;
* source face neighbours are queried lazily and cached;
* target positions, weights, and adjacency are read once;
* edge weight/stretch metrics and reason masks are calculated with NumPy;
* EdgeDiagnostic objects are created only for suspicious edges;
* component acceptance evaluates direct bridge rows only on suspicious-edge
  endpoints, while the full repair domain is retained as the smoothing mask;
* the prepared mask is reusable by preview and apply.
"""

from dataclasses import dataclass
import time
from typing import Dict, Sequence, Tuple

import maya.api.OpenMaya as om

from ad_skin_tools.core.compat import ensure_numpy
from ad_skin_tools.core.mesh import get_all_vertex_neighbors, get_dag_path
from ad_skin_tools.core.skin_cluster import SkinClusterAdapter, find_skin_cluster
from ad_skin_tools.transfer import (
    boundary_mask_solver,
    diagnostic_solver,
    donor_diagnostics,
    reference,
)
from ad_skin_tools.transfer.data import DiagnosticThresholds


np = ensure_numpy()


@dataclass(frozen=True)
class TargetTimings:
    bind_positions: float
    weight_read: float
    adjacency: float
    donor_sampling: float
    source_face_queries: float
    edge_classification: float
    connected_components: float
    mask_construction: float
    total: float


@dataclass(frozen=True)
class PreparedTarget:
    mesh_shape: str
    mesh_transform: str
    skin_cluster: str
    vertex_count: int
    edge_count: int
    influence_paths: Tuple[str, ...]
    mask_vertex_ids: Tuple[int, ...]
    baseline_mask_weights: np.ndarray
    suspicious_edge_count: int
    accepted_component_count: int
    total_component_count: int
    component_results: Tuple[object, ...]
    timings: TargetTimings

    @property
    def mask_vertex_count(self) -> int:
        return len(self.mask_vertex_ids)


@dataclass(frozen=True)
class PreparedMask:
    source_mesh_shapes: Tuple[str, ...]
    source_mesh_transforms: Tuple[str, ...]
    targets: Tuple[PreparedTarget, ...]
    thresholds: DiagnosticThresholds
    source_setup_seconds: float
    total_seconds: float


@dataclass(frozen=True)
class _DiagnosticSurface:
    registration: object
    triangle_count: int
    world_positions: np.ndarray
    triangle_vertex_ids: np.ndarray
    triangle_offsets_by_face: np.ndarray
    intersector: object


class _LazySourceFaceTopology:
    """Query only source faces touched by bounded continuity checks."""

    def __init__(self, mesh_shape: str):
        self.mesh_shape = str(mesh_shape)
        self.dag_path = get_dag_path(self.mesh_shape)
        self.mesh_fn = om.MFnMesh(self.dag_path)
        self.face_count = int(self.mesh_fn.numPolygons)
        self.iterator = om.MItMeshPolygon(self.dag_path)
        self.neighbour_cache: Dict[int, Tuple[int, ...]] = {}
        self.distance_cache: Dict[Tuple[int, int, int], int] = {}
        self.query_seconds = 0.0

    @property
    def cached_face_count(self) -> int:
        return len(self.neighbour_cache)

    def neighbours(self, face_id: int) -> Tuple[int, ...]:
        face_id = int(face_id)
        cached = self.neighbour_cache.get(face_id)
        if cached is not None:
            return cached
        if face_id < 0 or face_id >= self.face_count:
            return tuple()

        started = time.perf_counter()
        self.iterator.setIndex(face_id)
        result = tuple(
            sorted(int(value) for value in self.iterator.getConnectedFaces())
        )
        self.query_seconds += float(time.perf_counter() - started)
        self.neighbour_cache[face_id] = result
        return result

    def bounded_ring_distance(
        self,
        face_a: int,
        face_b: int,
        maximum_rings: int,
    ) -> int:
        a = int(face_a)
        b = int(face_b)
        limit = int(maximum_rings)
        if a == b:
            return 0
        if (
            a < 0
            or b < 0
            or a >= self.face_count
            or b >= self.face_count
        ):
            return limit + 1

        key = (min(a, b), max(a, b), limit)
        cached = self.distance_cache.get(key)
        if cached is not None:
            return cached

        distance = _bounded_ring_distance(
            self.neighbours,
            a,
            b,
            limit,
        )
        self.distance_cache[key] = int(distance)
        return int(distance)


def prepare(
    source_meshes: Sequence[str],
    target_meshes: Sequence[str],
    thresholds: DiagnosticThresholds = DiagnosticThresholds(),
    report_component_limit: int = 30,
) -> PreparedMask:
    """Prepare an adaptive mask once without writing skin weights."""

    started = time.perf_counter()
    thresholds.validate()
    registrations = donor_diagnostics._source_registrations(source_meshes)
    targets = tuple(donor_diagnostics._resolve_mesh(value) for value in target_meshes)
    if not targets:
        raise RuntimeError("Provide at least one target mesh.")

    duplicate_targets = donor_diagnostics._duplicates(
        shape for shape, _transform in targets
    )
    if duplicate_targets:
        raise RuntimeError(
            "Target mesh list contains duplicates:\n{}".format(
                "\n".join(duplicate_targets)
            )
        )

    source_started = time.perf_counter()
    surfaces = tuple(_build_diagnostic_surface(item) for item in registrations)
    source_setup_seconds = float(time.perf_counter() - source_started)
    for surface in surfaces:
        if surface.triangle_count <= 0:
            raise RuntimeError(
                "Source mesh has no usable polygon triangles:\n{}".format(
                    surface.registration.mesh_shape
                )
            )

    prepared_targets = tuple(
        _prepare_target(
            target_shape=shape,
            target_transform=transform,
            source_surfaces=surfaces,
            thresholds=thresholds,
        )
        for shape, transform in targets
    )
    result = PreparedMask(
        source_mesh_shapes=tuple(
            surface.registration.mesh_shape for surface in surfaces
        ),
        source_mesh_transforms=tuple(
            surface.registration.mesh_transform for surface in surfaces
        ),
        targets=prepared_targets,
        thresholds=thresholds,
        source_setup_seconds=source_setup_seconds,
        total_seconds=float(time.perf_counter() - started),
    )
    print_report(result, report_component_limit)
    return result


def print_report(
    prepared: PreparedMask,
    component_limit: int = 30,
) -> None:
    print("\n[AD Skin Tool - Optimized Mask Prepare]")
    print("Mode: Diagnostic only")
    print("Source skin-weight read: disabled")
    print("Source face topology: lazy cached queries")
    print("Edge metrics: vectorized")
    print("Mask acceptance: endpoint-only direct evaluation")
    print("Prepared mask reusable for apply: yes")
    print("Source setup: {:.3f}s".format(prepared.source_setup_seconds))
    print("Total prepare time: {:.3f}s".format(prepared.total_seconds))

    for target in prepared.targets:
        t = target.timings
        print("\nTarget:", target.mesh_transform)
        print("  Vertices / edges:", target.vertex_count, "/", target.edge_count)
        print("  Suspicious edges:", target.suspicious_edge_count)
        print(
            "  Components accepted: {} / {}".format(
                target.accepted_component_count,
                target.total_component_count,
            )
        )
        print("  Mask vertices:", target.mask_vertex_count)
        print("  Timings:")
        print("    bind positions:       {:.3f}s".format(t.bind_positions))
        print("    target weight read:   {:.3f}s".format(t.weight_read))
        print("    target adjacency:     {:.3f}s".format(t.adjacency))
        print("    closest sampling:     {:.3f}s".format(t.donor_sampling))
        print("    source face queries:  {:.3f}s".format(t.source_face_queries))
        print("    edge classification:  {:.3f}s".format(t.edge_classification))
        print("    connected components: {:.3f}s".format(t.connected_components))
        print("    mask construction:    {:.3f}s".format(t.mask_construction))
        print("    target total:         {:.3f}s".format(t.total))

        accepted = sorted(
            (item for item in target.component_results if item.accepted),
            key=lambda item: (
                item.median_jump_after - item.median_jump_before,
                -item.repair_vertices,
                item.index,
            ),
        )
        if component_limit > 0 and accepted:
            print("  Strongest accepted components:")
            for item in accepted[: int(component_limit)]:
                print(
                    "    {} | edges={} | gap={:.6f} | half={:.6f} | "
                    "repair={} | jump {:.4f}->{:.4f}".format(
                        item.index,
                        item.suspicious_edges,
                        item.measured_gap,
                        item.half_width,
                        item.repair_vertices,
                        item.median_jump_before,
                        item.median_jump_after,
                    )
                )

        rejected: Dict[str, int] = {}
        for item in target.component_results:
            if item.accepted:
                continue
            rejected[item.status] = rejected.get(item.status, 0) + 1
        if rejected:
            print("  Rejected components:")
            for status in sorted(rejected):
                print("    {}: {}".format(status, rejected[status]))


def _prepare_target(
    target_shape,
    target_transform,
    source_surfaces,
    thresholds,
) -> PreparedTarget:
    target_started = time.perf_counter()
    skin_cluster = find_skin_cluster(target_shape, required=False)
    if not skin_cluster:
        raise RuntimeError(
            "Target requires the baseline Transfer skinCluster:\n{}".format(
                target_transform
            )
        )
    adapter = SkinClusterAdapter(str(skin_cluster), target_shape)

    stage = time.perf_counter()
    positions = np.asarray(
        reference.bind_mesh_positions(target_shape, adapter.skin_cluster),
        dtype=np.float64,
    )
    bind_positions_seconds = float(time.perf_counter() - stage)

    vertex_ids = np.arange(len(positions), dtype=np.int32)
    stage = time.perf_counter()
    skin_data = adapter.get_weights(vertex_ids)
    before = np.asarray(skin_data.weights, dtype=np.float64)
    influences = tuple(str(path) for path in skin_data.influences)
    weight_read_seconds = float(time.perf_counter() - stage)
    if before.shape[0] != len(positions):
        raise RuntimeError(
            "Target weight rows do not match target vertices:\n{}".format(
                target_transform
            )
        )

    stage = time.perf_counter()
    adjacency = tuple(
        tuple(int(value) for value in row)
        for row in get_all_vertex_neighbors(target_shape)
    )
    unique_edges = diagnostic_solver.unique_edges(adjacency)
    adjacency_seconds = float(time.perf_counter() - stage)
    if len(adjacency) != len(positions):
        raise RuntimeError(
            "Target adjacency does not match target vertices:\n{}".format(
                target_transform
            )
        )

    stage = time.perf_counter()
    donor_samples = donor_diagnostics._sample_target_vertices(
        positions,
        source_surfaces,
    )
    donor_sampling_seconds = float(time.perf_counter() - stage)

    (
        source_face_distances,
        source_face_query_seconds,
        source_face_classification_seconds,
    ) = (
        _capture_source_face_distances(
            unique_edges=unique_edges,
            donor_samples=donor_samples,
            source_surfaces=source_surfaces,
            maximum_rings=int(thresholds.maximum_source_face_rings),
        )
    )
    solution = boundary_mask_solver.solve_target_mask(
        unique_edges=unique_edges,
        positions=positions,
        weights=before,
        adjacency=adjacency,
        donor_samples=donor_samples,
        source_face_distances=source_face_distances,
        thresholds=thresholds,
        source_face_query_seconds=source_face_query_seconds,
    )

    timings = TargetTimings(
        bind_positions=bind_positions_seconds,
        weight_read=weight_read_seconds,
        adjacency=adjacency_seconds,
        donor_sampling=donor_sampling_seconds,
        source_face_queries=solution.source_face_query_seconds,
        edge_classification=(
            source_face_classification_seconds
            + solution.edge_classification_seconds
        ),
        connected_components=solution.connected_components_seconds,
        mask_construction=solution.mask_construction_seconds,
        total=float(time.perf_counter() - target_started),
    )
    return PreparedTarget(
        mesh_shape=str(target_shape),
        mesh_transform=str(target_transform),
        skin_cluster=str(skin_cluster),
        vertex_count=len(positions),
        edge_count=solution.edge_count,
        influence_paths=influences,
        mask_vertex_ids=solution.mask_vertex_ids,
        baseline_mask_weights=solution.baseline_mask_weights,
        suspicious_edge_count=solution.suspicious_edge_count,
        accepted_component_count=solution.accepted_component_count,
        total_component_count=solution.total_component_count,
        component_results=solution.component_results,
        timings=timings,
    )


def _capture_source_face_distances(
    unique_edges,
    donor_samples,
    source_surfaces,
    maximum_rings,
):
    """Capture bounded source-face distances through lazy Maya topology."""

    started = time.perf_counter()
    edge_vertices = np.asarray(unique_edges, dtype=np.int32).reshape(-1, 2)
    if not edge_vertices.size:
        return np.empty(0, dtype=np.int32), 0.0, float(
            time.perf_counter() - started
        )

    vertex_a = edge_vertices[:, 0]
    vertex_b = edge_vertices[:, 1]
    source_indices = np.fromiter(
        (int(sample.source_index) for sample in donor_samples),
        dtype=np.int32,
        count=len(donor_samples),
    )
    source_face_ids = np.fromiter(
        (int(sample.source_face_id) for sample in donor_samples),
        dtype=np.int32,
        count=len(donor_samples),
    )

    limit = int(maximum_rings)
    face_distances = np.full(
        edge_vertices.shape[0],
        limit + 1,
        dtype=np.int32,
    )
    same_source = source_indices[vertex_a] == source_indices[vertex_b]
    topologies: Dict[int, _LazySourceFaceTopology] = {}
    for edge_index in np.flatnonzero(same_source).tolist():
        source_index = int(source_indices[int(vertex_a[edge_index])])
        topology = topologies.get(source_index)
        if topology is None:
            topology = _LazySourceFaceTopology(
                source_surfaces[source_index].registration.mesh_shape
            )
            topologies[source_index] = topology
        face_distances[edge_index] = topology.bounded_ring_distance(
            int(source_face_ids[int(vertex_a[edge_index])]),
            int(source_face_ids[int(vertex_b[edge_index])]),
            limit,
        )

    query_seconds = float(sum(item.query_seconds for item in topologies.values()))
    total_seconds = float(time.perf_counter() - started)
    return (
        face_distances,
        query_seconds,
        max(0.0, total_seconds - query_seconds),
    )


def _build_diagnostic_surface(registration) -> _DiagnosticSurface:
    adapter = SkinClusterAdapter.from_mesh(registration.mesh_shape)
    geometry_index = int(
        adapter.skin_fn.indexForOutputShape(adapter.mesh_dag_path.node())
    )
    input_object = reference._input_mesh_object(adapter, geometry_index)
    mesh_fn = om.MFnMesh(input_object)
    bind_matrix = reference._geometry_bind_matrix(adapter.skin_cluster)

    object_points = mesh_fn.getPoints(om.MSpace.kObject)
    world_positions = np.asarray(
        [
            _point_tuple(om.MPoint(point) * bind_matrix)
            for point in object_points
        ],
        dtype=np.float64,
    )
    if world_positions.shape[0] != adapter.vertex_count():
        raise RuntimeError(
            "Source pre-skin vertex count does not match its skinCluster output: "
            "{} != {}".format(
                world_positions.shape[0],
                adapter.vertex_count(),
            )
        )

    triangle_counts, triangle_vertices = mesh_fn.getTriangles()
    counts = np.asarray(triangle_counts, dtype=np.int32).reshape(-1)
    flattened = np.asarray(triangle_vertices, dtype=np.int32).reshape(-1)
    if flattened.size % 3:
        raise RuntimeError(
            "Source mesh triangulation returned an invalid index array."
        )
    triangles = flattened.reshape(-1, 3)
    offsets = np.zeros(counts.size + 1, dtype=np.int32)
    if counts.size:
        offsets[1:] = np.cumsum(counts, dtype=np.int32)

    intersector = om.MMeshIntersector()
    intersector.create(input_object, bind_matrix.inverse())
    return _DiagnosticSurface(
        registration=registration,
        triangle_count=int(triangles.shape[0]),
        world_positions=world_positions,
        triangle_vertex_ids=triangles,
        triangle_offsets_by_face=offsets,
        intersector=intersector,
    )


def _bounded_ring_distance(
    neighbour_getter,
    face_a: int,
    face_b: int,
    maximum_rings: int,
) -> int:
    a = int(face_a)
    b = int(face_b)
    limit = int(maximum_rings)
    if a == b:
        return 0
    if limit <= 0:
        return 1

    visited = {a}
    frontier = {a}
    for ring in range(1, limit + 1):
        next_frontier = set()
        for face_id in frontier:
            for neighbour in neighbour_getter(face_id):
                neighbour = int(neighbour)
                if neighbour == b:
                    return ring
                if neighbour not in visited:
                    visited.add(neighbour)
                    next_frontier.add(neighbour)
        if not next_frontier:
            break
        frontier = next_frontier
    return limit + 1


def _point_tuple(point):
    return float(point.x), float(point.y), float(point.z)
