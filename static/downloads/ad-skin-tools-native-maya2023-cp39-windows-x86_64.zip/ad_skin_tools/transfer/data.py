"""Platform-neutral data contracts for Transfer diagnostics."""

from dataclasses import dataclass
from typing import Tuple


@dataclass(frozen=True)
class DiagnosticThresholds:
    """Thresholds for donor-continuity diagnostics."""

    weight_jump: float = 0.35
    maximum_source_face_rings: int = 2
    correspondence_stretch: float = 4.0
    minimum_reasons: int = 2

    def validate(self) -> None:
        if not 0.0 <= float(self.weight_jump) <= 1.0:
            raise ValueError("weight_jump must be between 0.0 and 1.0.")
        if int(self.maximum_source_face_rings) < 0:
            raise ValueError("maximum_source_face_rings cannot be negative.")
        if float(self.correspondence_stretch) <= 0.0:
            raise ValueError("correspondence_stretch must be greater than zero.")
        if int(self.minimum_reasons) < 1 or int(self.minimum_reasons) > 3:
            raise ValueError("minimum_reasons must be between 1 and 3.")


@dataclass(frozen=True)
class DonorSample:
    """Closest source-surface correspondence for one target vertex."""

    source_index: int
    source_mesh_shape: str
    source_face_id: int
    source_triangle_id: int
    source_triangle_row: int
    triangle_vertex_ids: Tuple[int, int, int]
    barycentric: Tuple[float, float, float]
    source_point: Tuple[float, float, float]
    distance: float


@dataclass(frozen=True)
class EdgeDiagnostic:
    """Continuity measurements for one target edge."""

    vertex_a: int
    vertex_b: int
    weight_jump: float
    source_face_ring_distance: int
    correspondence_stretch: float
    weight_reason: bool
    source_face_reason: bool
    stretch_reason: bool
    suspicious: bool
    severity: float

    @property
    def reason_count(self) -> int:
        return int(self.weight_reason) + int(self.source_face_reason) + int(
            self.stretch_reason
        )


@dataclass(frozen=True)
class TargetDiagnosticResult:
    mesh_shape: str
    mesh_transform: str
    skin_cluster: str
    vertex_count: int
    edge_count: int
    suspicious_edges: Tuple[EdgeDiagnostic, ...]
    suspicious_vertex_ids: Tuple[int, ...]
    suspicious_components: Tuple[Tuple[int, ...], ...]
    weight_reason_count: int
    source_face_reason_count: int
    stretch_reason_count: int
    donor_source_counts: Tuple[Tuple[str, int], ...]

    @property
    def suspicious_edge_count(self) -> int:
        return len(self.suspicious_edges)

    @property
    def suspicious_vertex_count(self) -> int:
        return len(self.suspicious_vertex_ids)


@dataclass(frozen=True)
class DonorDiagnosticResult:
    source_mesh_shapes: Tuple[str, ...]
    source_mesh_transforms: Tuple[str, ...]
    target_results: Tuple[TargetDiagnosticResult, ...]
    thresholds: DiagnosticThresholds

    @property
    def suspicious_edge_count(self) -> int:
        return sum(item.suspicious_edge_count for item in self.target_results)

    @property
    def suspicious_vertex_count(self) -> int:
        return sum(item.suspicious_vertex_count for item in self.target_results)
