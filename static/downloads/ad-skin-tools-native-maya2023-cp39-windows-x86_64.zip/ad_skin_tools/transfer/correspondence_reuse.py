"""Reuse exact production Transfer correspondence for adaptive mask preparation.

A narrow wrapper captures the same closest-surface samples while
``operation.build_preflight`` runs, then reuses the winning correspondence after
``operation.apply_transfer``. This removes repeated source-surface setup and
repeated closest-point sampling from the diagnostic-mask stage.

The wrapper is explicit and short-lived:
* no global cache;
* no hidden scene state;
* no second closest-point pass;
* only whole-object target snapshots are accepted for reuse.
"""

from dataclasses import dataclass
import time
from types import SimpleNamespace
from typing import Dict, Sequence, Tuple

import maya.api.OpenMaya as om
import maya.cmds as cmds

from ad_skin_tools.core.compat import ensure_numpy
from ad_skin_tools.core.mesh import get_all_vertex_neighbors
from ad_skin_tools.core.skin_cluster import SkinClusterAdapter, find_skin_cluster
from ad_skin_tools.transfer import (
    boundary_mask_prepare,
    boundary_mask_solver,
    boundary_mask_smooth,
    diagnostic_solver,
    donor_diagnostics,
    nearest,
    operation,
    reference,
)
from ad_skin_tools.transfer.selection import SourceRegistration, TargetRegistration


np = ensure_numpy()


@dataclass(frozen=True)
class _CapturedCandidate:
    source_index: int
    source_mesh_shape: str
    source_face_id: int
    source_point: Tuple[float, float, float]
    distance: float


@dataclass(frozen=True)
class TargetCorrespondence:
    mesh_shape: str
    mesh_transform: str
    whole_object: bool
    vertex_ids: Tuple[int, ...]
    source_indices: np.ndarray
    source_face_ids: np.ndarray
    source_points: np.ndarray
    distances: np.ndarray

    @property
    def vertex_count(self) -> int:
        return len(self.vertex_ids)


@dataclass(frozen=True)
class TransferCorrespondence:
    source_mesh_shapes: Tuple[str, ...]
    source_mesh_transforms: Tuple[str, ...]
    source_skin_clusters: Tuple[str, ...]
    source_vertex_counts: Tuple[int, ...]
    source_triangle_counts: Tuple[int, ...]
    targets: Tuple[TargetCorrespondence, ...]


@dataclass(frozen=True)
class CapturedPreflight:
    preflight: operation.TransferPreflight
    correspondence: TransferCorrespondence


@dataclass(frozen=True)
class CapturedTransferResult:
    transfer_result: operation.TransferResult
    correspondence: TransferCorrespondence


def build_preflight(
    source_registrations: Sequence[SourceRegistration],
    target_registrations: Sequence[TargetRegistration],
) -> CapturedPreflight:
    """Build the production Transfer preflight while capturing exact candidates."""

    captured = []
    original = reference.closest_surface_sample

    def capturing_sample(surface, world_position, source_index):
        sample, candidate = _closest_surface_sample_with_metadata(
            surface,
            world_position,
            source_index,
        )
        captured.append(candidate)
        return sample

    reference.closest_surface_sample = capturing_sample
    try:
        preflight = operation.build_preflight(
            source_registrations,
            target_registrations,
        )
    finally:
        reference.closest_surface_sample = original

    correspondence = _assemble_correspondence(preflight, tuple(captured))
    return CapturedPreflight(preflight, correspondence)


def apply_transfer(captured: CapturedPreflight) -> CapturedTransferResult:
    """Apply the normal production Transfer and preserve its captured snapshot."""

    result = operation.apply_transfer(captured.preflight)
    return CapturedTransferResult(
        transfer_result=result,
        correspondence=captured.correspondence,
    )


def prepare_mask(
    captured: CapturedTransferResult,
    thresholds: donor_diagnostics.DiagnosticThresholds = donor_diagnostics.DiagnosticThresholds(),
    select_mask_vertices: bool = True,
    report_component_limit: int = 30,
):
    """Prepare the established mask without rebuilding or resampling donors."""

    prepared = _prepare_from_correspondence(
        captured.correspondence,
        thresholds=thresholds,
        report_component_limit=report_component_limit,
    )
    if select_mask_vertices:
        boundary_mask_smooth.select_prepared(prepared)
    return prepared


def apply_smooth(
    prepared,
    blend: float = 1.0,
    iterations: int = 10,
    select_mask_vertices: bool = True,
):
    """Apply the established production Component Smooth to a reused mask."""

    return boundary_mask_smooth.apply_prepared(
        prepared,
        blend=blend,
        iterations=iterations,
        select_mask_vertices=select_mask_vertices,
    )


def _closest_surface_sample_with_metadata(surface, world_position, source_index):
    """Exact copy of production sampling plus face/source-point metadata."""

    query = np.asarray(world_position, dtype=np.float64).reshape(3)
    point_on_mesh = surface.intersector.getClosestPoint(
        om.MPoint(float(query[0]), float(query[1]), float(query[2]))
    )
    face_id = int(reference._value_or_call(point_on_mesh, "face"))
    local_triangle = int(reference._value_or_call(point_on_mesh, "triangle"))
    if face_id < 0 or face_id + 1 >= surface.triangle_offsets_by_face.size:
        raise RuntimeError("Closest-point query returned an invalid source face ID.")

    start = int(surface.triangle_offsets_by_face[face_id])
    end = int(surface.triangle_offsets_by_face[face_id + 1])
    triangle_row = start + local_triangle
    if local_triangle < 0 or triangle_row >= end:
        raise RuntimeError("Closest-point query returned an invalid source triangle ID.")

    triangle_ids = surface.triangle_vertex_ids[triangle_row]
    triangle_positions = surface.world_positions[triangle_ids]
    uv = reference._value_or_call(point_on_mesh, "barycentricCoords")
    bary = nearest.barycentric_from_maya_uv(float(uv[0]), float(uv[1]))
    closest = np.sum(triangle_positions * bary[:, np.newaxis], axis=0)
    distance = float(np.linalg.norm(closest - query))

    sample = reference.SurfaceSample(
        source_index=int(source_index),
        source_mesh_shape=surface.registration.mesh_shape,
        triangle_vertex_ids=tuple(int(value) for value in triangle_ids.tolist()),
        barycentric=tuple(float(value) for value in bary.tolist()),
        distance=distance,
    )
    candidate = _CapturedCandidate(
        source_index=int(source_index),
        source_mesh_shape=str(surface.registration.mesh_shape),
        source_face_id=face_id,
        source_point=tuple(float(value) for value in closest.tolist()),
        distance=distance,
    )
    return sample, candidate


def _assemble_correspondence(preflight, candidates) -> TransferCorrespondence:
    source_count = len(preflight.sources)
    expected = sum(plan.requested_count * source_count for plan in preflight.target_plans)
    if len(candidates) != expected:
        raise RuntimeError(
            "Captured Transfer candidate count is inconsistent: {} != {}.".format(
                len(candidates),
                expected,
            )
        )

    cursor = 0
    targets = []
    for plan in preflight.target_plans:
        winners = []
        for local_row, _vertex_id in enumerate(plan.requested_vertex_ids):
            group = tuple(candidates[cursor : cursor + source_count])
            cursor += source_count
            if tuple(item.source_index for item in group) != tuple(range(source_count)):
                raise RuntimeError(
                    "Captured source order changed while building Transfer preflight."
                )
            winner = _winning_candidate(group)
            planned_distance = float(plan.distances[local_row])
            if not np.isclose(
                winner.distance,
                planned_distance,
                rtol=0.0,
                atol=1.0e-12,
            ):
                raise RuntimeError(
                    "Captured correspondence does not match production Transfer distance "
                    "for target vertex {}.".format(plan.requested_vertex_ids[local_row])
                )
            winners.append(winner)

        targets.append(
            TargetCorrespondence(
                mesh_shape=str(plan.registration.mesh_shape),
                mesh_transform=str(plan.registration.mesh_transform),
                whole_object=bool(plan.registration.whole_object),
                vertex_ids=tuple(int(value) for value in plan.requested_vertex_ids),
                source_indices=_readonly_array(
                    [item.source_index for item in winners],
                    np.int32,
                ),
                source_face_ids=_readonly_array(
                    [item.source_face_id for item in winners],
                    np.int32,
                ),
                source_points=_readonly_array(
                    [item.source_point for item in winners],
                    np.float64,
                    shape=(-1, 3),
                ),
                distances=_readonly_array(
                    [item.distance for item in winners],
                    np.float64,
                ),
            )
        )

    return TransferCorrespondence(
        source_mesh_shapes=tuple(item.mesh_shape for item in preflight.sources),
        source_mesh_transforms=tuple(item.mesh_transform for item in preflight.sources),
        source_skin_clusters=tuple(item.skin_cluster for item in preflight.sources),
        source_vertex_counts=tuple(int(item.vertex_count) for item in preflight.sources),
        source_triangle_counts=tuple(int(item.triangle_count) for item in preflight.sources),
        targets=tuple(targets),
    )


def _winning_candidate(candidates):
    best = None
    for candidate in candidates:
        if best is None:
            best = candidate
            continue
        if nearest.distance_tied(candidate.distance, best.distance):
            continue
        if candidate.distance < best.distance:
            best = candidate
    if best is None:
        raise RuntimeError("No captured Transfer candidate was available.")
    return best


def _readonly_array(values, dtype, shape=None):
    result = np.asarray(values, dtype=dtype)
    if shape is not None:
        result = result.reshape(shape)
    result = result.copy()
    result.setflags(write=False)
    return result


def _prepare_from_correspondence(
    correspondence,
    thresholds,
    report_component_limit,
):
    started = time.perf_counter()
    thresholds.validate()

    validation_started = time.perf_counter()
    _validate_sources(correspondence)
    validation_seconds = float(time.perf_counter() - validation_started)

    source_surfaces = tuple(
        SimpleNamespace(
            registration=SimpleNamespace(mesh_shape=shape),
        )
        for shape in correspondence.source_mesh_shapes
    )

    prepared_targets = tuple(
        _prepare_target_from_snapshot(
            target_snapshot=target,
            source_surfaces=source_surfaces,
            thresholds=thresholds,
        )
        for target in correspondence.targets
    )
    prepared = boundary_mask_prepare.PreparedMask(
        source_mesh_shapes=tuple(correspondence.source_mesh_shapes),
        source_mesh_transforms=tuple(correspondence.source_mesh_transforms),
        targets=prepared_targets,
        thresholds=thresholds,
        source_setup_seconds=0.0,
        total_seconds=float(time.perf_counter() - started),
    )
    _print_reuse_report(
        prepared,
        validation_seconds=validation_seconds,
        component_limit=report_component_limit,
    )
    return prepared


def _validate_sources(correspondence):
    count = len(correspondence.source_mesh_shapes)
    lengths = (
        len(correspondence.source_mesh_transforms),
        len(correspondence.source_skin_clusters),
        len(correspondence.source_vertex_counts),
        len(correspondence.source_triangle_counts),
    )
    if any(value != count for value in lengths):
        raise RuntimeError("Transfer correspondence source metadata is inconsistent.")

    for index, shape in enumerate(correspondence.source_mesh_shapes):
        if not cmds.objExists(shape):
            raise RuntimeError(
                "Transfer correspondence source no longer exists:\n{}".format(shape)
            )
        current_skin = find_skin_cluster(shape, required=False)
        if str(current_skin or "") != str(correspondence.source_skin_clusters[index]):
            raise RuntimeError(
                "Transfer correspondence source skinCluster changed:\n{}".format(shape)
            )
        adapter = SkinClusterAdapter(str(current_skin), shape)
        if int(adapter.vertex_count()) != int(
            correspondence.source_vertex_counts[index]
        ):
            raise RuntimeError(
                "Transfer correspondence source vertex count changed:\n{}".format(shape)
            )


def _prepare_target_from_snapshot(
    target_snapshot,
    source_surfaces,
    thresholds,
):
    target_started = time.perf_counter()
    if not target_snapshot.whole_object:
        raise RuntimeError(
            "Correspondence reuse currently requires a Whole Object target:\n{}".format(
                target_snapshot.mesh_transform
            )
        )

    target_shape, target_transform = donor_diagnostics._resolve_mesh(
        target_snapshot.mesh_shape
    )
    if target_shape != target_snapshot.mesh_shape:
        raise RuntimeError(
            "Transfer correspondence target path changed:\n{}".format(
                target_snapshot.mesh_shape
            )
        )

    skin_cluster = find_skin_cluster(target_shape, required=False)
    if not skin_cluster:
        raise RuntimeError(
            "Transfer correspondence target has no applied skinCluster:\n{}".format(
                target_transform
            )
        )
    adapter = SkinClusterAdapter(str(skin_cluster), target_shape)

    stage = time.perf_counter()
    positions = np.asarray(
        reference.bind_mesh_positions(target_shape, adapter.skin_cluster),
        dtype=np.float64,
    )
    bind_positions_seconds = float(time.perf_counter() - stage)

    vertex_count = len(positions)
    expected_ids = np.arange(vertex_count, dtype=np.int32)
    snapshot_ids = np.asarray(target_snapshot.vertex_ids, dtype=np.int32)
    if snapshot_ids.shape != expected_ids.shape or not np.array_equal(
        snapshot_ids,
        expected_ids,
    ):
        raise RuntimeError(
            "Transfer correspondence does not cover every target vertex in order:\n"
            "{}".format(target_transform)
        )
    if (
        np.asarray(target_snapshot.source_indices).shape != (vertex_count,)
        or np.asarray(target_snapshot.source_face_ids).shape != (vertex_count,)
        or np.asarray(target_snapshot.source_points).shape != (vertex_count, 3)
        or np.asarray(target_snapshot.distances).shape != (vertex_count,)
    ):
        raise RuntimeError(
            "Transfer correspondence target arrays are inconsistent:\n{}".format(
                target_transform
            )
        )
    source_indices = np.asarray(target_snapshot.source_indices, dtype=np.int32)
    if np.any(source_indices < 0) or np.any(source_indices >= len(source_surfaces)):
        raise RuntimeError(
            "Transfer correspondence contains an invalid source index:\n{}".format(
                target_transform
            )
        )

    stage = time.perf_counter()
    skin_data = adapter.get_weights(expected_ids)
    before = np.asarray(skin_data.weights, dtype=np.float64)
    influences = tuple(str(path) for path in skin_data.influences)
    weight_read_seconds = float(time.perf_counter() - stage)

    stage = time.perf_counter()
    adjacency = tuple(
        tuple(int(value) for value in row)
        for row in get_all_vertex_neighbors(target_shape)
    )
    unique_edges = diagnostic_solver.unique_edges(adjacency)
    adjacency_seconds = float(time.perf_counter() - stage)
    if len(adjacency) != vertex_count or before.shape[0] != vertex_count:
        raise RuntimeError(
            "Target topology, positions, and weights do not agree:\n{}".format(
                target_transform
            )
        )

    donor_samples = tuple(
        SimpleNamespace(
            source_index=int(source_indices[index]),
            source_face_id=int(target_snapshot.source_face_ids[index]),
            source_point=tuple(
                float(value)
                for value in np.asarray(target_snapshot.source_points[index]).tolist()
            ),
        )
        for index in range(vertex_count)
    )

    (
        source_face_distances,
        source_face_query_seconds,
        source_face_classification_seconds,
    ) = boundary_mask_prepare._capture_source_face_distances(
        unique_edges=unique_edges,
        donor_samples=donor_samples,
        source_surfaces=source_surfaces,
        maximum_rings=int(thresholds.maximum_source_face_rings),
    )
    solution = boundary_mask_solver.solve_target_mask(
        unique_edges=unique_edges,
        positions=positions,
        weights=before,
        adjacency=adjacency,
        donor_samples=donor_samples,
        source_face_distances=source_face_distances,
        thresholds=thresholds,
        source_face_query_seconds=source_face_query_seconds,
    )

    timings = boundary_mask_prepare.TargetTimings(
        bind_positions=bind_positions_seconds,
        weight_read=weight_read_seconds,
        adjacency=adjacency_seconds,
        donor_sampling=0.0,
        source_face_queries=solution.source_face_query_seconds,
        edge_classification=(
            source_face_classification_seconds
            + solution.edge_classification_seconds
        ),
        connected_components=solution.connected_components_seconds,
        mask_construction=solution.mask_construction_seconds,
        total=float(time.perf_counter() - target_started),
    )
    return boundary_mask_prepare.PreparedTarget(
        mesh_shape=str(target_shape),
        mesh_transform=str(target_transform),
        skin_cluster=str(skin_cluster),
        vertex_count=vertex_count,
        edge_count=solution.edge_count,
        influence_paths=influences,
        mask_vertex_ids=solution.mask_vertex_ids,
        baseline_mask_weights=solution.baseline_mask_weights,
        suspicious_edge_count=solution.suspicious_edge_count,
        accepted_component_count=solution.accepted_component_count,
        total_component_count=solution.total_component_count,
        component_results=solution.component_results,
        timings=timings,
    )


def _print_reuse_report(prepared, validation_seconds, component_limit):
    print("\n[AD Skin Tool - Reused Transfer Correspondence]")
    print("Mode: Diagnostic only")
    print("Source surface rebuild: skipped")
    print("Closest-point resampling: skipped")
    print("Correspondence source: exact production Transfer preflight")
    print("Source validation: {:.3f}s".format(validation_seconds))
    print("Total prepare time: {:.3f}s".format(prepared.total_seconds))

    for target in prepared.targets:
        t = target.timings
        print("\nTarget:", target.mesh_transform)
        print("  Vertices / edges:", target.vertex_count, "/", target.edge_count)
        print("  Suspicious edges:", target.suspicious_edge_count)
        print(
            "  Components accepted: {} / {}".format(
                target.accepted_component_count,
                target.total_component_count,
            )
        )
        print("  Mask vertices:", target.mask_vertex_count)
        print("  Timings:")
        print("    bind positions:       {:.3f}s".format(t.bind_positions))
        print("    target weight read:   {:.3f}s".format(t.weight_read))
        print("    target adjacency:     {:.3f}s".format(t.adjacency))
        print("    closest sampling:     reused (0.000s)")
        print("    source face queries:  {:.3f}s".format(t.source_face_queries))
        print("    edge classification:  {:.3f}s".format(t.edge_classification))
        print("    connected components: {:.3f}s".format(t.connected_components))
        print("    mask construction:    {:.3f}s".format(t.mask_construction))
        print("    target total:         {:.3f}s".format(t.total))

        accepted = sorted(
            (item for item in target.component_results if item.accepted),
            key=lambda item: (
                item.median_jump_after - item.median_jump_before,
                -item.repair_vertices,
                item.index,
            ),
        )
        if component_limit > 0 and accepted:
            print("  Strongest accepted components:")
            for item in accepted[: int(component_limit)]:
                print(
                    "    {} | edges={} | gap={:.6f} | half={:.6f} | "
                    "repair={} | jump {:.4f}->{:.4f}".format(
                        item.index,
                        item.suspicious_edges,
                        item.measured_gap,
                        item.half_width,
                        item.repair_vertices,
                        item.median_jump_before,
                        item.median_jump_after,
                    )
                )

        rejected: Dict[str, int] = {}
        for item in target.component_results:
            if item.accepted:
                continue
            rejected[item.status] = rejected.get(item.status, 0) + 1
        if rejected:
            print("  Rejected components:")
            for status in sorted(rejected):
                print("    {}: {}".format(status, rejected[status]))
