"""Barycentric transfer to existing or newly created target skinClusters."""

from dataclasses import dataclass
from typing import Sequence, Tuple

import maya.cmds as cmds

from ad_skin_tools.core.compat import ensure_numpy
from ad_skin_tools.core.influence_lock import locked_influences
from ad_skin_tools.core.skin_cluster import SkinClusterAdapter, find_skin_cluster
from ad_skin_tools.transfer import nearest
from ad_skin_tools.transfer import reference
from ad_skin_tools.transfer import undoable_transfer
from ad_skin_tools.transfer.selection import SourceRegistration, TargetRegistration


np = ensure_numpy()
_UNDO_CHUNK_NAME = "AD Skin Transfer Weights"


@dataclass(frozen=True)
class SourceSummary:
    mesh_shape: str
    mesh_transform: str
    skin_cluster: str
    influences: Tuple[str, ...]
    vertex_count: int
    triangle_count: int


@dataclass(frozen=True)
class _ResolvedDonor:
    vertex_id: int
    local_row: int
    source_index: int
    donor_source_row: np.ndarray
    distance: float


@dataclass
class TargetTransferPlan:
    registration: TargetRegistration
    create_skin_cluster: bool
    skin_cluster: str
    influences: Tuple[str, ...]
    final_influences: Tuple[str, ...]
    influences_to_add: Tuple[str, ...]
    locked_influence_paths: Tuple[str, ...]
    source_assignment_counts: Tuple[Tuple[str, int], ...]
    requested_vertex_ids: Tuple[int, ...]
    writable_vertex_ids: np.ndarray
    before_weights: np.ndarray
    after_weights: np.ndarray
    missing_influence_vertex_ids: Tuple[int, ...]
    fully_locked_vertex_ids: Tuple[int, ...]
    empty_donor_vertex_ids: Tuple[int, ...]
    missing_influence_paths: Tuple[str, ...]
    tie_count: int
    distances: np.ndarray

    @property
    def requested_count(self) -> int:
        return len(self.requested_vertex_ids)

    @property
    def writable_count(self) -> int:
        return int(self.writable_vertex_ids.size)

    @property
    def skipped_count(self) -> int:
        return (
            len(self.fully_locked_vertex_ids)
            + len(self.empty_donor_vertex_ids)
        )


@dataclass
class TransferPreflight:
    source_registrations: Tuple[SourceRegistration, ...]
    target_registrations: Tuple[TargetRegistration, ...]
    sources: Tuple[SourceSummary, ...]
    target_plans: Tuple[TargetTransferPlan, ...]
    source_vertex_count: int
    source_triangle_count: int
    requested_target_count: int
    writable_target_count: int
    missing_influence_target_count: int
    influence_addition_count: int
    new_skin_influence_count: int
    unskinned_target_count: int
    fully_locked_target_count: int
    empty_donor_target_count: int
    exact_distance_tie_count: int
    average_distance: float
    maximum_distance: float

    @property
    def valid(self) -> bool:
        return self.writable_target_count > 0

    @property
    def partial(self) -> bool:
        return (
            self.fully_locked_target_count
            + self.empty_donor_target_count
        ) > 0

    @property
    def registration_signature(self):
        return registration_signature(
            self.source_registrations,
            self.target_registrations,
        )

    @property
    def structural_signature(self):
        source_data = tuple(
            (
                item.mesh_shape,
                item.skin_cluster,
                item.influences,
                item.vertex_count,
                item.triangle_count,
            )
            for item in self.sources
        )
        target_data = tuple(
            (
                plan.registration.mesh_shape,
                plan.create_skin_cluster,
                plan.skin_cluster,
                plan.influences,
                plan.final_influences,
                plan.influences_to_add,
                plan.registration.whole_object,
                plan.requested_vertex_ids,
                plan.source_assignment_counts,
            )
            for plan in self.target_plans
        )
        return source_data, target_data


@dataclass(frozen=True)
class TransferResult:
    source_count: int
    target_count: int
    written_target_count: int
    created_skin_cluster_count: int
    requested_target_count: int
    transferred_target_count: int
    missing_influence_target_count: int
    added_influence_count: int
    new_skin_influence_count: int
    fully_locked_target_count: int
    empty_donor_target_count: int
    exact_distance_tie_count: int
    target_mesh_shapes: Tuple[str, ...]


def registration_signature(
    sources: Sequence[SourceRegistration],
    targets: Sequence[TargetRegistration],
):
    return (
        tuple(item.mesh_shape for item in sources),
        tuple(
            (
                item.mesh_shape,
                bool(item.whole_object),
                tuple(item.vertex_ids),
            )
            for item in targets
        ),
    )


def build_preflight(
    source_registrations: Sequence[SourceRegistration],
    target_registrations: Sequence[TargetRegistration],
) -> TransferPreflight:
    sources = tuple(source_registrations)
    targets = tuple(target_registrations)
    _validate_registrations(sources, targets)

    source_surfaces = tuple(
        reference.build_source_surface(item) for item in sources
    )
    for surface in source_surfaces:
        if surface.triangle_count <= 0:
            raise RuntimeError(
                "Source mesh has no usable polygon triangles:\n{}".format(
                    surface.registration.mesh_shape
                )
            )

    source_summaries = tuple(
        SourceSummary(
            mesh_shape=surface.registration.mesh_shape,
            mesh_transform=surface.registration.mesh_transform,
            skin_cluster=surface.skin_cluster,
            influences=surface.influences,
            vertex_count=surface.vertex_count,
            triangle_count=surface.triangle_count,
        )
        for surface in source_surfaces
    )

    target_plans = []
    all_distances = []
    total_ties = 0
    for registration in targets:
        plan = _build_target_plan(registration, source_surfaces)
        target_plans.append(plan)
        total_ties += int(plan.tie_count)
        if plan.distances.size:
            all_distances.extend(plan.distances.tolist())

    requested_count = sum(plan.requested_count for plan in target_plans)
    writable_count = sum(plan.writable_count for plan in target_plans)
    existing_addition_count = sum(
        len(plan.influences_to_add)
        for plan in target_plans
        if not plan.create_skin_cluster
    )
    new_skin_influence_count = sum(
        len(plan.final_influences)
        for plan in target_plans
        if plan.create_skin_cluster
    )
    unskinned_count = sum(
        1 for plan in target_plans if plan.create_skin_cluster
    )
    locked_count = sum(
        len(plan.fully_locked_vertex_ids) for plan in target_plans
    )
    empty_count = sum(
        len(plan.empty_donor_vertex_ids) for plan in target_plans
    )
    distance_array = np.asarray(all_distances, dtype=np.float64)

    return TransferPreflight(
        source_registrations=sources,
        target_registrations=targets,
        sources=source_summaries,
        target_plans=tuple(target_plans),
        source_vertex_count=sum(item.vertex_count for item in source_summaries),
        source_triangle_count=sum(item.triangle_count for item in source_summaries),
        requested_target_count=int(requested_count),
        writable_target_count=int(writable_count),
        missing_influence_target_count=0,
        influence_addition_count=int(existing_addition_count),
        new_skin_influence_count=int(new_skin_influence_count),
        unskinned_target_count=int(unskinned_count),
        fully_locked_target_count=int(locked_count),
        empty_donor_target_count=int(empty_count),
        exact_distance_tie_count=int(total_ties),
        average_distance=(
            float(np.mean(distance_array)) if distance_array.size else 0.0
        ),
        maximum_distance=(
            float(np.max(distance_array)) if distance_array.size else 0.0
        ),
    )


def apply_transfer(preflight: TransferPreflight) -> TransferResult:
    if not preflight.valid:
        raise RuntimeError(
            "Transfer preview contains no writable target vertices.\n\n"
            "Review locked target weights and vertices with no writable donor weight."
        )

    writable_plans = tuple(
        plan for plan in preflight.target_plans if plan.writable_count
    )
    for plan in writable_plans:
        _validate_target_before_apply(plan)
        paths_to_validate = (
            plan.final_influences
            if plan.create_skin_cluster
            else plan.influences_to_add
        )
        _validate_exact_joint_paths(paths_to_validate)

    selection_before = cmds.ls(selection=True, long=True, flatten=True) or []
    chunk_open = False
    mutation_recorded = False
    skin_cluster_by_mesh = {}
    try:
        cmds.undoInfo(openChunk=True, chunkName=_UNDO_CHUNK_NAME)
        chunk_open = True

        for plan in writable_plans:
            if plan.create_skin_cluster:
                created = _create_skin_cluster_node(plan)
                mutation_recorded = True
                skin_cluster_by_mesh[plan.registration.mesh_shape] = created
                adapter = SkinClusterAdapter.from_mesh(plan.registration.mesh_shape)
                if adapter.skin_cluster != created:
                    raise RuntimeError(
                        "Created skinCluster could not be resolved on target:\n{}".format(
                            plan.registration.mesh_shape
                        )
                    )
                _validate_final_influence_set(plan, tuple(adapter.influences()))
                continue

            for influence in plan.influences_to_add:
                _add_exact_influence(plan.skin_cluster, influence)
                mutation_recorded = True
            skin_cluster_by_mesh[plan.registration.mesh_shape] = plan.skin_cluster

        records = []
        expected_by_mesh = {}
        for plan in writable_plans:
            adapter = SkinClusterAdapter.from_mesh(plan.registration.mesh_shape)
            expected_skin_cluster = skin_cluster_by_mesh[plan.registration.mesh_shape]
            if adapter.skin_cluster != expected_skin_cluster:
                raise RuntimeError(
                    "Target skinCluster changed during Transfer on:\n{}".format(
                        plan.registration.mesh_shape
                    )
                )
            current_influences = tuple(adapter.influences())
            _validate_final_influence_set(plan, current_influences)

            before_current = np.asarray(
                adapter.get_weights(plan.writable_vertex_ids).weights,
                dtype=np.float64,
            )
            after_current = nearest.remap_matrix_by_paths(
                plan.after_weights,
                plan.final_influences,
                current_influences,
            )
            records.append(
                undoable_transfer.TransferWriteRecord(
                    skin_cluster=adapter.skin_cluster,
                    mesh_shape=plan.registration.mesh_shape,
                    vertex_ids=plan.writable_vertex_ids,
                    before_weights=before_current,
                    after_weights=after_current,
                )
            )
            expected_by_mesh[plan.registration.mesh_shape] = (
                adapter.skin_cluster,
                current_influences,
                after_current,
            )

        undoable_transfer.apply_grouped_transfer(records)
        mutation_recorded = True

        for plan in writable_plans:
            expected_skin, expected_influences, expected_weights = expected_by_mesh[
                plan.registration.mesh_shape
            ]
            adapter = SkinClusterAdapter.from_mesh(plan.registration.mesh_shape)
            if (
                adapter.skin_cluster != expected_skin
                or tuple(adapter.influences()) != expected_influences
            ):
                raise RuntimeError(
                    "Target skinCluster or influence order changed during Transfer on:\n{}".format(
                        plan.registration.mesh_shape
                    )
                )
            _validate_written_rows(
                adapter=adapter,
                vertex_ids=plan.writable_vertex_ids,
                expected=expected_weights,
            )

        cmds.undoInfo(closeChunk=True)
        chunk_open = False
    except Exception as exc:
        if chunk_open:
            try:
                cmds.undoInfo(closeChunk=True)
            finally:
                chunk_open = False
        if mutation_recorded:
            try:
                cmds.undo()
            except Exception as rollback_exc:
                raise RuntimeError(
                    "Transfer failed and Maya could not fully roll back the undo "
                    "transaction.\n\nOriginal error: {}\nRollback error: {}".format(
                        exc,
                        rollback_exc,
                    )
                ) from exc
        raise
    finally:
        if chunk_open:
            try:
                cmds.undoInfo(closeChunk=True)
            except Exception:
                pass
        _restore_selection(selection_before)

    return TransferResult(
        source_count=len(preflight.sources),
        target_count=len(preflight.target_plans),
        written_target_count=len(writable_plans),
        created_skin_cluster_count=preflight.unskinned_target_count,
        requested_target_count=preflight.requested_target_count,
        transferred_target_count=preflight.writable_target_count,
        missing_influence_target_count=0,
        added_influence_count=preflight.influence_addition_count,
        new_skin_influence_count=preflight.new_skin_influence_count,
        fully_locked_target_count=preflight.fully_locked_target_count,
        empty_donor_target_count=preflight.empty_donor_target_count,
        exact_distance_tie_count=preflight.exact_distance_tie_count,
        target_mesh_shapes=tuple(
            plan.registration.mesh_shape for plan in preflight.target_plans
        ),
    )


def _build_target_plan(
    registration: TargetRegistration,
    source_surfaces,
) -> TargetTransferPlan:
    skin_cluster = find_skin_cluster(registration.mesh_shape, required=False)
    create_skin_cluster = not bool(skin_cluster)

    if create_skin_cluster:
        if not registration.whole_object:
            raise RuntimeError(
                "Unskinned targets support Whole Object transfer only:\n{}".format(
                    registration.mesh_transform
                )
            )
        target_influences = ()
        target_positions = reference.current_mesh_world_positions(
            registration.mesh_shape
        )
        vertex_count = int(target_positions.shape[0])
        requested_ids = _target_vertex_ids(registration, vertex_count)
        before = np.empty((requested_ids.size, 0), dtype=np.float64)
        locked_paths = ()
        original_locked_columns = ()
    else:
        adapter = SkinClusterAdapter(str(skin_cluster), registration.mesh_shape)
        target_influences = tuple(adapter.influences())
        target_positions = reference.bind_mesh_positions(
            registration.mesh_shape,
            adapter.skin_cluster,
        )
        requested_ids = _target_vertex_ids(registration, adapter.vertex_count())
        before = np.asarray(
            adapter.get_weights(requested_ids).weights,
            dtype=np.float64,
        )
        locked_paths = tuple(
            locked_influences(adapter.skin_cluster, target_influences)
        )
        original_column_by_path = {
            path: index for index, path in enumerate(target_influences)
        }
        original_locked_columns = tuple(
            original_column_by_path[path]
            for path in locked_paths
            if path in original_column_by_path
        )

    resolved = []
    fully_locked_ids = []
    distances = []
    tie_count = 0
    source_counts = [0 for _surface in source_surfaces]
    required_missing = []
    required_missing_set = set()
    existing_paths = set(target_influences)

    # Existing targets follow the source binding set. Add every exact source
    # influence that is not already bound, even when its weight is zero in the
    # requested component scope or the affected target rows are fully locked.
    if not create_skin_cluster:
        for surface in source_surfaces:
            for path in surface.influences:
                if path in existing_paths or path in required_missing_set:
                    continue
                required_missing_set.add(path)
                required_missing.append(path)

    for local_row, vertex_id in enumerate(requested_ids.tolist()):
        query = target_positions[int(vertex_id)]
        best_sample = None
        row_tied = False
        for source_index, surface in enumerate(source_surfaces):
            sample = reference.closest_surface_sample(
                surface,
                query,
                source_index,
            )
            if best_sample is None:
                best_sample = sample
                row_tied = False
                continue
            if nearest.distance_tied(sample.distance, best_sample.distance):
                row_tied = True
                # Registration order is the deterministic exact-tie priority.
                continue
            if sample.distance < best_sample.distance:
                best_sample = sample
                row_tied = False

        if best_sample is None:
            raise RuntimeError(
                "No source surface sample was produced for target vertex {}.".format(
                    vertex_id
                )
            )
        if row_tied:
            tie_count += 1
        distances.append(best_sample.distance)
        source_counts[best_sample.source_index] += 1

        if (
            not create_skin_cluster
            and _row_is_fully_locked(
                before[local_row],
                original_locked_columns,
            )
        ):
            fully_locked_ids.append(int(vertex_id))
            continue

        surface = source_surfaces[best_sample.source_index]
        donor_source = nearest.prune_donor_row(
            nearest.interpolate_triangle_rows(
                surface.weights,
                best_sample.triangle_vertex_ids,
                best_sample.barycentric,
            )
        )
        for path in nearest.active_influence_paths(
            donor_source,
            surface.influences,
        ):
            if path in existing_paths or path in required_missing_set:
                continue
            required_missing_set.add(path)
            required_missing.append(path)

        resolved.append(
            _ResolvedDonor(
                vertex_id=int(vertex_id),
                local_row=int(local_row),
                source_index=int(best_sample.source_index),
                donor_source_row=donor_source,
                distance=float(best_sample.distance),
            )
        )

    final_influences = target_influences + tuple(required_missing)
    if create_skin_cluster and not final_influences:
        raise RuntimeError(
            "Unskinned target did not resolve any active donor influences:\n{}".format(
                registration.mesh_transform
            )
        )

    final_column_by_path = {
        path: index for index, path in enumerate(final_influences)
    }
    final_locked_columns = tuple(
        final_column_by_path[path]
        for path in locked_paths
        if path in final_column_by_path
    )
    before_expanded = nearest.remap_matrix_by_paths(
        before,
        target_influences,
        final_influences,
    )
    influence_maps = tuple(
        nearest.exact_influence_map(surface.influences, final_influences)
        for surface in source_surfaces
    )

    writable_ids = []
    writable_before = []
    writable_after = []
    empty_donor_ids = []
    for donor in resolved:
        donor_target, missing_columns = nearest.remap_exact_row(
            donor.donor_source_row,
            influence_maps[donor.source_index],
            len(final_influences),
        )
        if missing_columns.size:
            surface = source_surfaces[donor.source_index]
            paths = [
                surface.influences[int(column)]
                for column in missing_columns.tolist()
            ]
            raise RuntimeError(
                "Transfer influence planning failed to include exact donor paths:\n{}".format(
                    "\n".join(paths)
                )
            )

        projection = nearest.project_locked_row(
            donor_target,
            before_expanded[donor.local_row],
            final_locked_columns,
        )
        if projection.fully_locked:
            fully_locked_ids.append(donor.vertex_id)
            continue
        if projection.empty_donor:
            empty_donor_ids.append(donor.vertex_id)
            continue

        writable_ids.append(donor.vertex_id)
        if target_influences:
            writable_before.append(before[donor.local_row].copy())
        writable_after.append(projection.weights.copy())

    source_assignment_counts = tuple(
        (
            source_surfaces[index].registration.mesh_transform,
            int(count),
        )
        for index, count in enumerate(source_counts)
        if count
    )
    return TargetTransferPlan(
        registration=registration,
        create_skin_cluster=create_skin_cluster,
        skin_cluster=str(skin_cluster or ""),
        influences=target_influences,
        final_influences=final_influences,
        influences_to_add=tuple(required_missing),
        locked_influence_paths=locked_paths,
        source_assignment_counts=source_assignment_counts,
        requested_vertex_ids=tuple(int(value) for value in requested_ids.tolist()),
        writable_vertex_ids=np.asarray(writable_ids, dtype=np.int32),
        before_weights=_row_matrix(
            writable_before,
            len(target_influences),
            len(writable_ids),
        ),
        after_weights=_row_matrix(
            writable_after,
            len(final_influences),
            len(writable_ids),
        ),
        missing_influence_vertex_ids=(),
        fully_locked_vertex_ids=tuple(sorted(set(fully_locked_ids))),
        empty_donor_vertex_ids=tuple(empty_donor_ids),
        missing_influence_paths=(),
        tie_count=int(tie_count),
        distances=np.asarray(distances, dtype=np.float64),
    )


def _row_is_fully_locked(row, locked_columns) -> bool:
    if not locked_columns:
        return False
    values = np.asarray(row, dtype=np.float64).reshape(-1)
    locked_total = float(
        np.sum(values[np.asarray(locked_columns, dtype=np.int32)], dtype=np.float64)
    )
    numerical_zero = float(np.finfo(np.float64).eps) * max(1, values.size) * 64.0
    return (1.0 - min(1.0, max(0.0, locked_total))) <= numerical_zero


def _validate_exact_joint_paths(influences) -> None:
    for influence in influences:
        matches = cmds.ls(influence, long=True, type="joint") or []
        if str(influence) not in {str(value) for value in matches}:
            raise RuntimeError(
                "Required exact influence path no longer exists:\n{}".format(
                    influence
                )
            )


def _add_exact_influence(skin_cluster: str, influence: str) -> None:
    _validate_exact_joint_paths((influence,))
    cmds.skinCluster(
        skin_cluster,
        edit=True,
        addInfluence=influence,
        weight=0.0,
        lockWeights=False,
    )


def _create_skin_cluster_node(plan: TargetTransferPlan) -> str:
    if not plan.create_skin_cluster or not plan.registration.whole_object:
        raise RuntimeError("Only an unskinned Whole Object target may create a skinCluster.")
    if find_skin_cluster(plan.registration.mesh_shape, required=False):
        raise RuntimeError(
            "Target gained a skinCluster after Preview. Preview again:\n{}".format(
                plan.registration.mesh_shape
            )
        )
    if not plan.final_influences:
        raise RuntimeError("Cannot create a skinCluster without planned influences.")

    max_influences = max(1, min(5, len(plan.final_influences)))
    created = cmds.skinCluster(
        *(list(plan.final_influences) + [plan.registration.mesh_transform]),
        name=_next_skin_cluster_name(plan.registration.mesh_transform),
        toSelectedBones=True,
        bindMethod=0,
        skinMethod=0,
        maximumInfluences=max_influences,
        obeyMaxInfluences=False,
        normalizeWeights=1,
    )
    skin_cluster = _first_result(created)
    if not skin_cluster or not cmds.objExists(skin_cluster):
        raise RuntimeError(
            "Maya did not return a valid skinCluster for target:\n{}".format(
                plan.registration.mesh_transform
            )
        )
    return str(skin_cluster)


def _next_skin_cluster_name(mesh_transform: str) -> str:
    leaf = str(mesh_transform).rsplit("|", 1)[-1]
    base = "{}_adSc".format(leaf)
    if not cmds.objExists(base):
        return base
    index = 1
    while cmds.objExists("{}{}".format(base, index)):
        index += 1
    return "{}{}".format(base, index)


def _first_result(value):
    if isinstance(value, (list, tuple)):
        return value[0] if value else None
    return value


def _validate_target_before_apply(plan: TargetTransferPlan) -> None:
    if not cmds.objExists(plan.registration.mesh_shape):
        raise RuntimeError(
            "Target mesh no longer exists:\n{}".format(plan.registration.mesh_shape)
        )

    current_skin = find_skin_cluster(plan.registration.mesh_shape, required=False)
    if plan.create_skin_cluster:
        if not plan.registration.whole_object:
            raise RuntimeError(
                "Unskinned targets support Whole Object transfer only:\n{}".format(
                    plan.registration.mesh_transform
                )
            )
        if current_skin:
            raise RuntimeError(
                "Target gained a skinCluster after Preview. Preview again:\n{}".format(
                    plan.registration.mesh_shape
                )
            )
        return

    if not current_skin or str(current_skin) != plan.skin_cluster:
        raise RuntimeError(
            "Target skinCluster changed after Preview. Preview again:\n{}".format(
                plan.registration.mesh_shape
            )
        )
    adapter = SkinClusterAdapter.from_mesh(plan.registration.mesh_shape)
    if tuple(adapter.influences()) != plan.influences:
        raise RuntimeError(
            "Target influence order changed after Preview. Preview again:\n{}".format(
                plan.registration.mesh_shape
            )
        )


def _validate_final_influence_set(plan, current_influences) -> None:
    if len(current_influences) != len(set(current_influences)):
        raise RuntimeError("Target skinCluster contains duplicate influence paths.")
    if set(current_influences) != set(plan.final_influences):
        missing = sorted(set(plan.final_influences) - set(current_influences))
        unexpected = sorted(set(current_influences) - set(plan.final_influences))
        raise RuntimeError(
            "Target influence synchronization did not produce the planned exact set."
            "\n\nTarget: {}\nMissing: {}\nUnexpected: {}".format(
                plan.registration.mesh_shape,
                missing,
                unexpected,
            )
        )


def _target_vertex_ids(
    registration: TargetRegistration,
    vertex_count: int,
) -> np.ndarray:
    if registration.whole_object:
        return np.arange(int(vertex_count), dtype=np.int32)
    ids = np.asarray(registration.vertex_ids, dtype=np.int32).reshape(-1)
    if not ids.size:
        raise RuntimeError(
            "Component target has no registered vertices:\n{}".format(
                registration.mesh_shape
            )
        )
    invalid = ids[(ids < 0) | (ids >= int(vertex_count))]
    if invalid.size:
        raise RuntimeError(
            "Component target contains invalid vertex IDs on {}: {}".format(
                registration.mesh_shape,
                invalid[:20].tolist(),
            )
        )
    return np.unique(ids)


def _validate_registrations(sources, targets) -> None:
    if not sources:
        raise RuntimeError("Register at least one already-skinned source mesh.")
    if not targets:
        raise RuntimeError("Register at least one target mesh.")
    source_shapes = [item.mesh_shape for item in sources]
    target_shapes = [item.mesh_shape for item in targets]
    if len(source_shapes) != len(set(source_shapes)):
        raise RuntimeError("Source registration contains duplicate meshes.")
    if len(target_shapes) != len(set(target_shapes)):
        raise RuntimeError("Target registration contains duplicate meshes.")
    overlap = sorted(set(source_shapes) & set(target_shapes))
    if overlap:
        raise RuntimeError(
            "A mesh cannot be both source and target in one transfer:\n{}".format(
                "\n".join(overlap)
            )
        )


def _row_matrix(rows, influence_count: int, row_count: int) -> np.ndarray:
    influence_count = int(influence_count)
    row_count = int(row_count)
    if influence_count == 0:
        return np.empty((row_count, 0), dtype=np.float64)
    if not rows:
        return np.empty((0, influence_count), dtype=np.float64)
    return np.asarray(rows, dtype=np.float64).reshape(-1, influence_count)


def _validate_written_rows(adapter, vertex_ids, expected) -> None:
    stored = np.asarray(
        adapter.get_weights(vertex_ids).weights,
        dtype=np.float64,
    )
    expected = np.asarray(expected, dtype=np.float64)
    tolerance = 1.0e-8
    if not np.all(np.isfinite(stored)):
        raise RuntimeError("Transfer stored non-finite skin weights.")
    if np.any(stored < -tolerance):
        raise RuntimeError("Transfer stored negative skin weights.")
    if not np.allclose(stored, expected, rtol=0.0, atol=tolerance):
        changed = np.where(
            np.any(np.abs(stored - expected) > tolerance, axis=1)
        )[0][:20]
        raise RuntimeError(
            "Transfer did not store the calculated rows on {}. Vertex IDs: {}".format(
                adapter.mesh_shape,
                np.asarray(vertex_ids)[changed].tolist(),
            )
        )
    row_sums = np.sum(stored, axis=1, dtype=np.float64)
    bad = np.where(np.abs(row_sums - 1.0) > tolerance)[0]
    if bad.size:
        raise RuntimeError(
            "Transfer produced non-normalized rows on {}. Vertex IDs: {}".format(
                adapter.mesh_shape,
                np.asarray(vertex_ids)[bad[:20]].tolist(),
            )
        )


def _restore_selection(selection) -> None:
    existing = cmds.ls(selection, long=True, flatten=True) or []
    if existing:
        cmds.select(existing, replace=True)
    else:
        cmds.select(clear=True)


def print_preflight_report(preflight: TransferPreflight) -> None:
    print("\n[AD Skin Tool - Transfer Skin Weights Preview]")
    print("Sources:", len(preflight.sources))
    print("Source vertices:", preflight.source_vertex_count)
    print("Source triangles:", preflight.source_triangle_count)
    for index, source in enumerate(preflight.sources):
        print("  Source {}: {}".format(index + 1, source.mesh_transform))
        print("    SkinCluster:", source.skin_cluster)
        print("    Vertices:", source.vertex_count)
        print("    Triangles:", source.triangle_count)
    print("Targets:", len(preflight.target_plans))
    print("Unskinned targets planned for skinCluster creation:", preflight.unskinned_target_count)
    print("Requested target vertices:", preflight.requested_target_count)
    print("Writable target vertices:", preflight.writable_target_count)
    print("Influences planned to add to existing targets:", preflight.influence_addition_count)
    print("Influences planned to bind on new targets:", preflight.new_skin_influence_count)
    print("Fully locked targets:", preflight.fully_locked_target_count)
    print(
        "Vertices with no writable donor weight:",
        preflight.empty_donor_target_count,
    )
    print(
        "Exact-distance ties resolved by source order:",
        preflight.exact_distance_tie_count,
    )
    print("Average source-surface distance:", preflight.average_distance)
    print("Maximum source-surface distance:", preflight.maximum_distance)
    for plan in preflight.target_plans:
        print("  Target:", plan.registration.mesh_transform)
        print("    Scope:", plan.registration.scope_label)
        if plan.create_skin_cluster:
            print("    Target state: Unskinned - create skinCluster")
        else:
            print("    Target state: Existing skinCluster", plan.skin_cluster)
        print("    Requested:", plan.requested_count)
        print("    Writable after influence sync:", plan.writable_count)
        print("    Fully locked:", len(plan.fully_locked_vertex_ids))
        print(
            "    Vertices with no writable donor weight:",
            len(plan.empty_donor_vertex_ids),
        )
        print("    Winning source assignments:")
        for source_path, count in plan.source_assignment_counts:
            print("      {}: {} vertices".format(source_path, count))
        if plan.influences_to_add:
            label = (
                "    Exact influences to bind on new skinCluster:"
                if plan.create_skin_cluster
                else "    Exact influences to add:"
            )
            print(label)
            for path in plan.influences_to_add:
                print("      ", path)
    print("Valid:", preflight.valid)
    print("Partial:", preflight.partial)


def print_transfer_report(result: TransferResult) -> None:
    print("\n[AD Skin Tool - Transfer Skin Weights]")
    print("Sources:", result.source_count)
    print("Targets:", result.target_count)
    print("Created skinClusters:", result.created_skin_cluster_count)
    print("Requested target vertices:", result.requested_target_count)
    print("Transferred target vertices:", result.transferred_target_count)
    print("Exact influences added to existing targets:", result.added_influence_count)
    print("Exact influences bound on new targets:", result.new_skin_influence_count)
    print("Fully locked targets skipped:", result.fully_locked_target_count)
    print(
        "Vertices with no writable donor weight:",
        result.empty_donor_target_count,
    )
    print("Exact-distance ties resolved:", result.exact_distance_tie_count)
    print(
        "Maya undo: one step across",
        result.written_target_count,
        "writable targets",
    )
