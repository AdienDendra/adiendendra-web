"""One Maya undo command for a grouped collection of target weight writes."""

from dataclasses import dataclass
import os
import tempfile
from typing import Sequence, Tuple

import maya.api.OpenMaya as om
import maya.cmds as cmds

from ad_skin_tools.core.compat import ensure_numpy
from ad_skin_tools.core.skin_cluster import SkinClusterAdapter


np = ensure_numpy()
COMMAND_NAME = "adSkinTransferWeightMatrices"


@dataclass(frozen=True)
class TransferWriteRecord:
    skin_cluster: str
    mesh_shape: str
    vertex_ids: np.ndarray
    before_weights: np.ndarray
    after_weights: np.ndarray


def maya_useNewAPI():
    pass


def apply_grouped_transfer(records: Sequence[TransferWriteRecord]) -> None:
    normalized = tuple(_normalize_record(record) for record in records)
    if not normalized:
        raise RuntimeError("Transfer transaction has no writable target records.")
    _ensure_plugin_loaded()

    descriptor, payload_path = tempfile.mkstemp(
        prefix="ad_skin_transfer_",
        suffix=".npz",
    )
    os.close(descriptor)
    payload = {"record_count": np.asarray(len(normalized), dtype=np.int32)}
    for index, record in enumerate(normalized):
        payload["skin_cluster_{}".format(index)] = np.asarray(record.skin_cluster)
        payload["mesh_shape_{}".format(index)] = np.asarray(record.mesh_shape)
        payload["vertex_ids_{}".format(index)] = record.vertex_ids
        payload["before_weights_{}".format(index)] = record.before_weights
        payload["after_weights_{}".format(index)] = record.after_weights

    try:
        np.savez_compressed(payload_path, **payload)
        getattr(cmds, COMMAND_NAME)(payload_path)
    finally:
        try:
            if os.path.exists(payload_path):
                os.remove(payload_path)
        except Exception:
            pass


def _normalize_record(record: TransferWriteRecord) -> TransferWriteRecord:
    ids = np.asarray(record.vertex_ids, dtype=np.int32).reshape(-1)
    before = np.asarray(record.before_weights, dtype=np.float64)
    after = np.asarray(record.after_weights, dtype=np.float64)
    if not ids.size:
        raise RuntimeError("Transfer write record has no vertex IDs.")
    if before.ndim != 2 or before.shape != after.shape:
        raise RuntimeError("Transfer before/after matrices do not match.")
    if before.shape[0] != ids.size:
        raise RuntimeError("Transfer matrix row count does not match vertex IDs.")
    if not np.all(np.isfinite(before)) or not np.all(np.isfinite(after)):
        raise RuntimeError("Transfer write record contains non-finite weights.")
    return TransferWriteRecord(
        str(record.skin_cluster),
        str(record.mesh_shape),
        ids.copy(),
        before.copy(),
        after.copy(),
    )


def _ensure_plugin_loaded() -> None:
    plugin_path = os.path.abspath(__file__)
    plugin_name = os.path.splitext(os.path.basename(plugin_path))[0]
    try:
        loaded = bool(cmds.pluginInfo(plugin_name, query=True, loaded=True))
    except Exception:
        loaded = False
    if not loaded:
        cmds.loadPlugin(plugin_path, quiet=True)


class _TransferWeightMatricesCommand(om.MPxCommand):
    def __init__(self):
        super(_TransferWeightMatricesCommand, self).__init__()
        self._records: Tuple[TransferWriteRecord, ...] = ()

    @staticmethod
    def creator():
        return _TransferWeightMatricesCommand()

    def doIt(self, args):
        try:
            payload_path = args.asString(0)
        except (IndexError, RuntimeError, TypeError) as exc:
            raise RuntimeError(
                "{} requires one transaction payload path.\n\n{}".format(
                    COMMAND_NAME,
                    exc,
                )
            )
        records = []
        with np.load(payload_path, allow_pickle=False) as payload:
            count = int(payload["record_count"].item())
            for index in range(count):
                records.append(
                    TransferWriteRecord(
                        skin_cluster=str(
                            payload["skin_cluster_{}".format(index)].item()
                        ),
                        mesh_shape=str(
                            payload["mesh_shape_{}".format(index)].item()
                        ),
                        vertex_ids=np.asarray(
                            payload["vertex_ids_{}".format(index)],
                            dtype=np.int32,
                        ).copy(),
                        before_weights=np.asarray(
                            payload["before_weights_{}".format(index)],
                            dtype=np.float64,
                        ).copy(),
                        after_weights=np.asarray(
                            payload["after_weights_{}".format(index)],
                            dtype=np.float64,
                        ).copy(),
                    )
                )
        self._records = tuple(records)
        self.redoIt()

    def redoIt(self):
        self._write_transaction(use_after=True)

    def undoIt(self):
        self._write_transaction(use_after=False)

    def isUndoable(self):
        return True

    def _write_transaction(self, use_after: bool) -> None:
        order = list(range(len(self._records)))
        if not use_after:
            order.reverse()
        completed = []
        current = None
        try:
            for index in order:
                current = index
                record = self._records[index]
                self._write(
                    record,
                    record.after_weights if use_after else record.before_weights,
                )
                completed.append(index)
        except Exception:
            rollback_order = list(reversed(completed))
            if current is not None and current not in completed:
                rollback_order.insert(0, current)
            for index in rollback_order:
                record = self._records[index]
                try:
                    self._write(
                        record,
                        record.before_weights if use_after else record.after_weights,
                    )
                except Exception:
                    pass
            raise

    @staticmethod
    def _write(record: TransferWriteRecord, weights) -> None:
        adapter = SkinClusterAdapter(record.skin_cluster, record.mesh_shape)
        adapter.set_weights(record.vertex_ids, weights, normalize=False)


def initializePlugin(plugin_object):
    plugin = om.MFnPlugin(
        plugin_object,
        "AD Skin Tool",
        "1.0.0",
        "Any",
    )
    plugin.registerCommand(COMMAND_NAME, _TransferWeightMatricesCommand.creator)


def uninitializePlugin(plugin_object):
    plugin = om.MFnPlugin(plugin_object)
    plugin.deregisterCommand(COMMAND_NAME)
