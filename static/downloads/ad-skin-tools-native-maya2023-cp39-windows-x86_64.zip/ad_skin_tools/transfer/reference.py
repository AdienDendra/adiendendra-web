"""Reference geometry and accelerated closest-surface sampling."""

from dataclasses import dataclass
from typing import Tuple

import maya.api.OpenMaya as om
import maya.cmds as cmds

from ad_skin_tools.core.compat import ensure_numpy
from ad_skin_tools.core.mesh import get_dag_path
from ad_skin_tools.core.skin_cluster import SkinClusterAdapter
from ad_skin_tools.transfer import nearest
from ad_skin_tools.transfer.selection import SourceRegistration


np = ensure_numpy()
_BOUND_PADDING_MULTIPLIER = 1024.0


@dataclass
class SourceSurface:
    registration: SourceRegistration
    skin_cluster: str
    influences: Tuple[str, ...]
    vertex_count: int
    triangle_count: int
    world_positions: np.ndarray
    triangle_vertex_ids: np.ndarray
    triangle_offsets_by_face: np.ndarray
    weights: np.ndarray
    mesh_data: object
    mesh_object: object
    mesh_fn: object
    intersector: object
    aabb_minimum: np.ndarray
    aabb_maximum: np.ndarray
    obb_centre: np.ndarray
    obb_axes: object
    obb_minimum: np.ndarray
    obb_maximum: np.ndarray
    bound_guard: float


@dataclass(frozen=True)
class SurfaceSample:
    source_index: int
    source_mesh_shape: str
    triangle_vertex_ids: Tuple[int, int, int]
    barycentric: Tuple[float, float, float]
    distance: float
    source_face_id: int = -1
    source_point: Tuple[float, float, float] = (0.0, 0.0, 0.0)


def build_source_surface(registration: SourceRegistration) -> SourceSurface:
    """Build one immutable world-space source snapshot and spatial index."""

    adapter = SkinClusterAdapter.from_mesh(registration.mesh_shape)
    dag_path = get_dag_path(registration.mesh_shape)
    evaluated_mesh_fn = om.MFnMesh(dag_path)

    points = evaluated_mesh_fn.getPoints(om.MSpace.kWorld)
    world_positions = np.asarray(
        [_point_tuple(point) for point in points],
        dtype=np.float64,
    )
    if world_positions.shape[0] != adapter.vertex_count():
        raise RuntimeError(
            "Source evaluated vertex count does not match its skinCluster output: "
            "{} != {}".format(world_positions.shape[0], adapter.vertex_count())
        )

    polygon_counts, polygon_connects = evaluated_mesh_fn.getVertices()
    mesh_data = om.MFnMeshData().create()
    snapshot_mesh_fn = om.MFnMesh()
    mesh_object = snapshot_mesh_fn.create(
        points,
        polygon_counts,
        polygon_connects,
        parent=mesh_data,
    )

    triangle_counts, triangle_vertices = snapshot_mesh_fn.getTriangles()
    counts = np.asarray(triangle_counts, dtype=np.int32).reshape(-1)
    flattened = np.asarray(triangle_vertices, dtype=np.int32).reshape(-1)
    if flattened.size % 3:
        raise RuntimeError("Source mesh triangulation returned an invalid index array.")
    triangles = flattened.reshape(-1, 3)
    offsets = np.zeros(counts.size + 1, dtype=np.int32)
    if counts.size:
        offsets[1:] = np.cumsum(counts, dtype=np.int32)

    intersector = om.MMeshIntersector()
    intersector.create(mesh_object, om.MMatrix())
    if not intersector.isCreated:
        raise RuntimeError(
            "Unable to build closest-surface accelerator for source:\n{}".format(
                registration.mesh_transform
            )
        )

    bounds = _build_source_bounds(world_positions)
    vertex_ids = np.arange(adapter.vertex_count(), dtype=np.int32)
    skin_data = adapter.get_weights(vertex_ids)
    return SourceSurface(
        registration=registration,
        skin_cluster=adapter.skin_cluster,
        influences=tuple(skin_data.influences),
        vertex_count=adapter.vertex_count(),
        triangle_count=int(triangles.shape[0]),
        world_positions=world_positions,
        triangle_vertex_ids=triangles,
        triangle_offsets_by_face=offsets,
        weights=np.asarray(skin_data.weights, dtype=np.float64),
        mesh_data=mesh_data,
        mesh_object=mesh_object,
        mesh_fn=snapshot_mesh_fn,
        intersector=intersector,
        aabb_minimum=bounds["aabb_minimum"],
        aabb_maximum=bounds["aabb_maximum"],
        obb_centre=bounds["obb_centre"],
        obb_axes=bounds["obb_axes"],
        obb_minimum=bounds["obb_minimum"],
        obb_maximum=bounds["obb_maximum"],
        bound_guard=float(bounds["bound_guard"]),
    )


def closest_surface_sample(
    surface: SourceSurface,
    world_position,
    source_index: int,
) -> SurfaceSample:
    """Return the exact closest triangle sample from the world-space snapshot."""

    query = np.asarray(world_position, dtype=np.float64).reshape(3)
    point_on_mesh = surface.intersector.getClosestPoint(
        om.MPoint(float(query[0]), float(query[1]), float(query[2]))
    )
    if point_on_mesh is None:
        raise RuntimeError("Closest-point accelerator returned no source sample.")

    face_id = int(_value_or_call(point_on_mesh, "face"))
    local_triangle = int(_value_or_call(point_on_mesh, "triangle"))
    if face_id < 0 or face_id + 1 >= surface.triangle_offsets_by_face.size:
        raise RuntimeError("Closest-point query returned an invalid source face ID.")

    start = int(surface.triangle_offsets_by_face[face_id])
    end = int(surface.triangle_offsets_by_face[face_id + 1])
    triangle_row = start + local_triangle
    if local_triangle < 0 or triangle_row >= end:
        raise RuntimeError("Closest-point query returned an invalid source triangle ID.")

    triangle_ids = surface.triangle_vertex_ids[triangle_row]
    uv = _value_or_call(point_on_mesh, "barycentricCoords")
    bary = nearest.barycentric_from_maya_uv(float(uv[0]), float(uv[1]))
    reconstructed = np.sum(
        surface.world_positions[triangle_ids] * bary[:, np.newaxis],
        axis=0,
    )
    distance = float(np.linalg.norm(reconstructed - query))
    return SurfaceSample(
        source_index=int(source_index),
        source_mesh_shape=surface.registration.mesh_shape,
        source_face_id=face_id,
        source_point=tuple(float(value) for value in reconstructed.tolist()),
        triangle_vertex_ids=tuple(int(value) for value in triangle_ids.tolist()),
        barycentric=tuple(float(value) for value in bary.tolist()),
        distance=distance,
    )


def source_lower_bound(surface: SourceSurface, world_position) -> float:
    """Return a conservative AABB/PCA-OBB lower bound to one source surface."""

    query = np.asarray(world_position, dtype=np.float64).reshape(3)
    if not np.all(np.isfinite(query)):
        return 0.0

    aabb_distance = _distance_to_box(
        query,
        surface.aabb_minimum,
        surface.aabb_maximum,
    )
    raw_lower_bound = aabb_distance

    if surface.obb_axes is not None:
        query_local = np.matmul(
            query - surface.obb_centre,
            surface.obb_axes,
        )
        obb_distance = _distance_to_box(
            query_local,
            surface.obb_minimum,
            surface.obb_maximum,
        )
        raw_lower_bound = max(raw_lower_bound, obb_distance)

    if not np.isfinite(raw_lower_bound):
        return 0.0

    return max(
        0.0,
        float(raw_lower_bound) - float(surface.bound_guard),
    )


def _build_source_bounds(world_positions):
    points = np.asarray(world_positions, dtype=np.float64).reshape(-1, 3)
    if not points.size or not np.all(np.isfinite(points)):
        raise RuntimeError("Source world positions contain no finite geometry.")

    coordinate_scale = float(np.max(np.abs(points)))
    extents = np.max(points, axis=0) - np.min(points, axis=0)
    extent_scale = float(np.max(np.abs(extents)))
    numerical_scale = max(1.0, coordinate_scale, extent_scale)
    padding = (
        float(np.finfo(np.float64).eps)
        * numerical_scale
        * _BOUND_PADDING_MULTIPLIER
    )

    aabb_minimum = np.min(points, axis=0) - padding
    aabb_maximum = np.max(points, axis=0) + padding
    centre = np.mean(points, axis=0, dtype=np.float64)

    obb_axes = None
    obb_minimum = np.zeros(3, dtype=np.float64)
    obb_maximum = np.zeros(3, dtype=np.float64)
    try:
        centred = points - centre
        covariance = np.matmul(centred.T, centred)
        if np.all(np.isfinite(covariance)):
            _eigenvalues, axes = np.linalg.eigh(covariance)
            if np.all(np.isfinite(axes)):
                local_points = np.matmul(centred, axes)
                local_minimum = np.min(local_points, axis=0) - padding
                local_maximum = np.max(local_points, axis=0) + padding
                if (
                    np.all(np.isfinite(local_minimum))
                    and np.all(np.isfinite(local_maximum))
                ):
                    obb_axes = axes
                    obb_minimum = local_minimum
                    obb_maximum = local_maximum
    except Exception:
        # AABB remains a valid conservative fallback for degenerate PCA cases.
        obb_axes = None

    return {
        "aabb_minimum": aabb_minimum,
        "aabb_maximum": aabb_maximum,
        "obb_centre": centre,
        "obb_axes": obb_axes,
        "obb_minimum": obb_minimum,
        "obb_maximum": obb_maximum,
        "bound_guard": padding * 4.0,
    }


def _distance_to_box(point, minimum, maximum) -> float:
    outside = np.maximum(
        np.maximum(
            np.asarray(minimum, dtype=np.float64) - point,
            point - np.asarray(maximum, dtype=np.float64),
        ),
        0.0,
    )
    return float(np.linalg.norm(outside))


def bind_mesh_positions(mesh_shape: str, skin_cluster: str) -> np.ndarray:
    adapter = SkinClusterAdapter(skin_cluster, mesh_shape)
    geometry_index = int(
        adapter.skin_fn.indexForOutputShape(adapter.mesh_dag_path.node())
    )
    input_object = _input_mesh_object(adapter, geometry_index)
    points = om.MFnMesh(input_object).getPoints(om.MSpace.kObject)
    matrix = _geometry_bind_matrix(adapter.skin_cluster)
    positions = np.asarray(
        [_point_tuple(om.MPoint(point) * matrix) for point in points],
        dtype=np.float64,
    )
    if positions.shape[0] != adapter.vertex_count():
        raise RuntimeError(
            "Target pre-skin vertex count does not match its skinCluster output: "
            "{} != {}".format(positions.shape[0], adapter.vertex_count())
        )
    return positions


def current_mesh_world_positions(mesh_shape: str) -> np.ndarray:
    """Return current world positions for an unskinned target mesh."""

    dag_path = get_dag_path(mesh_shape)
    mesh_fn = om.MFnMesh(dag_path)
    points = mesh_fn.getPoints(om.MSpace.kWorld)
    positions = np.asarray(
        [_point_tuple(point) for point in points],
        dtype=np.float64,
    )
    if positions.shape != (int(mesh_fn.numVertices), 3):
        raise RuntimeError(
            "Unable to read current world positions for unskinned target:\n{}".format(
                mesh_shape
            )
        )
    return positions


def _input_mesh_object(adapter, geometry_index: int):
    try:
        return adapter.skin_fn.inputShapeAtIndex(int(geometry_index))
    except Exception:
        pass

    plug = "{}.input[{}].inputGeometry".format(
        adapter.skin_cluster,
        geometry_index,
    )
    source_shapes = cmds.listConnections(
        plug,
        source=True,
        destination=False,
        shapes=True,
    ) or []
    for node in source_shapes:
        matches = cmds.ls(node, long=True, type="mesh") or []
        if matches:
            return get_dag_path(matches[0]).node()
    raise RuntimeError(
        "Unable to resolve pre-skin input geometry for {}.".format(
            adapter.mesh_shape
        )
    )


def _geometry_bind_matrix(skin_cluster: str):
    attribute = "{}.geomMatrix".format(skin_cluster)
    if not cmds.objExists(attribute):
        raise RuntimeError(
            "The skinCluster does not expose geomMatrix:\n{}".format(skin_cluster)
        )
    return om.MMatrix(_flatten_matrix_value(cmds.getAttr(attribute)))


def _flatten_matrix_value(value):
    current = value
    while isinstance(current, (list, tuple)) and len(current) == 1:
        current = current[0]
    if not isinstance(current, (list, tuple)) or len(current) != 16:
        raise RuntimeError("geomMatrix did not return a 4x4 matrix value.")
    return [float(item) for item in current]


def _value_or_call(instance, name):
    """Return an attribute value or call it for Maya API compatibility objects."""

    value = getattr(instance, name)
    return value() if callable(value) else value


def _point_tuple(point):
    return float(point.x), float(point.y), float(point.z)
