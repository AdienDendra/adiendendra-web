"""Canonical in-window UI for flexible barycentric skin-weight transfer."""

from collections import Counter, OrderedDict
from contextlib import contextmanager

import maya.cmds as cmds
from maya import OpenMayaUI as omui

from ad_skin_tools.core.compat import import_qt_modules
from ad_skin_tools.transfer import operation, selection
from ad_skin_tools.ui import qt_helpers


CTRL_TITLE_RESET = "adSkin_transferResetButton"
CTRL_SOURCE_LABEL = "adSkin_transferSourceLabel"
CTRL_SOURCE_LIST = "adSkin_transferSourceList"
CTRL_SOURCE_ADD = "adSkin_transferSourceAdd"
CTRL_SOURCE_REMOVE = "adSkin_transferSourceRemove"
CTRL_SOURCE_CLEAR = "adSkin_transferSourceClear"
CTRL_TARGET_LABEL = "adSkin_transferTargetLabel"
CTRL_TARGET_LIST = "adSkin_transferTargetList"
CTRL_TARGET_ADD = "adSkin_transferTargetAdd"
CTRL_TARGET_REMOVE = "adSkin_transferTargetRemove"
CTRL_TARGET_CLEAR = "adSkin_transferTargetClear"
CTRL_PREVIEW = "adSkin_transferPreviewButton"
CTRL_APPLY = "adSkin_transferApplyButton"
CTRL_STATUS = "adSkin_transferStatus"
CTRL_SOURCE_CONTEXT_MENU = "adSkin_transferSourceContextMenu"
CTRL_TARGET_CONTEXT_MENU = "adSkin_transferTargetContextMenu"

VISIBLE_ROWS = 8
LIST_HEIGHT = 144

_TOOL_WINDOW = None
_SKIN_OPERATIONS = None
_SOURCES = OrderedDict()
_TARGETS = OrderedDict()
_SOURCE_LABEL_TO_SHAPE = {}
_TARGET_LABEL_TO_SHAPE = {}
_PREFLIGHT = None
_SCOPE_RESOLUTION = None
_UI_REGISTRATION_SIGNATURE = None
_PREVIEW_HANDLER = None
_APPLY_HANDLER = None
_INVALIDATE_HANDLER = None


def install(tool_window_module, skin_operations_module) -> None:
    """Configure Transfer services without replacing peer-module functions."""

    global _TOOL_WINDOW, _SKIN_OPERATIONS

    _TOOL_WINDOW = tool_window_module
    _SKIN_OPERATIONS = skin_operations_module
    _SKIN_OPERATIONS.register_common_enabled_callback(_set_common_enabled)


def install_post_show() -> None:
    """Apply native Qt scroll policies after Maya has created both lists."""

    try:
        QtWidgets, _QtGui, QtCore, binding_name = import_qt_modules()
        always_on = _enum_value(
            QtCore.Qt,
            "ScrollBarAlwaysOn",
            "ScrollBarPolicy",
        )
        scroll_per_item = _enum_value(
            QtWidgets.QAbstractItemView,
            "ScrollPerItem",
            "ScrollMode",
        )
        scroll_per_pixel = _enum_value(
            QtWidgets.QAbstractItemView,
            "ScrollPerPixel",
            "ScrollMode",
        )
        adjust_ignored = _enum_value(
            QtWidgets.QAbstractScrollArea,
            "AdjustIgnored",
            "SizeAdjustPolicy",
        )
        elide_none = _enum_value(
            QtCore.Qt,
            "ElideNone",
            "TextElideMode",
        )

        for control_name in (CTRL_SOURCE_LIST, CTRL_TARGET_LIST):
            view = _wrap_list_view(control_name, QtWidgets, binding_name)
            if view is None:
                continue
            view.setSizeAdjustPolicy(adjust_ignored)
            view.setVerticalScrollBarPolicy(always_on)
            view.setHorizontalScrollBarPolicy(always_on)
            view.setVerticalScrollMode(scroll_per_item)
            view.setHorizontalScrollMode(scroll_per_pixel)
            view.setTextElideMode(elide_none)
            view.setWordWrap(False)
            view.setWrapping(False)
            view.setMinimumWidth(0)
            view.horizontalScrollBar().setSingleStep(12)
            view.verticalScrollBar().setSingleStep(1)
            view.horizontalScrollBar().show()
            view.verticalScrollBar().show()
            view.updateGeometries()
            view.updateGeometry()
            view.viewport().update()
    except Exception as exc:
        cmds.warning("AD Skin Tool Transfer scrollbar setup skipped: {}".format(exc))


def shutdown() -> None:
    global _TOOL_WINDOW, _SKIN_OPERATIONS
    global _PREFLIGHT, _SCOPE_RESOLUTION, _UI_REGISTRATION_SIGNATURE
    global _PREVIEW_HANDLER, _APPLY_HANDLER, _INVALIDATE_HANDLER

    if _SKIN_OPERATIONS is not None:
        _SKIN_OPERATIONS.unregister_common_enabled_callback(
            _set_common_enabled
        )

    _TOOL_WINDOW = None
    _SKIN_OPERATIONS = None
    _PREFLIGHT = None
    _SCOPE_RESOLUTION = None
    _UI_REGISTRATION_SIGNATURE = None
    _PREVIEW_HANDLER = None
    _APPLY_HANDLER = None
    _INVALIDATE_HANDLER = None


def configure_actions(
    preview_handler=None,
    apply_handler=None,
    invalidate_handler=None,
) -> None:
    """Configure optional production action handlers explicitly."""

    global _PREVIEW_HANDLER, _APPLY_HANDLER, _INVALIDATE_HANDLER
    _PREVIEW_HANDLER = preview_handler
    _APPLY_HANDLER = apply_handler
    _INVALIDATE_HANDLER = invalidate_handler


def _build_transfer_controls() -> None:
    _build_title_row()
    _build_registration_list(
        label_control=CTRL_SOURCE_LABEL,
        list_control=CTRL_SOURCE_LIST,
        label="Sources (0)",
    )
    _SKIN_OPERATIONS._named_button_row(
        [
            (CTRL_SOURCE_ADD, "Add Selected", lambda *_: add_selected_sources()),
            (
                CTRL_SOURCE_REMOVE,
                "Remove Selected",
                lambda *_: remove_selected_sources(),
            ),
            (CTRL_SOURCE_CLEAR, "Clear", lambda *_: clear_sources()),
        ],
        height=28,
    )

    _build_registration_list(
        label_control=CTRL_TARGET_LABEL,
        list_control=CTRL_TARGET_LIST,
        label="Targets (0)",
    )
    _SKIN_OPERATIONS._named_button_row(
        [
            (CTRL_TARGET_ADD, "Add Selected", lambda *_: add_selected_targets()),
            (
                CTRL_TARGET_REMOVE,
                "Remove Selected",
                lambda *_: remove_selected_targets(),
            ),
            (CTRL_TARGET_CLEAR, "Clear", lambda *_: clear_targets()),
        ],
        height=28,
    )

    _SKIN_OPERATIONS._named_button_row(
        [
            (CTRL_PREVIEW, "Preview Transfer", lambda *_: preview_transfer()),
            (CTRL_APPLY, "Transfer Skin Weights", lambda *_: apply_transfer()),
        ],
        height=36,
    )
    cmds.text(
        CTRL_STATUS,
        label="",
        align="left",
        wordWrap=True,
        visible=False,
    )
    _refresh_registration_lists()
    _install_context_menu(
        CTRL_SOURCE_LIST,
        CTRL_SOURCE_CONTEXT_MENU,
        "source",
    )
    _install_context_menu(
        CTRL_TARGET_LIST,
        CTRL_TARGET_CONTEXT_MENU,
        "target",
    )


def _build_title_row() -> None:
    layout = cmds.formLayout(height=24)
    title = cmds.text(
        label="Transfer Skin Weights",
        align="left",
        font="boldLabelFont",
    )
    reset_button = cmds.button(
        CTRL_TITLE_RESET,
        label="Reset",
        width=64,
        height=22,
        command=lambda *_: reset_transfer(),
    )
    cmds.formLayout(
        layout,
        edit=True,
        attachForm=[
            (title, "left", 0),
            (title, "top", 3),
            (title, "bottom", 2),
            (reset_button, "right", 0),
            (reset_button, "top", 1),
            (reset_button, "bottom", 1),
        ],
        attachControl=[(title, "right", 8, reset_button)],
    )
    cmds.setParent("..")


def _build_registration_list(label_control, list_control, label) -> None:
    cmds.text(
        label_control,
        label=label,
        align="left",
        font="boldLabelFont",
    )
    cmds.textScrollList(
        list_control,
        allowMultiSelection=True,
        numberOfRows=VISIBLE_ROWS,
        height=LIST_HEIGHT,
    )


def _install_context_menu(control: str, menu_name: str, list_kind: str) -> None:
    if cmds.popupMenu(menu_name, exists=True):
        try:
            cmds.deleteUI(menu_name)
        except Exception:
            pass
    cmds.popupMenu(
        menu_name,
        parent=control,
        button=3,
        postMenuCommand=lambda menu, *_: _populate_context_menu(menu, list_kind),
    )


def _populate_context_menu(menu: str, list_kind: str) -> None:
    cmds.popupMenu(menu, edit=True, deleteAllItems=True)
    cmds.menuItem(
        label="Select Object In The Scene",
        parent=menu,
        command=lambda *_: select_objects_in_scene(list_kind, select_all=False),
    )
    cmds.menuItem(
        label="Select All Objects In The Scene",
        parent=menu,
        command=lambda *_: select_objects_in_scene(list_kind, select_all=True),
    )


def select_objects_in_scene(list_kind: str, select_all: bool = False) -> None:
    try:
        _TOOL_WINDOW._require_not_busy()
        registrations, control, label_map = _list_context(list_kind)
        if select_all:
            requested = list(registrations.values())
        else:
            labels = cmds.textScrollList(
                control,
                query=True,
                selectItem=True,
            ) or []
            if not labels:
                cmds.warning("No objects selected in the list.")
                return
            requested = []
            for label in labels:
                shape = label_map.get(label)
                item = registrations.get(shape) if shape else None
                if item is not None:
                    requested.append(item)

        existing = []
        seen = set()
        for item in requested:
            matches = cmds.ls(
                item.mesh_transform,
                long=True,
                type="transform",
            ) or []
            path = str(item.mesh_transform)
            if path in matches and path not in seen:
                seen.add(path)
                existing.append(path)

        if not existing:
            cmds.warning("Registered list objects no longer exist in the scene.")
            return
        cmds.select(existing, replace=True)
        _TOOL_WINDOW._info(
            "Selected {} {} object(s) in the Maya scene.".format(
                len(existing),
                list_kind,
            )
        )
    except Exception as exc:
        _TOOL_WINDOW._show_error(exc)


def _list_context(list_kind: str):
    if list_kind == "source":
        return _SOURCES, CTRL_SOURCE_LIST, _SOURCE_LABEL_TO_SHAPE
    if list_kind == "target":
        return _TARGETS, CTRL_TARGET_LIST, _TARGET_LABEL_TO_SHAPE
    raise ValueError("Unknown Transfer object-list kind: {}".format(list_kind))


def add_selected_sources() -> None:
    try:
        _TOOL_WINDOW._require_not_busy()
        additions = selection.collect_selected_sources()
        target_shapes = set(_TARGETS)
        overlap = [
            item.mesh_shape for item in additions if item.mesh_shape in target_shapes
        ]
        if overlap:
            raise RuntimeError(
                "A registered target cannot also be a source:\n{}".format(
                    "\n".join(overlap)
                )
            )
        added_count = 0
        for item in additions:
            if item.mesh_shape not in _SOURCES:
                _SOURCES[item.mesh_shape] = item
                added_count += 1
        _invalidate_preflight()
        _refresh_registration_lists()
        if added_count:
            _TOOL_WINDOW._info(
                "Registered {} source mesh(es).".format(added_count)
            )
        else:
            cmds.warning("Selected source objects already exist in the list.")
    except Exception as exc:
        _TOOL_WINDOW._show_error(exc)


def add_selected_targets() -> None:
    try:
        _TOOL_WINDOW._require_not_busy()
        additions = selection.collect_selected_targets()
        source_shapes = set(_SOURCES)
        overlap = [
            item.mesh_shape for item in additions if item.mesh_shape in source_shapes
        ]
        if overlap:
            raise RuntimeError(
                "A registered source cannot also be a target:\n{}".format(
                    "\n".join(overlap)
                )
            )
        added_count = 0
        for item in additions:
            if item.mesh_shape not in _TARGETS:
                _TARGETS[item.mesh_shape] = item
                added_count += 1
        _invalidate_preflight()
        _refresh_registration_lists()
        if added_count:
            _TOOL_WINDOW._info(
                "Registered {} target mesh object(s).".format(added_count)
            )
        else:
            cmds.warning("Selected target objects already exist in the list.")
    except Exception as exc:
        _TOOL_WINDOW._show_error(exc)


def remove_selected_sources() -> None:
    labels = cmds.textScrollList(CTRL_SOURCE_LIST, query=True, selectItem=True) or []
    for label in labels:
        shape = _SOURCE_LABEL_TO_SHAPE.get(label)
        if shape:
            _SOURCES.pop(shape, None)
    _invalidate_preflight()
    _refresh_registration_lists()


def remove_selected_targets() -> None:
    labels = cmds.textScrollList(CTRL_TARGET_LIST, query=True, selectItem=True) or []
    for label in labels:
        shape = _TARGET_LABEL_TO_SHAPE.get(label)
        if shape:
            _TARGETS.pop(shape, None)
    _invalidate_preflight()
    _refresh_registration_lists()


def clear_sources() -> None:
    _SOURCES.clear()
    _invalidate_preflight()
    _refresh_registration_lists()


def clear_targets() -> None:
    _TARGETS.clear()
    _invalidate_preflight()
    _refresh_registration_lists()


def reset_transfer() -> None:
    try:
        _TOOL_WINDOW._require_not_busy()
        _SOURCES.clear()
        _TARGETS.clear()
        _invalidate_preflight()
        _refresh_registration_lists()
        _TOOL_WINDOW._info("Transfer registrations reset.")
    except Exception as exc:
        _TOOL_WINDOW._show_error(exc)


def preview_transfer() -> None:
    """Run the configured Preview action or the canonical fallback."""

    if _PREVIEW_HANDLER is not None:
        return _PREVIEW_HANDLER()
    return _preview_transfer_default()


def _preview_transfer_default() -> None:
    global _PREFLIGHT, _SCOPE_RESOLUTION, _UI_REGISTRATION_SIGNATURE
    try:
        _TOOL_WINDOW._require_not_busy()
        _require_registrations()
        _set_transfer_busy(True, "Calculating closest source surfaces...")
        with _wait_cursor():
            resolution = selection.resolve_registered_target_scopes(
                tuple(_TARGETS.values())
            )
            preflight = operation.build_preflight(
                tuple(_SOURCES.values()),
                resolution.effective_targets,
            )
        _SCOPE_RESOLUTION = resolution
        _UI_REGISTRATION_SIGNATURE = _current_ui_registration_signature()
        _PREFLIGHT = preflight
        selection.print_target_scope_report(resolution)
        operation.print_preflight_report(preflight)
        _set_status(_preflight_status(preflight))
        if preflight.valid:
            qualifier = "partial" if preflight.partial else "valid"
            _TOOL_WINDOW._info(
                "Transfer preview {}: {} writable target vertices.".format(
                    qualifier,
                    preflight.writable_target_count,
                )
            )
        else:
            cmds.warning(_preflight_status(preflight))
    except Exception as exc:
        _PREFLIGHT = None
        _SCOPE_RESOLUTION = None
        _UI_REGISTRATION_SIGNATURE = None
        _set_status("Transfer preview failed; see the error details.")
        _TOOL_WINDOW._show_error(exc)
    finally:
        _set_transfer_busy(False)


def apply_transfer() -> None:
    """Run the configured Apply action or the canonical fallback."""

    if _APPLY_HANDLER is not None:
        return _APPLY_HANDLER()
    return _apply_transfer_default()


def _apply_transfer_default() -> None:
    global _PREFLIGHT, _SCOPE_RESOLUTION, _UI_REGISTRATION_SIGNATURE
    try:
        _TOOL_WINDOW._require_not_busy()
        if _PREFLIGHT is None or _SCOPE_RESOLUTION is None:
            raise RuntimeError("Run Preview Transfer before applying weights.")
        if _current_ui_registration_signature() != _UI_REGISTRATION_SIGNATURE:
            raise RuntimeError(
                "Source or target object registration changed after Preview. "
                "Preview again."
            )

        _set_transfer_busy(True, "Calculating and applying Transfer weights...")
        with _wait_cursor():
            fresh = operation.build_preflight(
                _PREFLIGHT.source_registrations,
                _PREFLIGHT.target_registrations,
            )
            if fresh.structural_signature != _PREFLIGHT.structural_signature:
                raise RuntimeError(
                    "A source/target skinCluster, influence order, or captured "
                    "component scope changed after Preview. Preview again."
                )
            result = operation.apply_transfer(fresh)

        _PREFLIGHT = None
        _SCOPE_RESOLUTION = None
        _UI_REGISTRATION_SIGNATURE = None
        operation.print_transfer_report(result)
        _refresh_registration_lists()
        _set_status(_result_status(result))
        _TOOL_WINDOW._info(
            "Transfer complete: {} vertices across {} active target mesh(es).".format(
                result.transferred_target_count,
                result.target_count,
            )
        )
        _request_weight_preview_refresh()
    except Exception as exc:
        _set_status("Transfer failed; no partial multi-target write was kept.")
        _TOOL_WINDOW._show_error(exc)
    finally:
        _set_transfer_busy(False)


def _require_registrations() -> None:
    if not _SOURCES:
        raise RuntimeError("Register at least one source mesh.")
    if not _TARGETS:
        raise RuntimeError("Register at least one target mesh or component scope.")


def _refresh_registration_lists() -> None:
    global _SOURCE_LABEL_TO_SHAPE, _TARGET_LABEL_TO_SHAPE

    if cmds.textScrollList(CTRL_SOURCE_LIST, exists=True):
        cmds.textScrollList(CTRL_SOURCE_LIST, edit=True, removeAll=True)
        source_labels = _unique_display_labels(tuple(_SOURCES.values()))
        _SOURCE_LABEL_TO_SHAPE = {}
        for item in _SOURCES.values():
            label = source_labels[item.mesh_shape]
            _SOURCE_LABEL_TO_SHAPE[label] = item.mesh_shape
            cmds.textScrollList(CTRL_SOURCE_LIST, edit=True, append=label)
    if cmds.text(CTRL_SOURCE_LABEL, exists=True):
        cmds.text(
            CTRL_SOURCE_LABEL,
            edit=True,
            label="Sources ({})".format(len(_SOURCES)),
        )

    if cmds.textScrollList(CTRL_TARGET_LIST, exists=True):
        cmds.textScrollList(CTRL_TARGET_LIST, edit=True, removeAll=True)
        target_labels = _unique_display_labels(tuple(_TARGETS.values()))
        _TARGET_LABEL_TO_SHAPE = {}
        for item in _TARGETS.values():
            label = target_labels[item.mesh_shape]
            _TARGET_LABEL_TO_SHAPE[label] = item.mesh_shape
            cmds.textScrollList(CTRL_TARGET_LIST, edit=True, append=label)
    if cmds.text(CTRL_TARGET_LABEL, exists=True):
        cmds.text(
            CTRL_TARGET_LABEL,
            edit=True,
            label="Targets ({})".format(len(_TARGETS)),
        )


def _unique_display_labels(registrations):
    registrations = tuple(registrations)
    leaf_by_shape = {
        item.mesh_shape: _leaf_name(item.mesh_transform) for item in registrations
    }
    leaf_counts = Counter(leaf_by_shape.values())
    result = {}
    used = set()

    for item in registrations:
        leaf = leaf_by_shape[item.mesh_shape]
        if leaf_counts[leaf] == 1:
            label = leaf
        else:
            segments = [
                segment for segment in str(item.mesh_transform).split("|") if segment
            ]
            ancestors = segments[:-1]
            label = leaf
            for depth in range(1, len(ancestors) + 1):
                hint = "/".join(ancestors[-depth:])
                candidate = "{} [{}]".format(leaf, hint)
                if candidate not in used:
                    label = candidate
                    break
        if label in used:
            index = 2
            candidate = "{} [{}]".format(label, index)
            while candidate in used:
                index += 1
                candidate = "{} [{}]".format(label, index)
            label = candidate
        used.add(label)
        result[item.mesh_shape] = label
    return result


def _leaf_name(path: str) -> str:
    return str(path).rsplit("|", 1)[-1]


def _invalidate_preflight(clear_status=True) -> None:
    """Invalidate Preview through the configured action boundary."""

    if _INVALIDATE_HANDLER is not None:
        _INVALIDATE_HANDLER(clear_status=clear_status)
        return
    clear_preflight_state(clear_status=clear_status)


def clear_preflight_state(clear_status=True) -> None:
    """Clear canonical UI Preview state without action dispatch."""

    global _PREFLIGHT, _SCOPE_RESOLUTION, _UI_REGISTRATION_SIGNATURE
    _PREFLIGHT = None
    _SCOPE_RESOLUTION = None
    _UI_REGISTRATION_SIGNATURE = None
    if clear_status:
        _set_status("")


def _current_ui_registration_signature():
    return tuple(_SOURCES.keys()), tuple(_TARGETS.keys())


def _preflight_status(preflight) -> str:
    if not preflight.valid:
        prefix = "Preview incomplete"
    elif preflight.partial:
        prefix = "Preview partial"
    else:
        prefix = "Preview valid"
    registered_count = (
        len(_SCOPE_RESOLUTION.registered_targets)
        if _SCOPE_RESOLUTION is not None
        else len(preflight.target_plans)
    )
    skipped_count = (
        len(_SCOPE_RESOLUTION.skipped_targets)
        if _SCOPE_RESOLUTION is not None
        else 0
    )
    mode = (
        "component"
        if _SCOPE_RESOLUTION is not None and _SCOPE_RESOLUTION.component_mode
        else "whole-object"
    )
    return (
        "{}: {} mode, {} registered / {} active / {} skipped targets, "
        "{} requested, {} writable; {} fully locked, {} vertices with no "
        "writable donor weight. Max distance {:.6f}."
    ).format(
        prefix,
        mode,
        registered_count,
        len(preflight.target_plans),
        skipped_count,
        preflight.requested_target_count,
        preflight.writable_target_count,
        preflight.fully_locked_target_count,
        preflight.empty_donor_target_count,
        preflight.maximum_distance,
    )


def _result_status(result) -> str:
    return (
        "Transfer complete: {} / {} requested vertices across {} active targets; "
        "{} skinClusters created. Skipped vertices: {} fully locked, {} with no "
        "writable donor weight."
    ).format(
        result.transferred_target_count,
        result.requested_target_count,
        result.target_count,
        result.created_skin_cluster_count,
        result.fully_locked_target_count,
        result.empty_donor_target_count,
    )


def _set_status(message: str) -> None:
    if not cmds.text(CTRL_STATUS, exists=True):
        return
    cmds.text(
        CTRL_STATUS,
        edit=True,
        label=str(message),
        visible=bool(message),
    )


def _set_common_enabled(enabled) -> None:
    enabled = bool(enabled)
    controls = (
        (cmds.button, CTRL_TITLE_RESET),
        (cmds.textScrollList, CTRL_SOURCE_LIST),
        (cmds.button, CTRL_SOURCE_ADD),
        (cmds.button, CTRL_SOURCE_REMOVE),
        (cmds.button, CTRL_SOURCE_CLEAR),
        (cmds.textScrollList, CTRL_TARGET_LIST),
        (cmds.button, CTRL_TARGET_ADD),
        (cmds.button, CTRL_TARGET_REMOVE),
        (cmds.button, CTRL_TARGET_CLEAR),
        (cmds.button, CTRL_PREVIEW),
        (cmds.button, CTRL_APPLY),
    )
    for control_type, name in controls:
        if control_type(name, exists=True):
            control_type(name, edit=True, enable=enabled)


def _set_transfer_busy(busy, status="") -> None:
    busy = bool(busy)
    if _TOOL_WINDOW is not None:
        _TOOL_WINDOW._STATE["busy"] = busy
    if _SKIN_OPERATIONS is not None:
        _SKIN_OPERATIONS._set_common_enabled(not busy)
    if busy:
        _set_status(status)
    try:
        cmds.refresh(force=True)
    except Exception:
        pass


def _request_weight_preview_refresh() -> None:
    callback = _TOOL_WINDOW._STATE.get("skin_weight_mode_refresh")
    if callable(callback):
        callback()


def _wrap_list_view(control_name, QtWidgets, binding_name):
    pointer = omui.MQtUtil.findControl(control_name)
    if not pointer:
        return None
    try:
        return qt_helpers.wrap_instance(
            pointer,
            QtWidgets.QListView,
            binding_name,
        )
    except (RuntimeError, TypeError):
        return None


def _enum_value(owner, name, scoped_name):
    if hasattr(owner, name):
        return getattr(owner, name)
    return getattr(getattr(owner, scoped_name), name)


@contextmanager
def _wait_cursor():
    active = False
    try:
        cmds.waitCursor(state=True)
        active = True
        cmds.refresh(force=True)
        yield
    finally:
        if active:
            try:
                cmds.waitCursor(state=False)
            except Exception:
                pass
