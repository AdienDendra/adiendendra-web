"""Diagnostic-only validation for closest-surface skin-weight transfers.

This module intentionally does not replace or modify the production Transfer
operation. It re-samples the same closest-surface correspondence after a
transfer has been written, then evaluates continuity across target mesh edges.

Run from Maya's Script Editor, for example::

    import importlib
    from ad_skin_tools.transfer import donor_diagnostics

    importlib.reload(donor_diagnostics)

    result = donor_diagnostics.run(
        source_meshes=["Cbody1aOSDM"],
        target_meshes=["Ccoat1aCSDM2"],
        select_suspects=True,
    )

The diagnostic never writes skin weights. Its only optional scene mutation is
selecting suspicious target vertices or creating Maya sets for inspection.
"""

from typing import Dict, Iterable, List, Sequence, Tuple

import maya.api.OpenMaya as om
import maya.cmds as cmds

from ad_skin_tools.core.mesh import get_all_vertex_neighbors, get_dag_path
from ad_skin_tools.core.skin_cluster import SkinClusterAdapter, find_skin_cluster
from ad_skin_tools.runtime.compatibility import ensure_numpy
from ad_skin_tools.transfer import nearest
from ad_skin_tools.transfer import reference
from ad_skin_tools.transfer.data import (
    DiagnosticThresholds,
    DonorDiagnosticResult,
    DonorSample,
    EdgeDiagnostic,
    TargetDiagnosticResult,
)
from ad_skin_tools.transfer.diagnostic_solver import (
    bounded_face_ring_distance as _bounded_face_ring_distance,
    connected_components_from_edges as _connected_components_from_edges,
    correspondence_stretch as _correspondence_stretch,
    edge_severity as _edge_severity,
    unique_edges as _unique_edges,
    weight_jump as _weight_jump,
)
from ad_skin_tools.transfer.selection import SourceRegistration


np = ensure_numpy()


class _SourceFaceTopology:
    """Full polygon adjacency for one source mesh."""

    def __init__(self, mesh_shape: str):
        self.mesh_shape = str(mesh_shape)
        self.adjacency = _build_face_adjacency(self.mesh_shape)
        self._distance_cache: Dict[Tuple[int, int, int], int] = {}

    def bounded_ring_distance(
        self,
        face_a: int,
        face_b: int,
        maximum_rings: int,
    ) -> int:
        a = int(face_a)
        b = int(face_b)
        limit = int(maximum_rings)
        if a == b:
            return 0
        if a < 0 or b < 0 or a >= len(self.adjacency) or b >= len(self.adjacency):
            return limit + 1

        key = (min(a, b), max(a, b), limit)
        cached = self._distance_cache.get(key)
        if cached is not None:
            return cached

        distance = _bounded_face_ring_distance(
            self.adjacency,
            a,
            b,
            limit,
        )
        self._distance_cache[key] = distance
        return distance


def run(
    source_meshes: Sequence[str],
    target_meshes: Sequence[str],
    thresholds: DiagnosticThresholds = DiagnosticThresholds(),
    select_suspects: bool = True,
    create_sets: bool = False,
    report_edge_limit: int = 20,
) -> DonorDiagnosticResult:
    """Diagnose already-written target skin weights without changing them.

    ``source_meshes`` must be the same skinned donor meshes used for Transfer.
    ``target_meshes`` must already have skinClusters containing the transferred
    result. The function re-runs closest-surface correspondence only to collect
    donor metadata; it reads the actual written target weight matrices for the
    continuity measurements.
    """

    thresholds.validate()
    sources = _source_registrations(source_meshes)
    targets = tuple(_resolve_mesh(value) for value in target_meshes)
    if not targets:
        raise RuntimeError("Provide at least one target mesh.")

    duplicate_targets = _duplicates(shape for shape, _transform in targets)
    if duplicate_targets:
        raise RuntimeError(
            "Target mesh list contains duplicates:\n{}".format(
                "\n".join(duplicate_targets)
            )
        )

    source_surfaces = tuple(reference.build_source_surface(item) for item in sources)
    for surface in source_surfaces:
        if surface.triangle_count <= 0:
            raise RuntimeError(
                "Source mesh has no usable polygon triangles:\n{}".format(
                    surface.registration.mesh_shape
                )
            )

    source_face_topologies: Dict[int, _SourceFaceTopology] = {}
    target_results = []
    selection_items = []

    for target_shape, target_transform in targets:
        result = _diagnose_target(
            target_shape=target_shape,
            target_transform=target_transform,
            source_surfaces=source_surfaces,
            source_face_topologies=source_face_topologies,
            thresholds=thresholds,
        )
        target_results.append(result)
        selection_items.extend(
            "{}.vtx[{}]".format(target_transform, vertex_id)
            for vertex_id in result.suspicious_vertex_ids
        )
        if create_sets and result.suspicious_vertex_ids:
            _create_or_replace_component_set(result)

    diagnostic = DonorDiagnosticResult(
        source_mesh_shapes=tuple(
            item.registration.mesh_shape for item in source_surfaces
        ),
        source_mesh_transforms=tuple(
            item.registration.mesh_transform for item in source_surfaces
        ),
        target_results=tuple(target_results),
        thresholds=thresholds,
    )
    print_report(diagnostic, edge_limit=report_edge_limit)

    if select_suspects:
        if selection_items:
            cmds.select(selection_items, replace=True)
        else:
            cmds.select(clear=True)

    return diagnostic


def print_report(
    result: DonorDiagnosticResult,
    edge_limit: int = 20,
) -> None:
    """Print a compact diagnostic report and the most severe suspicious edges."""

    thresholds = result.thresholds
    print("\n[AD Skin Tool - Transfer Donor Diagnostics]")
    print("Mode: Diagnostic only - no skin weights were changed")
    print("Sources:", len(result.source_mesh_shapes))
    print("Targets:", len(result.target_results))
    print(
        "Thresholds: weight_jump>{:.3f} | source_face_rings>{} | "
        "stretch>{:.3f} | minimum_reasons={}".format(
            float(thresholds.weight_jump),
            int(thresholds.maximum_source_face_rings),
            float(thresholds.correspondence_stretch),
            int(thresholds.minimum_reasons),
        )
    )

    for target in result.target_results:
        print("\nTarget:", target.mesh_transform)
        print("  SkinCluster:", target.skin_cluster)
        print("  Vertices:", target.vertex_count)
        print("  Edges evaluated:", target.edge_count)
        print("  Suspicious edges:", target.suspicious_edge_count)
        print("  Suspicious vertices:", target.suspicious_vertex_count)
        print("  Suspicious connected components:", len(target.suspicious_components))
        print("  Reason hits:")
        print("    Weight discontinuity:", target.weight_reason_count)
        print("    Source-face discontinuity:", target.source_face_reason_count)
        print("    Correspondence stretch:", target.stretch_reason_count)
        if target.donor_source_counts:
            print("  Winning donor sources:")
            for source_path, count in target.donor_source_counts:
                print("    {}: {} vertices".format(source_path, count))

        if target.suspicious_components:
            component_sizes = sorted(
                (len(component) for component in target.suspicious_components),
                reverse=True,
            )
            print(
                "  Largest suspicious component sizes:",
                component_sizes[:10],
            )

        severe = sorted(
            target.suspicious_edges,
            key=lambda item: (-item.severity, item.vertex_a, item.vertex_b),
        )
        if severe and edge_limit > 0:
            print("  Most severe suspicious edges:")
            for edge in severe[: int(edge_limit)]:
                reasons = []
                if edge.weight_reason:
                    reasons.append("weight")
                if edge.source_face_reason:
                    reasons.append("face")
                if edge.stretch_reason:
                    reasons.append("stretch")
                print(
                    "    vtx[{}]-vtx[{}] | reasons={} | weight={:.4f} | "
                    "face_rings={} | stretch={:.4f} | severity={:.4f}".format(
                        edge.vertex_a,
                        edge.vertex_b,
                        "+".join(reasons),
                        edge.weight_jump,
                        edge.source_face_ring_distance,
                        edge.correspondence_stretch,
                        edge.severity,
                    )
                )

    print("\nTotals:")
    print("  Suspicious edges:", result.suspicious_edge_count)
    print("  Suspicious vertices:", result.suspicious_vertex_count)


def _diagnose_target(
    target_shape: str,
    target_transform: str,
    source_surfaces,
    source_face_topologies: Dict[int, _SourceFaceTopology],
    thresholds: DiagnosticThresholds,
) -> TargetDiagnosticResult:
    skin_cluster = find_skin_cluster(target_shape, required=False)
    if not skin_cluster:
        raise RuntimeError(
            "Target must already have a skinCluster before diagnostics:\n{}".format(
                target_transform
            )
        )

    adapter = SkinClusterAdapter(str(skin_cluster), target_shape)
    target_positions = np.asarray(
        reference.bind_mesh_positions(target_shape, adapter.skin_cluster),
        dtype=np.float64,
    )
    vertex_count = int(target_positions.shape[0])
    vertex_ids = np.arange(vertex_count, dtype=np.int32)
    weights = np.asarray(
        adapter.get_weights(vertex_ids).weights,
        dtype=np.float64,
    )
    if weights.shape[0] != vertex_count:
        raise RuntimeError(
            "Target weight row count does not match its vertex count:\n{}".format(
                target_transform
            )
        )

    donor_samples = _sample_target_vertices(
        target_positions,
        source_surfaces,
    )
    donor_counts = [0 for _surface in source_surfaces]
    for sample in donor_samples:
        donor_counts[sample.source_index] += 1

    adjacency = get_all_vertex_neighbors(target_shape)
    edges = _unique_edges(adjacency)
    diagnostics = []
    suspicious_edges = []
    weight_reason_count = 0
    source_face_reason_count = 0
    stretch_reason_count = 0

    for vertex_a, vertex_b in edges:
        sample_a = donor_samples[vertex_a]
        sample_b = donor_samples[vertex_b]
        weight_jump = _weight_jump(weights[vertex_a], weights[vertex_b])
        target_edge_length = float(
            np.linalg.norm(target_positions[vertex_a] - target_positions[vertex_b])
        )
        source_edge_length = float(
            np.linalg.norm(
                np.asarray(sample_a.source_point, dtype=np.float64)
                - np.asarray(sample_b.source_point, dtype=np.float64)
            )
        )
        stretch = _correspondence_stretch(
            target_edge_length,
            source_edge_length,
        )

        if sample_a.source_index != sample_b.source_index:
            face_ring_distance = int(thresholds.maximum_source_face_rings) + 1
        else:
            source_index = int(sample_a.source_index)
            topology = source_face_topologies.get(source_index)
            if topology is None:
                topology = _SourceFaceTopology(
                    source_surfaces[source_index].registration.mesh_shape
                )
                source_face_topologies[source_index] = topology
            face_ring_distance = topology.bounded_ring_distance(
                sample_a.source_face_id,
                sample_b.source_face_id,
                thresholds.maximum_source_face_rings,
            )

        edge = _classify_edge(
            vertex_a=vertex_a,
            vertex_b=vertex_b,
            weight_jump=weight_jump,
            source_face_ring_distance=face_ring_distance,
            correspondence_stretch=stretch,
            thresholds=thresholds,
        )
        diagnostics.append(edge)
        weight_reason_count += int(edge.weight_reason)
        source_face_reason_count += int(edge.source_face_reason)
        stretch_reason_count += int(edge.stretch_reason)
        if edge.suspicious:
            suspicious_edges.append(edge)

    suspicious_vertex_ids = tuple(
        sorted(
            {
                vertex_id
                for edge in suspicious_edges
                for vertex_id in (edge.vertex_a, edge.vertex_b)
            }
        )
    )
    suspicious_components = _connected_components_from_edges(suspicious_edges)

    donor_source_counts = tuple(
        (
            source_surfaces[index].registration.mesh_transform,
            int(count),
        )
        for index, count in enumerate(donor_counts)
        if count
    )

    return TargetDiagnosticResult(
        mesh_shape=target_shape,
        mesh_transform=target_transform,
        skin_cluster=str(skin_cluster),
        vertex_count=vertex_count,
        edge_count=len(diagnostics),
        suspicious_edges=tuple(suspicious_edges),
        suspicious_vertex_ids=suspicious_vertex_ids,
        suspicious_components=suspicious_components,
        weight_reason_count=int(weight_reason_count),
        source_face_reason_count=int(source_face_reason_count),
        stretch_reason_count=int(stretch_reason_count),
        donor_source_counts=donor_source_counts,
    )


def _sample_target_vertices(target_positions, source_surfaces) -> Tuple[DonorSample, ...]:
    samples = []
    for vertex_id, query in enumerate(np.asarray(target_positions, dtype=np.float64)):
        best = None
        for source_index, surface in enumerate(source_surfaces):
            candidate = _closest_donor_sample(
                surface,
                query,
                source_index,
            )
            if best is None:
                best = candidate
                continue
            if nearest.distance_tied(candidate.distance, best.distance):
                continue
            if candidate.distance < best.distance:
                best = candidate
        if best is None:
            raise RuntimeError(
                "No source donor sample was produced for target vertex {}.".format(
                    vertex_id
                )
            )
        samples.append(best)
    return tuple(samples)


def _closest_donor_sample(
    surface,
    world_position,
    source_index: int,
) -> DonorSample:
    query = np.asarray(world_position, dtype=np.float64).reshape(3)
    point_on_mesh = surface.intersector.getClosestPoint(
        om.MPoint(float(query[0]), float(query[1]), float(query[2]))
    )
    face_id = int(_value_or_call(point_on_mesh, "face"))
    local_triangle = int(_value_or_call(point_on_mesh, "triangle"))
    if face_id < 0 or face_id + 1 >= surface.triangle_offsets_by_face.size:
        raise RuntimeError("Closest-point query returned an invalid source face ID.")

    start = int(surface.triangle_offsets_by_face[face_id])
    end = int(surface.triangle_offsets_by_face[face_id + 1])
    triangle_row = start + local_triangle
    if local_triangle < 0 or triangle_row >= end:
        raise RuntimeError("Closest-point query returned an invalid source triangle ID.")

    triangle_ids = surface.triangle_vertex_ids[triangle_row]
    triangle_positions = surface.world_positions[triangle_ids]
    uv = _value_or_call(point_on_mesh, "barycentricCoords")
    bary = nearest.barycentric_from_maya_uv(float(uv[0]), float(uv[1]))
    closest = np.sum(triangle_positions * bary[:, np.newaxis], axis=0)
    distance = float(np.linalg.norm(closest - query))

    return DonorSample(
        source_index=int(source_index),
        source_mesh_shape=surface.registration.mesh_shape,
        source_face_id=int(face_id),
        source_triangle_id=int(local_triangle),
        source_triangle_row=int(triangle_row),
        triangle_vertex_ids=tuple(int(value) for value in triangle_ids.tolist()),
        barycentric=tuple(float(value) for value in bary.tolist()),
        source_point=tuple(float(value) for value in closest.tolist()),
        distance=distance,
    )


def _classify_edge(
    vertex_a: int,
    vertex_b: int,
    weight_jump: float,
    source_face_ring_distance: int,
    correspondence_stretch: float,
    thresholds: DiagnosticThresholds,
) -> EdgeDiagnostic:
    weight_reason = float(weight_jump) > float(thresholds.weight_jump)
    source_face_reason = int(source_face_ring_distance) > int(
        thresholds.maximum_source_face_rings
    )
    stretch_reason = float(correspondence_stretch) > float(
        thresholds.correspondence_stretch
    )
    reason_count = (
        int(weight_reason) + int(source_face_reason) + int(stretch_reason)
    )
    suspicious = reason_count >= int(thresholds.minimum_reasons)
    severity = _edge_severity(
        weight_jump=weight_jump,
        source_face_ring_distance=source_face_ring_distance,
        correspondence_stretch=correspondence_stretch,
        thresholds=thresholds,
    )
    return EdgeDiagnostic(
        vertex_a=int(vertex_a),
        vertex_b=int(vertex_b),
        weight_jump=float(weight_jump),
        source_face_ring_distance=int(source_face_ring_distance),
        correspondence_stretch=float(correspondence_stretch),
        weight_reason=bool(weight_reason),
        source_face_reason=bool(source_face_reason),
        stretch_reason=bool(stretch_reason),
        suspicious=bool(suspicious),
        severity=float(severity),
    )


def _build_face_adjacency(mesh_shape: str) -> Tuple[Tuple[int, ...], ...]:
    dag_path = get_dag_path(mesh_shape)
    mesh_fn = om.MFnMesh(dag_path)
    face_count = int(mesh_fn.numPolygons)
    adjacency: List[Tuple[int, ...]] = [tuple() for _ in range(face_count)]
    iterator = om.MItMeshPolygon(dag_path)
    while not iterator.isDone():
        face_id = int(iterator.index())
        adjacency[face_id] = tuple(
            sorted(int(value) for value in iterator.getConnectedFaces())
        )
        iterator.next()
    return tuple(adjacency)


def _source_registrations(meshes: Sequence[str]) -> Tuple[SourceRegistration, ...]:
    registrations = []
    seen = set()
    for value in meshes:
        shape, transform = _resolve_mesh(value)
        if shape in seen:
            continue
        if not find_skin_cluster(shape, required=False):
            raise RuntimeError(
                "Diagnostic source requires an existing skinCluster:\n{}".format(
                    transform
                )
            )
        seen.add(shape)
        registrations.append(SourceRegistration(shape, transform))
    if not registrations:
        raise RuntimeError("Provide at least one skinned source mesh.")
    return tuple(registrations)


def _resolve_mesh(value: str) -> Tuple[str, str]:
    base = str(value).split(".", 1)[0]
    matches = cmds.ls(base, long=True) or []
    if not matches:
        raise RuntimeError("Mesh does not exist:\n{}".format(value))
    node = matches[0]
    node_type = cmds.nodeType(node)

    if node_type == "mesh":
        try:
            intermediate = bool(
                cmds.getAttr("{}.intermediateObject".format(node))
            )
        except Exception:
            intermediate = False
        if intermediate:
            raise RuntimeError("Intermediate mesh is not supported:\n{}".format(node))
        parents = cmds.listRelatives(node, parent=True, fullPath=True) or []
        if not parents:
            raise RuntimeError("Mesh shape has no parent transform:\n{}".format(node))
        return str(node), str(parents[0])

    if node_type != "transform":
        raise RuntimeError("Node is not a polygon mesh:\n{}".format(node))

    shapes = cmds.listRelatives(
        node,
        shapes=True,
        noIntermediate=True,
        fullPath=True,
        type="mesh",
    ) or []
    if not shapes:
        raise RuntimeError("Transform has no visible polygon mesh shape:\n{}".format(node))
    return str(shapes[0]), str(node)


def _create_or_replace_component_set(result: TargetDiagnosticResult) -> str:
    leaf = result.mesh_transform.rsplit("|", 1)[-1]
    safe = "".join(character if character.isalnum() or character == "_" else "_"
                   for character in leaf)
    set_name = "AD_TRANSFER_SUSPECT_{}".format(safe or "target")
    if cmds.objExists(set_name):
        try:
            cmds.delete(set_name)
        except Exception as exc:
            raise RuntimeError(
                "Unable to replace existing diagnostic set {}:\n{}".format(
                    set_name,
                    exc,
                )
            )
    components = [
        "{}.vtx[{}]".format(result.mesh_transform, vertex_id)
        for vertex_id in result.suspicious_vertex_ids
    ]
    created = cmds.sets(components, name=set_name)
    return str(created)


def _duplicates(values: Iterable[str]) -> Tuple[str, ...]:
    seen = set()
    duplicates = []
    duplicate_set = set()
    for value in values:
        value = str(value)
        if value in seen and value not in duplicate_set:
            duplicate_set.add(value)
            duplicates.append(value)
        seen.add(value)
    return tuple(duplicates)


def _value_or_call(instance, name):
    value = getattr(instance, name)
    return value() if callable(value) else value
