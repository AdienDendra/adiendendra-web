"""Component Smooth over one reusable adaptive Transfer diagnostic mask."""

from dataclasses import dataclass
import time
from typing import Optional, Sequence, Tuple

import maya.cmds as cmds

from ad_skin_tools.components import smooth as component_smooth
from ad_skin_tools.core.compat import ensure_numpy
from ad_skin_tools.core.skin_cluster import SkinClusterAdapter, find_skin_cluster
from ad_skin_tools.transfer import boundary_mask_prepare, donor_diagnostics


np = ensure_numpy()
PreparedMask = boundary_mask_prepare.PreparedMask
PreparedTarget = boundary_mask_prepare.PreparedTarget


@dataclass(frozen=True)
class TargetResult:
    mesh_shape: str
    mesh_transform: str
    mask_vertex_ids: Tuple[int, ...]
    accepted_component_count: int
    total_component_count: int
    smooth_result: Optional[component_smooth.ComponentSmoothResult]

    @property
    def mask_vertex_count(self) -> int:
        return len(self.mask_vertex_ids)

    @property
    def changed_vertex_count(self) -> int:
        if self.smooth_result is None:
            return 0
        return self.smooth_result.smoothed_vertex_count

    @property
    def applied(self) -> bool:
        return self.smooth_result is not None


@dataclass(frozen=True)
class Result:
    prepared_mask: PreparedMask
    targets: Tuple[TargetResult, ...]
    blend: float
    iterations: int
    prepare_seconds: float
    smoothing_seconds: float
    total_seconds: float
    reused_prepared_mask: bool
    applied: bool


def prepare(
    source_meshes: Sequence[str],
    target_meshes: Sequence[str],
    thresholds: donor_diagnostics.DiagnosticThresholds = donor_diagnostics.DiagnosticThresholds(),
    select_mask_vertices: bool = True,
    report_component_limit: int = 30,
) -> PreparedMask:
    """Calculate the diagnostic mask once and keep it for preview/apply."""

    prepared = boundary_mask_prepare.prepare(
        source_meshes=source_meshes,
        target_meshes=target_meshes,
        thresholds=thresholds,
        report_component_limit=report_component_limit,
    )
    if select_mask_vertices:
        select_prepared(prepared)
    return prepared


def select_prepared(prepared: PreparedMask) -> None:
    selection = [
        "{}.vtx[{}]".format(target.mesh_transform, vertex_id)
        for target in prepared.targets
        for vertex_id in target.mask_vertex_ids
    ]
    cmds.select(selection, replace=True) if selection else cmds.select(clear=True)


def preview(
    prepared: PreparedMask,
    blend: float = 1.0,
    iterations: int = 10,
    select_mask_vertices: bool = True,
) -> Result:
    """Preview a prepared mask without recalculating it or writing weights."""

    return _execute(
        prepared=prepared,
        blend=blend,
        iterations=iterations,
        apply_requested=False,
        select_mask_vertices=select_mask_vertices,
        reused_prepared_mask=True,
        call_started=time.perf_counter(),
    )


def apply_prepared(
    prepared: PreparedMask,
    blend: float = 1.0,
    iterations: int = 10,
    select_mask_vertices: bool = True,
) -> Result:
    """Apply production Component Smooth to an unchanged prepared mask."""

    return _execute(
        prepared=prepared,
        blend=blend,
        iterations=iterations,
        apply_requested=True,
        select_mask_vertices=select_mask_vertices,
        reused_prepared_mask=True,
        call_started=time.perf_counter(),
    )


def run(
    source_meshes: Optional[Sequence[str]] = None,
    target_meshes: Optional[Sequence[str]] = None,
    thresholds: donor_diagnostics.DiagnosticThresholds = donor_diagnostics.DiagnosticThresholds(),
    blend: float = 1.0,
    iterations: int = 10,
    apply: bool = False,
    select_mask_vertices: bool = True,
    report_component_limit: int = 30,
    prepared: Optional[PreparedMask] = None,
) -> Result:
    """One-shot compatibility path, or reuse ``prepared`` when supplied."""

    call_started = time.perf_counter()
    reused = prepared is not None
    if prepared is None:
        if source_meshes is None or target_meshes is None:
            raise RuntimeError(
                "Provide source_meshes and target_meshes, or a prepared mask."
            )
        prepared = boundary_mask_prepare.prepare(
            source_meshes=source_meshes,
            target_meshes=target_meshes,
            thresholds=thresholds,
            report_component_limit=report_component_limit,
        )

    return _execute(
        prepared=prepared,
        blend=blend,
        iterations=iterations,
        apply_requested=bool(apply),
        select_mask_vertices=select_mask_vertices,
        reused_prepared_mask=reused,
        call_started=call_started,
    )


def _execute(
    prepared,
    blend,
    iterations,
    apply_requested,
    select_mask_vertices,
    reused_prepared_mask,
    call_started,
):
    blend, iterations = component_smooth._validated_options(
        blend=blend,
        iterations=iterations,
        passes=None,
    )

    smoothing_started = time.perf_counter()
    target_results = []
    for target in prepared.targets:
        smooth_result = None
        if apply_requested:
            _validate_prepared_target(target)
            if target.mask_vertex_ids:
                scope = _scope_from_mask(
                    mesh_shape=target.mesh_shape,
                    mesh_transform=target.mesh_transform,
                    vertex_ids=target.mask_vertex_ids,
                )
                smooth_result = component_smooth.smooth_skin_weights(
                    scope=scope,
                    blend=blend,
                    iterations=iterations,
                )
        target_results.append(_target_result(target, smooth_result))
    smoothing_seconds = float(time.perf_counter() - smoothing_started)

    result = Result(
        prepared_mask=prepared,
        targets=tuple(target_results),
        blend=float(blend),
        iterations=int(iterations),
        prepare_seconds=float(prepared.total_seconds),
        smoothing_seconds=smoothing_seconds,
        total_seconds=float(time.perf_counter() - call_started),
        reused_prepared_mask=bool(reused_prepared_mask),
        applied=bool(any(item.applied for item in target_results)),
    )
    print_report(result)
    if select_mask_vertices:
        select_prepared(prepared)
    return result


def print_report(result: Result) -> None:
    print("\n[AD Skin Tool - Prepared Diagnostic Mask Smooth]")
    print("Mode:", "Applied" if result.applied else "Diagnostic only")
    print("Prepared mask reused:", result.reused_prepared_mask)
    print("Direct bridge weighting: disabled")
    print(
        "Component Smooth: Blend {:.3f} | Iterations {}".format(
            result.blend,
            result.iterations,
        )
    )
    print("Original prepare time: {:.3f}s".format(result.prepare_seconds))
    print("Current call time: {:.3f}s".format(result.total_seconds))

    for target in result.targets:
        print("\nTarget:", target.mesh_transform)
        print(
            "  Mask components: {} / {}".format(
                target.accepted_component_count,
                target.total_component_count,
            )
        )
        print("  Mask vertices:", target.mask_vertex_count)
        print("  Changed vertices:", target.changed_vertex_count)
        print("  Applied:", target.applied)
        if target.smooth_result is not None:
            smooth = target.smooth_result
            print("  Smooth context vertices:", smooth.context_vertex_count)
            print(
                "  Skipped empty/locked:",
                len(smooth.skipped_empty_vertex_ids),
                len(smooth.skipped_locked_vertex_ids),
            )
            print(
                "  Smooth calculation: {:.3f}s".format(
                    smooth.calculation_seconds
                )
            )
            print(
                "  Smooth write+validation: {:.3f}s".format(
                    smooth.weight_write_seconds + smooth.validation_seconds
                )
            )

    print("Smoothing stage: {:.3f}s".format(result.smoothing_seconds))


def _target_result(target, smooth_result):
    return TargetResult(
        mesh_shape=target.mesh_shape,
        mesh_transform=target.mesh_transform,
        mask_vertex_ids=tuple(target.mask_vertex_ids),
        accepted_component_count=int(target.accepted_component_count),
        total_component_count=int(target.total_component_count),
        smooth_result=smooth_result,
    )


def _validate_prepared_target(target: PreparedTarget) -> None:
    skin_cluster = find_skin_cluster(target.mesh_shape, required=False)
    if str(skin_cluster or "") != str(target.skin_cluster):
        raise RuntimeError(
            "Prepared mask skinCluster changed. Prepare the mask again:\n{}".format(
                target.mesh_transform
            )
        )

    adapter = SkinClusterAdapter(str(skin_cluster), target.mesh_shape)
    if int(adapter.vertex_count()) != int(target.vertex_count):
        raise RuntimeError(
            "Prepared mask vertex count changed. Prepare the mask again:\n{}".format(
                target.mesh_transform
            )
        )

    influences = tuple(str(path) for path in adapter.influences())
    if influences != tuple(target.influence_paths):
        raise RuntimeError(
            "Prepared mask influence order changed. Prepare the mask again:\n{}".format(
                target.mesh_transform
            )
        )

    if not target.mask_vertex_ids:
        return
    vertex_ids = np.asarray(target.mask_vertex_ids, dtype=np.int32)
    current = np.asarray(
        adapter.get_weights(vertex_ids).weights,
        dtype=np.float64,
    )
    expected = np.asarray(target.baseline_mask_weights, dtype=np.float64)
    if current.shape != expected.shape or not np.allclose(
        current,
        expected,
        rtol=0.0,
        atol=1.0e-12,
    ):
        raise RuntimeError(
            "Prepared mask weights changed after preparation. "
            "Prepare the mask again before smoothing:\n{}".format(
                target.mesh_transform
            )
        )


def _scope_from_mask(mesh_shape, mesh_transform, vertex_ids):
    ids = tuple(sorted({int(value) for value in vertex_ids}))
    return component_smooth.ComponentSmoothScope(
        mesh_shape=str(mesh_shape),
        mesh_transform=str(mesh_transform),
        vertex_ids=ids,
        selection_falloffs=tuple(1.0 for _value in ids),
        whole_object=False,
        soft_selection_enabled=False,
        soft_selection_used=False,
        source_component_count=len(ids),
        ignored_component_count=0,
    )
