"""Install captured-Preview Transfer into the canonical Maya UI."""

import maya.cmds as cmds

from ad_skin_tools.licensing import gate

from ad_skin_tools.transfer import (
    bounded_preview as correspondence_reuse,
    selection,
    transfer_ui_pipeline,
)


AUTO_SMOOTH_BLEND = 1.0
AUTO_SMOOTH_ITERATIONS = 10
UI_REPORT_COMPONENT_LIMIT = 0
CONFIRMATION_INFLUENCE_LIMIT = 10

_TRANSFER_UI = None
_CAPTURED_PREFLIGHT = None


def install(transfer_ui_module) -> None:
    """Configure captured Preview/Apply through the explicit UI API."""

    global _TRANSFER_UI

    if _TRANSFER_UI is transfer_ui_module:
        return
    shutdown()

    _TRANSFER_UI = transfer_ui_module
    _TRANSFER_UI.configure_actions(
        preview_handler=preview_transfer,
        apply_handler=apply_transfer,
        invalidate_handler=_invalidate_preflight,
    )


def shutdown() -> None:
    """Remove captured Transfer actions from the canonical UI API."""

    global _TRANSFER_UI, _CAPTURED_PREFLIGHT

    if _TRANSFER_UI is not None:
        _TRANSFER_UI.configure_actions()

    _TRANSFER_UI = None
    _CAPTURED_PREFLIGHT = None


@gate.protected(gate.TRANSFER_PREVIEW)
def preview_transfer() -> None:
    """Build production Preview once and retain its exact correspondence."""

    global _CAPTURED_PREFLIGHT
    ui = _require_transfer_ui()
    try:
        ui._TOOL_WINDOW._require_not_busy()
        ui._require_registrations()
        ui._set_transfer_busy(True, "Calculating closest source surfaces...")
        with ui._wait_cursor():
            resolution = selection.resolve_registered_target_scopes(
                tuple(ui._TARGETS.values())
            )
            captured = correspondence_reuse.build_preflight(
                tuple(ui._SOURCES.values()),
                resolution.effective_targets,
            )
            preflight = captured.preflight

        ui._SCOPE_RESOLUTION = resolution
        ui._UI_REGISTRATION_SIGNATURE = ui._current_ui_registration_signature()
        ui._PREFLIGHT = preflight
        _CAPTURED_PREFLIGHT = captured

        _print_scope_notices(resolution)
        ui._set_status(ui._preflight_status(preflight))
        if preflight.valid:
            qualifier = "partial" if preflight.partial else "valid"
            ui._TOOL_WINDOW._info(
                "Transfer preview {}: {} writable target vertices. "
                "Apply will reuse this exact preflight and correspondence.".format(
                    qualifier,
                    preflight.writable_target_count,
                )
            )
        else:
            cmds.warning(ui._preflight_status(preflight))
    except Exception as exc:
        _clear_preview_state(ui)
        ui._set_status("Transfer preview failed; see the error details.")
        ui._TOOL_WINDOW._show_error(exc)
    finally:
        ui._set_transfer_busy(False)


@gate.protected(gate.TRANSFER_APPLY)
def apply_transfer() -> None:
    """Apply previewed Transfer and automatic adaptive Smooth without recalculation."""

    ui = _require_transfer_ui()
    try:
        ui._TOOL_WINDOW._require_not_busy()
        if (
            _CAPTURED_PREFLIGHT is None
            or ui._PREFLIGHT is None
            or ui._SCOPE_RESOLUTION is None
        ):
            raise RuntimeError("Run Preview Transfer before applying weights.")
        if _CAPTURED_PREFLIGHT.preflight is not ui._PREFLIGHT:
            raise RuntimeError(
                "Transfer Preview state is inconsistent. Run Preview Transfer again."
            )
        if ui._current_ui_registration_signature() != ui._UI_REGISTRATION_SIGNATURE:
            raise RuntimeError(
                "Source or target object registration changed after Preview. "
                "Preview again."
            )
        if not _confirm_existing_skin_changes(ui._PREFLIGHT):
            ui._set_status("Transfer cancelled; Preview is still available.")
            return

        ui._set_transfer_busy(
            True,
            "Applying previewed Transfer and adaptive smoothing...",
        )
        with ui._wait_cursor():
            integrated = transfer_ui_pipeline.apply_captured_preview(
                _CAPTURED_PREFLIGHT,
                blend=AUTO_SMOOTH_BLEND,
                iterations=AUTO_SMOOTH_ITERATIONS,
                report_component_limit=UI_REPORT_COMPONENT_LIMIT,
            )

        _clear_preview_state(ui)
        ui._refresh_registration_lists()
        ui._set_status(_integrated_result_status(integrated))
        ui._TOOL_WINDOW._info(_integrated_info(integrated))
        ui._request_weight_preview_refresh()
    except Exception as exc:
        ui._set_status(
            "Transfer and adaptive smoothing failed; the shared Maya undo chunk "
            "was rolled back."
        )
        ui._TOOL_WINDOW._show_error(exc)
    finally:
        ui._set_transfer_busy(False)


def _confirm_existing_skin_changes(preflight) -> bool:
    missing_paths, locked_paths = _existing_skin_influence_paths(preflight)
    message = _confirmation_message(missing_paths, locked_paths)
    if not message:
        return True

    _print_influence_history(missing_paths, locked_paths)
    result = cmds.confirmDialog(
        title="Transfer Skin Weights",
        message=message,
        button=["Cancel", "Proceed"],
        defaultButton="Proceed",
        cancelButton="Cancel",
        dismissString="Cancel",
        icon="warning",
    )
    return result == "Proceed"


def _existing_skin_influence_paths(preflight):
    existing_plans = tuple(
        plan for plan in preflight.target_plans if not plan.create_skin_cluster
    )
    missing_paths = tuple(
        sorted(
            {
                path
                for plan in existing_plans
                for path in plan.influences_to_add
            }
        )
    )
    locked_paths = tuple(
        sorted(
            {
                path
                for plan in existing_plans
                for path in plan.locked_influence_paths
            }
        )
    )
    return missing_paths, locked_paths


def _confirmation_message(missing_paths, locked_paths) -> str:
    if not missing_paths and not locked_paths:
        return ""

    lines = []
    if missing_paths:
        lines.append(
            "Missing source influences will be added ({}):".format(
                len(missing_paths)
            )
        )
        _append_influence_preview(lines, missing_paths)

    if locked_paths:
        if lines:
            lines.append("")
        lines.append(
            "Locked target influences will be skipped ({}):".format(
                len(locked_paths)
            )
        )
        _append_influence_preview(lines, locked_paths)

    if (
        len(missing_paths) > CONFIRMATION_INFLUENCE_LIMIT
        or len(locked_paths) > CONFIRMATION_INFLUENCE_LIMIT
    ):
        lines.extend(("", "Full list printed in Maya Script Editor."))

    lines.extend(("", "Proceed?"))
    return "\n".join(lines)


def _append_influence_preview(lines, paths) -> None:
    preview_paths = paths[:CONFIRMATION_INFLUENCE_LIMIT]
    lines.extend("  {}".format(_short_name(path)) for path in preview_paths)

    remaining_count = len(paths) - len(preview_paths)
    if remaining_count:
        lines.append("  ... and {} more.".format(remaining_count))


def _print_influence_history(missing_paths, locked_paths) -> None:
    if missing_paths:
        print(
            "\n[AD Skin Tool - Missing source influences ({})]".format(
                len(missing_paths)
            )
        )
        print("missing_influences = [")
        for path in missing_paths:
            print('    "{}",'.format(path))
        print("]")

    if locked_paths:
        print(
            "\n[AD Skin Tool - Locked target influences ({})]".format(
                len(locked_paths)
            )
        )
        print("locked_influences = [")
        for path in locked_paths:
            print('    "{}",'.format(path))
        print("]")


def _short_name(path) -> str:
    return str(path).rsplit("|", 1)[-1]


def _invalidate_preflight(clear_status=True) -> None:
    global _CAPTURED_PREFLIGHT

    _CAPTURED_PREFLIGHT = None
    ui = _require_transfer_ui()
    ui.clear_preflight_state(clear_status=clear_status)


def _clear_preview_state(ui) -> None:
    global _CAPTURED_PREFLIGHT

    _CAPTURED_PREFLIGHT = None
    ui._PREFLIGHT = None
    ui._SCOPE_RESOLUTION = None
    ui._UI_REGISTRATION_SIGNATURE = None


def _print_scope_notices(resolution) -> None:
    has_notices = bool(
        resolution.component_mode
        or resolution.skipped_targets
        or resolution.ignored_component_meshes
        or resolution.ignored_component_items
        or resolution.unskinned_component_targets
    )
    if not has_notices:
        return

    print("\n[AD Skin Tool - Transfer Scope]")
    print(
        "Mode:",
        "Per-target Component Override"
        if resolution.component_mode
        else "Whole Object",
    )
    print("Active targets:", len(resolution.effective_targets))
    if resolution.skipped_targets:
        print(
            "Registered targets skipped:",
            len(resolution.skipped_targets),
        )
    if resolution.unskinned_component_targets:
        names = [
            item.mesh_transform for item in resolution.unskinned_component_targets
        ]
        print(
            "Unskinned component targets skipped; Bind Skin first:",
            len(names),
        )
        for name in names:
            print("  ", name)
        cmds.warning(
            "Component Transfer skipped unskinned target(s). Bind Skin first: {}".format(
                ", ".join(names)
            )
        )
    if resolution.ignored_component_meshes:
        print(
            "Component meshes ignored outside the target list:",
            len(resolution.ignored_component_meshes),
        )
    if resolution.ignored_component_items:
        print(
            "Unsupported or unresolved component items ignored:",
            len(resolution.ignored_component_items),
        )


def _integrated_result_status(integrated) -> str:
    transfer = integrated.transfer_result
    return (
        "Transfer complete: {} / {} requested vertices across {} active targets. "
        "Adaptive Smooth changed {} vertices across {} whole-object targets; "
        "{} component-scope targets remained Transfer-only."
    ).format(
        transfer.transferred_target_count,
        transfer.requested_target_count,
        transfer.target_count,
        integrated.smoothed_vertex_count,
        integrated.smoothed_target_count,
        integrated.component_target_count,
    )


def _integrated_info(integrated) -> str:
    transfer = integrated.transfer_result
    if integrated.whole_object_target_count:
        smoothing = (
            " Adaptive Smooth updated {} vertices across {} target(s).".format(
                integrated.smoothed_vertex_count,
                integrated.smoothed_target_count,
            )
        )
    else:
        smoothing = " Component-scope Transfer completed without automatic expansion."
    return (
        "Transfer complete: {} vertices across {} active target mesh(es).{}"
    ).format(
        transfer.transferred_target_count,
        transfer.target_count,
        smoothing,
    )


def _require_transfer_ui():
    if _TRANSFER_UI is None:
        raise RuntimeError("Transfer UI integration is not installed.")
    return _TRANSFER_UI
