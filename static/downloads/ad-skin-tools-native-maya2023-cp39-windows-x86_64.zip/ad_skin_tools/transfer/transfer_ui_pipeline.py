"""Grouped UI workflow for Transfer followed by adaptive diagnostic smoothing.

The existing production Transfer and Component Smooth solvers stay unchanged.
The UI reuses the exact correspondence captured during Preview, applies the
previewed Transfer without rebuilding its preflight, prepares the adaptive mask,
and smooths whole-object targets inside one outer Maya undo chunk.

Component-scope targets keep their established Transfer behaviour and are not
automatically expanded into a whole-object diagnostic mask.
"""

from contextlib import contextmanager, redirect_stdout
from dataclasses import dataclass
import io
from typing import Optional

import maya.cmds as cmds

from ad_skin_tools.core.compat import ensure_numpy
from ad_skin_tools.core.skin_cluster import SkinClusterAdapter, find_skin_cluster
from ad_skin_tools.transfer import boundary_mask_smooth, correspondence_reuse


np = ensure_numpy()
UNDO_CHUNK_NAME = "AD Skin Transfer And Adaptive Smooth"
DEFAULT_BLEND = 1.0
DEFAULT_ITERATIONS = 10


@dataclass(frozen=True)
class Result:
    captured_transfer: correspondence_reuse.CapturedTransferResult
    prepared_mask: Optional[object]
    smooth_result: Optional[boundary_mask_smooth.Result]
    whole_object_target_count: int
    component_target_count: int

    @property
    def transfer_result(self):
        return self.captured_transfer.transfer_result

    @property
    def correspondence(self):
        return self.captured_transfer.correspondence

    @property
    def smoothed_target_count(self) -> int:
        if self.smooth_result is None:
            return 0
        return sum(int(target.applied) for target in self.smooth_result.targets)

    @property
    def mask_vertex_count(self) -> int:
        if self.prepared_mask is None:
            return 0
        return sum(target.mask_vertex_count for target in self.prepared_mask.targets)

    @property
    def smoothed_vertex_count(self) -> int:
        if self.smooth_result is None:
            return 0
        return sum(target.changed_vertex_count for target in self.smooth_result.targets)


def apply_captured_preview(
    captured_preflight: correspondence_reuse.CapturedPreflight,
    blend: float = DEFAULT_BLEND,
    iterations: int = DEFAULT_ITERATIONS,
    report_component_limit: int = 0,
) -> Result:
    """Apply Previewed Transfer and automatic Smooth as one Maya undo step."""

    if not isinstance(captured_preflight, correspondence_reuse.CapturedPreflight):
        raise TypeError("Expected a captured Transfer preflight from Preview.")

    blend, iterations = boundary_mask_smooth.component_smooth._validated_options(
        blend=blend,
        iterations=iterations,
        passes=None,
    )
    _validate_captured_preview(captured_preflight)

    whole_correspondence = _whole_object_correspondence(
        captured_preflight.correspondence
    )
    whole_count = len(whole_correspondence.targets)
    component_count = (
        len(captured_preflight.correspondence.targets) - whole_count
    )

    chunk_open = False
    transfer_completed = False
    captured_transfer = None
    prepared = None
    smooth_result = None

    try:
        cmds.undoInfo(openChunk=True, chunkName=UNDO_CHUNK_NAME)
        chunk_open = True

        captured_transfer = correspondence_reuse.apply_transfer(captured_preflight)
        transfer_completed = True

        if whole_count:
            with _quiet_internal_reports():
                whole_transfer = correspondence_reuse.CapturedTransferResult(
                    transfer_result=captured_transfer.transfer_result,
                    correspondence=whole_correspondence,
                )
                prepared = correspondence_reuse.prepare_mask(
                    whole_transfer,
                    select_mask_vertices=False,
                    report_component_limit=report_component_limit,
                )

                # Component Smooth owns failed-write rollback through its atomic
                # Maya command. The outer chunk owns rollback for the combined
                # Transfer/Smooth transaction.
                smooth_result = correspondence_reuse.apply_smooth(
                    prepared,
                    blend=blend,
                    iterations=iterations,
                    select_mask_vertices=False,
                )

        cmds.undoInfo(closeChunk=True)
        chunk_open = False
    except Exception as exc:
        if chunk_open:
            try:
                cmds.undoInfo(closeChunk=True)
            finally:
                chunk_open = False
        if transfer_completed:
            try:
                cmds.undo()
            except Exception as rollback_exc:
                raise RuntimeError(
                    "Transfer/Smooth failed and Maya could not roll back the shared "
                    "undo chunk.\n\nOriginal error: {}\nRollback error: {}".format(
                        exc,
                        rollback_exc,
                    )
                ) from exc
        raise

    result = Result(
        captured_transfer=captured_transfer,
        prepared_mask=prepared,
        smooth_result=smooth_result,
        whole_object_target_count=whole_count,
        component_target_count=component_count,
    )
    print_report(result, blend=blend, iterations=iterations)
    return result


def print_report(result: Result, blend: float, iterations: int) -> None:
    transfer = result.transfer_result
    print("\n[AD Skin Tool - Transfer Complete]")
    print(
        "Sources / targets: {} / {}".format(
            transfer.source_count,
            transfer.target_count,
        )
    )
    print(
        "Transferred vertices: {} / {}".format(
            transfer.transferred_target_count,
            transfer.requested_target_count,
        )
    )
    print("Created skinClusters:", transfer.created_skin_cluster_count)
    print(
        "Adaptive Smooth: {} vertices across {} target(s) | Blend {:.3f} | Iterations {}".format(
            result.smoothed_vertex_count,
            result.smoothed_target_count,
            float(blend),
            int(iterations),
        )
    )
    if result.component_target_count:
        print(
            "Component-scope targets kept Transfer-only:",
            result.component_target_count,
        )
    if transfer.fully_locked_target_count:
        print(
            "Fully locked vertices skipped:",
            transfer.fully_locked_target_count,
        )
    if transfer.empty_donor_target_count:
        print(
            "Vertices with no writable donor weight:",
            transfer.empty_donor_target_count,
        )
    if transfer.exact_distance_tie_count:
        print(
            "Exact-distance ties resolved by source order:",
            transfer.exact_distance_tie_count,
        )
    print("Maya undo: one step")


@contextmanager
def _quiet_internal_reports():
    """Hide successful diagnostic detail, but replay it when the stage fails."""

    captured_output = io.StringIO()
    try:
        with redirect_stdout(captured_output):
            yield
    except Exception:
        detail = captured_output.getvalue().strip()
        if detail:
            print("\n[AD Skin Tool - Internal Transfer Diagnostics]")
            print(detail)
        raise


def _whole_object_correspondence(correspondence):
    targets = tuple(target for target in correspondence.targets if target.whole_object)
    return correspondence_reuse.TransferCorrespondence(
        source_mesh_shapes=tuple(correspondence.source_mesh_shapes),
        source_mesh_transforms=tuple(correspondence.source_mesh_transforms),
        source_skin_clusters=tuple(correspondence.source_skin_clusters),
        source_vertex_counts=tuple(correspondence.source_vertex_counts),
        source_triangle_counts=tuple(correspondence.source_triangle_counts),
        targets=targets,
    )


def _validate_captured_preview(captured_preflight) -> None:
    correspondence_reuse._validate_sources(captured_preflight.correspondence)

    preflight = captured_preflight.preflight
    summaries = tuple(preflight.sources)
    source_shapes = tuple(item.mesh_shape for item in summaries)
    if source_shapes != tuple(captured_preflight.correspondence.source_mesh_shapes):
        raise RuntimeError(
            "Captured Transfer source order changed. Run Preview Transfer again."
        )

    target_shapes = tuple(
        plan.registration.mesh_shape for plan in preflight.target_plans
    )
    correspondence_targets = tuple(
        target.mesh_shape for target in captured_preflight.correspondence.targets
    )
    if target_shapes != correspondence_targets:
        raise RuntimeError(
            "Captured Transfer target order changed. Run Preview Transfer again."
        )

    for summary in summaries:
        current_skin = find_skin_cluster(summary.mesh_shape, required=False)
        if str(current_skin or "") != str(summary.skin_cluster):
            raise RuntimeError(
                "Source skinCluster changed after Preview. Preview again:\n{}".format(
                    summary.mesh_transform
                )
            )
        adapter = SkinClusterAdapter(str(current_skin), summary.mesh_shape)
        if tuple(adapter.influences()) != tuple(summary.influences):
            raise RuntimeError(
                "Source influence order changed after Preview. Preview again:\n{}".format(
                    summary.mesh_transform
                )
            )
        if int(adapter.vertex_count()) != int(summary.vertex_count):
            raise RuntimeError(
                "Source vertex count changed after Preview. Preview again:\n{}".format(
                    summary.mesh_transform
                )
            )

    for plan in preflight.target_plans:
        if plan.create_skin_cluster or not plan.writable_count:
            continue
        current_skin = find_skin_cluster(
            plan.registration.mesh_shape,
            required=False,
        )
        if str(current_skin or "") != str(plan.skin_cluster):
            raise RuntimeError(
                "Target skinCluster changed after Preview. Preview again:\n{}".format(
                    plan.registration.mesh_transform
                )
            )
        adapter = SkinClusterAdapter(str(current_skin), plan.registration.mesh_shape)
        if tuple(adapter.influences()) != tuple(plan.influences):
            raise RuntimeError(
                "Target influence order changed after Preview. Preview again:\n{}".format(
                    plan.registration.mesh_transform
                )
            )
        current = np.asarray(
            adapter.get_weights(plan.writable_vertex_ids).weights,
            dtype=np.float64,
        )
        expected = np.asarray(plan.before_weights, dtype=np.float64)
        if current.shape != expected.shape or not np.allclose(
            current,
            expected,
            rtol=0.0,
            atol=1.0e-12,
        ):
            raise RuntimeError(
                "Target weights changed after Preview. Preview again:\n{}".format(
                    plan.registration.mesh_transform
                )
            )
