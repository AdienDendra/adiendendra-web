"""Register transfer meshes and resolve dynamic target component scopes."""

from dataclasses import dataclass
import re
from typing import Dict, List, Sequence, Tuple

import maya.cmds as cmds

from ad_skin_tools.core.skin_cluster import find_skin_cluster


_VERTEX_PATTERN = re.compile(r"\.vtx\[(\d+)\]$")
_SUPPORTED_MARKERS = (".vtx[", ".e[", ".f[")
SCOPE_WHOLE_OBJECT = "whole_object"
SCOPE_COMPONENT = "component"


@dataclass(frozen=True)
class SourceRegistration:
    mesh_shape: str
    mesh_transform: str


@dataclass(frozen=True)
class TargetRegistration:
    mesh_shape: str
    mesh_transform: str
    whole_object: bool
    vertex_ids: Tuple[int, ...]

    @property
    def scope_label(self) -> str:
        if self.whole_object:
            state = (
                "Existing SkinCluster"
                if find_skin_cluster(self.mesh_shape, required=False)
                else "Unskinned"
            )
            return "Whole Object - {}".format(state)
        return "{} vertices".format(len(self.vertex_ids))


@dataclass(frozen=True)
class TargetScopeResolution:
    mode: str
    registered_targets: Tuple[TargetRegistration, ...]
    effective_targets: Tuple[TargetRegistration, ...]
    skipped_targets: Tuple[TargetRegistration, ...]
    ignored_component_meshes: Tuple[str, ...]
    ignored_component_items: Tuple[str, ...]
    unskinned_component_targets: Tuple[TargetRegistration, ...]
    selected_vertex_counts: Tuple[Tuple[str, int], ...]

    @property
    def component_mode(self) -> bool:
        return self.mode == SCOPE_COMPONENT


def collect_selected_sources() -> Tuple[SourceRegistration, ...]:
    selected = cmds.ls(selection=True, long=True) or []
    ordered: Dict[str, SourceRegistration] = {}
    for item in selected:
        resolved = _resolve_mesh_from_item(item)
        if resolved is None:
            continue
        shape, transform = resolved
        if shape in ordered:
            continue
        _require_existing_skin(shape)
        ordered[shape] = SourceRegistration(shape, transform)
    if not ordered:
        raise RuntimeError(
            "Select one or more already-skinned source mesh objects or components."
        )
    return tuple(ordered.values())


def collect_selected_targets() -> Tuple[TargetRegistration, ...]:
    """Register owning target objects, never the current component scope."""

    selected = cmds.ls(selection=True, long=True) or []
    if not selected:
        raise RuntimeError("Select one or more target mesh objects or components.")

    ordered: Dict[str, TargetRegistration] = {}
    for item in selected:
        resolved = _resolve_mesh_from_item(item)
        if resolved is None:
            continue
        shape, transform = resolved
        ordered.setdefault(
            shape,
            TargetRegistration(
                mesh_shape=shape,
                mesh_transform=transform,
                whole_object=True,
                vertex_ids=(),
            ),
        )

    if not ordered:
        raise RuntimeError(
            "The selection did not contain usable target mesh objects or components."
        )
    return tuple(ordered.values())


def resolve_registered_target_scopes(
    registered_targets: Sequence[TargetRegistration],
) -> TargetScopeResolution:
    """Resolve Transfer scope per target from the registered target list.

    Every registered target participates by default as Whole Object. A supported
    component selection on a registered target overrides only that target to
    Component scope. Component Transfer requires an existing target skinCluster;
    an unskinned component target is skipped and must be bound first.
    """

    registered = tuple(registered_targets)
    if not registered:
        raise RuntimeError("Register at least one target mesh.")
    by_shape = {item.mesh_shape: item for item in registered}
    if len(by_shape) != len(registered):
        raise RuntimeError("Target registration contains duplicate meshes.")

    selected = cmds.ls(
        selection=True,
        long=True,
        flatten=True,
    ) or []
    component_items = [str(item) for item in selected if _looks_like_component(item)]

    components_by_shape: Dict[str, List[str]] = {}
    ignored_meshes = []
    ignored_mesh_set = set()
    ignored_items = []

    for item in component_items:
        if not _is_supported_component(item):
            ignored_items.append(item)
            continue
        resolved = _resolve_mesh_from_item(item)
        if resolved is None:
            ignored_items.append(item)
            continue
        shape, transform = resolved
        if shape not in by_shape:
            if transform not in ignored_mesh_set:
                ignored_mesh_set.add(transform)
                ignored_meshes.append(transform)
            continue
        components_by_shape.setdefault(shape, []).append(item)

    effective = []
    skipped = []
    unskinned_component_targets = []
    selected_counts = []
    unusable_registered = []
    has_registered_component_scope = False

    for item in registered:
        components = components_by_shape.get(item.mesh_shape)
        if not components:
            effective.append(
                TargetRegistration(
                    item.mesh_shape,
                    item.mesh_transform,
                    True,
                    (),
                )
            )
            continue

        has_registered_component_scope = True
        vertex_ids = _components_to_vertex_ids(components, item.mesh_shape)
        if not vertex_ids:
            skipped.append(item)
            unusable_registered.append(item.mesh_transform)
            continue

        selected_counts.append((item.mesh_transform, len(vertex_ids)))
        if not find_skin_cluster(item.mesh_shape, required=False):
            skipped.append(item)
            unskinned_component_targets.append(item)
            continue

        effective.append(
            TargetRegistration(
                item.mesh_shape,
                item.mesh_transform,
                False,
                tuple(vertex_ids),
            )
        )

    if not effective:
        details = []
        if unskinned_component_targets:
            details.append(
                "Unskinned target components require Bind Skin first:\n{}".format(
                    "\n".join(
                        item.mesh_transform for item in unskinned_component_targets
                    )
                )
            )
        if ignored_meshes:
            details.append(
                "Components from unregistered meshes:\n{}".format(
                    "\n".join(ignored_meshes)
                )
            )
        if ignored_items:
            details.append(
                "Unsupported or unresolved components: {}".format(len(ignored_items))
            )
        if unusable_registered:
            details.append(
                "Registered targets with no convertible vertices:\n{}".format(
                    "\n".join(unusable_registered)
                )
            )
        suffix = "\n\n" + "\n\n".join(details) if details else ""
        if unskinned_component_targets:
            raise RuntimeError(
                "Component Transfer requires an existing skinCluster on each active "
                "component target. Bind the unskinned target(s) first.{}".format(suffix)
            )
        raise RuntimeError(
            "No registered target produced a usable Transfer scope.{}".format(suffix)
        )

    return TargetScopeResolution(
        mode=(
            SCOPE_COMPONENT
            if has_registered_component_scope
            else SCOPE_WHOLE_OBJECT
        ),
        registered_targets=registered,
        effective_targets=tuple(effective),
        skipped_targets=tuple(skipped),
        ignored_component_meshes=tuple(ignored_meshes),
        ignored_component_items=tuple(ignored_items),
        unskinned_component_targets=tuple(unskinned_component_targets),
        selected_vertex_counts=tuple(selected_counts),
    )


def print_target_scope_report(resolution: TargetScopeResolution) -> None:
    print("\n[AD Skin Tool - Transfer Target Scope]")
    print(
        "Selection mode:",
        "Per-target Component Override" if resolution.component_mode else "Whole Object",
    )
    print("Registered targets:", len(resolution.registered_targets))
    print("Active targets:", len(resolution.effective_targets))
    print("Skipped registered targets:", len(resolution.skipped_targets))
    for item in resolution.skipped_targets:
        print("  Skipped:", item.mesh_transform)

    if resolution.unskinned_component_targets:
        print("Skipped unskinned component targets; Bind Skin first:")
        for item in resolution.unskinned_component_targets:
            print("  ", item.mesh_transform)
    if resolution.ignored_component_meshes:
        print("Ignored component meshes outside the target list:")
        for path in resolution.ignored_component_meshes:
            print("  ", path)
    if resolution.ignored_component_items:
        print(
            "Ignored unsupported or unresolved component items:",
            len(resolution.ignored_component_items),
        )



def _components_to_vertex_ids(components, mesh_shape: str) -> Tuple[int, ...]:
    converted = cmds.polyListComponentConversion(
        list(components),
        toVertex=True,
    ) or []
    flattened = cmds.ls(converted, flatten=True, long=True) or []
    return tuple(
        sorted(
            {
                _vertex_id(value)
                for value in flattened
                if _component_belongs_to_shape(value, mesh_shape)
                and _VERTEX_PATTERN.search(str(value))
            }
        )
    )


def _require_existing_skin(mesh_shape: str) -> None:
    if not find_skin_cluster(mesh_shape, required=False):
        raise RuntimeError(
            "Transfer source requires an existing skinCluster:\n{}".format(
                mesh_shape
            )
        )


def _resolve_mesh_from_item(item):
    base = str(item).split(".", 1)[0]
    matches = cmds.ls(base, long=True) or []
    if not matches:
        return None
    node = matches[0]
    node_type = cmds.nodeType(node)
    if node_type == "mesh":
        try:
            if cmds.getAttr("{}.intermediateObject".format(node)):
                return None
        except Exception:
            pass
        parents = cmds.listRelatives(node, parent=True, fullPath=True) or []
        return (node, parents[0]) if parents else None
    if node_type != "transform":
        return None
    shapes = cmds.listRelatives(
        node,
        shapes=True,
        noIntermediate=True,
        fullPath=True,
        type="mesh",
    ) or []
    if not shapes:
        return None
    return shapes[0], node


def _looks_like_component(item: str) -> bool:
    return "." in str(item) and "[" in str(item) and "]" in str(item)


def _is_supported_component(item: str) -> bool:
    return any(marker in str(item) for marker in _SUPPORTED_MARKERS)


def _component_belongs_to_shape(component: str, mesh_shape: str) -> bool:
    resolved = _resolve_mesh_from_item(component)
    return resolved is not None and resolved[0] == mesh_shape


def _vertex_id(component: str) -> int:
    match = _VERTEX_PATTERN.search(str(component))
    if match is None:
        raise ValueError("Not a flattened mesh vertex component: {}".format(component))
    return int(match.group(1))
