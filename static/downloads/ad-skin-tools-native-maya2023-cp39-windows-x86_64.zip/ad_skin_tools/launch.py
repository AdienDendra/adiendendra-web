"""Public launch entry point for AD Skin Tools."""


def _reload_for_development() -> None:
    """Delegate hot reload to the development-only deployed helper."""

    try:
        _dev_reload = __import__(
            "ad_skin_tools._dev_reload",
            fromlist=("reload_modules",),
        )
    except ImportError as exc:
        raise RuntimeError(
            "reload=True is available only in a development deployment. "
            "Deploy from the repository with tools/deploy_to_maya.sh, or launch "
            "the production package with reload=False."
        ) from exc

    _dev_reload.reload_modules()


def reload_modules() -> None:
    """Backward-compatible development reload entry point."""

    _reload_for_development()


def show(reload=False, auto_refresh=False):
    if reload:
        _reload_for_development()

    from ad_skin_tools.ui import composition

    composition.show(auto_refresh=auto_refresh)
