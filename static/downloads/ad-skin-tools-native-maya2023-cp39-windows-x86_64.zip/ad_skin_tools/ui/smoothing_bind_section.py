"""Canonical Bind/Add Influence UI using shared smoothing controls."""

import builtins

import maya.cmds as cmds

from ad_skin_tools.core import add_influence
from ad_skin_tools.core import automatic_surface_commands
from ad_skin_tools.licensing import gate
from ad_skin_tools.ui import global_owner_tag
from ad_skin_tools.ui import joint_list
from ad_skin_tools.ui import smoothing_controls


_TOOL_WINDOW = None
_SKIN_OPERATIONS = None


def install(tool_window_module, skin_operations_module) -> None:
    """Install the canonical Joints / Influences builder and bind callbacks."""

    global _TOOL_WINDOW, _SKIN_OPERATIONS
    _TOOL_WINDOW = tool_window_module
    _SKIN_OPERATIONS = skin_operations_module

    smoothing_controls.configure(tool_window_module)


def build_section() -> None:
    """Build list, smoothing controls, and all four operations in one frame."""

    from ad_skin_tools.ui import component_section

    cmds.frameLayout(
        label="Joints / Influences",
        collapsable=True,
        collapse=False,
        marginWidth=6,
        marginHeight=6,
    )
    cmds.columnLayout(adjustableColumn=True, rowSpacing=5)

    joint_list._build_tree()
    joint_list._build_list_buttons()
    smoothing_controls.build_controls()

    _SKIN_OPERATIONS._named_button_row(
        [
            (
                _TOOL_WINDOW.CTRL_BIND_BUTTON,
                "Bind Skin",
                lambda *_: apply_bind_skin(),
            ),
            (
                _SKIN_OPERATIONS.CTRL_ADD_INFLUENCE_BUTTON,
                "Add Influence",
                lambda *_: apply_add_influence(),
            ),
        ],
        height=38,
    )
    _SKIN_OPERATIONS._named_button_row(
        [
            (
                component_section.CTRL_FLOOD_BUTTON,
                "Flood",
                lambda *_: component_section.apply_component_flood(),
            ),
            (
                component_section.CTRL_SMOOTH_BUTTON,
                "Smooth",
                lambda *_: component_section.apply_component_smooth(),
            ),
        ],
        height=38,
    )

    _TOOL_WINDOW._create_bind_progress_bar()
    cmds.text(
        _TOOL_WINDOW.CTRL_BIND_STATUS,
        label="",
        align="left",
        wordWrap=True,
        visible=False,
    )
    cmds.text(
        component_section.CTRL_COMPONENT_STATUS,
        label="",
        align="left",
        wordWrap=True,
        visible=False,
    )

    cmds.setParent("..")
    cmds.setParent("..")


@gate.protected(gate.BIND_SKIN)
def apply_bind_skin() -> None:
    """Run the production ownership pipeline and apply shared smoothing values."""

    wait_cursor_active = False
    try:
        _TOOL_WINDOW._require_not_busy()
        _TOOL_WINDOW._require_unskinned_mesh()

        joints = builtins.list(_TOOL_WINDOW._STATE.get("joints", []))
        if builtins.len(joints) < 2:
            raise RuntimeError(
                "Bind Skin requires at least two joints.\n\n"
                "Select joints in Maya and click Add Joints To The List."
            )

        values = smoothing_controls.query_values()
        tagged_global_owner = global_owner_tag.global_owner_joint()
        status = "Calculating final blocking ownership..."
        if values.iterations > 0:
            status = (
                "Calculating final blocking and smoothing with Blend {:.3f}, "
                "Iterations {}..."
            ).format(values.blend, values.iterations)

        _TOOL_WINDOW._set_bind_busy(True, status)
        cmds.waitCursor(state=True)
        wait_cursor_active = True
        cmds.refresh(force=True)

        result = automatic_surface_commands.bind_object_automatic_surface(
            mesh=_TOOL_WINDOW._STATE["mesh_transform"],
            joints=joints,
            options=automatic_surface_commands.AutomaticSurfaceBindOptions(
                smoothing_blend=values.blend,
                smoothing_iterations=values.iterations,
                global_owner_joint=tagged_global_owner,
            ),
        )

        _TOOL_WINDOW._sync_loaded_skin_context()
        automatic_surface_commands.print_report(result)

        if values.iterations == 0:
            message = (
                "Bind complete: {} vertices with final hard blocking weights."
                .format(result.vertex_count)
            )
        else:
            message = (
                "Bind complete: Blend {:.3f}, Iterations {}, Max Influences {}."
                .format(
                    result.smoothing_blend,
                    result.smoothing_iterations,
                    result.effective_maximum_influences,
                )
            )
        _TOOL_WINDOW._info(message)
    except Exception as exc:
        _TOOL_WINDOW._show_error(exc)
    finally:
        if wait_cursor_active:
            try:
                cmds.waitCursor(state=False)
            except Exception:
                pass
        _TOOL_WINDOW._set_bind_busy(False)


@gate.protected(gate.ADD_INFLUENCE)
def apply_add_influence() -> None:
    """Claim pending-joint regions and apply shared smoothing values."""

    wait_cursor_active = False
    try:
        _TOOL_WINDOW._require_not_busy()
        _TOOL_WINDOW._require_loaded_mesh()
        if not _TOOL_WINDOW._STATE.get("has_skin_cluster"):
            raise RuntimeError(
                "Add Influence requires an existing skinCluster.\n\n"
                "Use Bind Skin first."
            )

        selected_rows = builtins.list(joint_list.selected_joint_paths())
        bound = set(_TOOL_WINDOW._STATE.get("bound_joint_paths", set()))
        targets = [joint for joint in selected_rows if joint not in bound]
        if not targets:
            raise RuntimeError(
                "Select at least one new pending joint in the influence list."
            )

        locked_targets = [
            joint for joint in targets if joint_list.joint_is_locked(joint)
        ]
        if locked_targets:
            raise RuntimeError(
                "Unlock the selected pending joint(s) before Add Influence:\n{}"
                .format("\n".join(locked_targets))
            )

        staged_joints = builtins.list(
            _TOOL_WINDOW._STATE.get("joints", [])
        )
        staged_locks = set(
            _TOOL_WINDOW._STATE.get("pending_locked_joints", set())
        )
        values = smoothing_controls.query_values()
        tagged_global_owner = global_owner_tag.global_owner_joint()
        status = "Calculating final Region ownership for new influences..."
        if values.iterations > 0:
            status = (
                "Calculating Region claims and smoothing with Blend {:.3f}, "
                "Iterations {}..."
            ).format(values.blend, values.iterations)

        _SKIN_OPERATIONS._set_add_influence_busy(True, status)
        cmds.waitCursor(state=True)
        wait_cursor_active = True
        cmds.refresh(force=True)

        result = add_influence.add_influences_by_region(
            mesh=_TOOL_WINDOW._STATE["mesh_shape"],
            target_joints=targets,
            smoothing_blend=values.blend,
            smoothing_iterations=values.iterations,
            global_owner_joint=tagged_global_owner,
        )

        joint_list.sync_after_flood_preserving_pending(
            staged_joints,
            staged_locks,
        )
        joint_list.select_joint_paths(result.target_joints)

        add_influence.print_report(result)
        _TOOL_WINDOW._info(
            (
                "Added {} influence(s); {} vertices claimed; Blend {:.3f}, "
                "Iterations {}."
            ).format(
                len(result.target_joints),
                result.claimed_vertex_count,
                result.smoothing_blend,
                result.smoothing_iterations,
            )
        )
    except Exception as exc:
        _TOOL_WINDOW._show_error(exc)
    finally:
        if wait_cursor_active:
            try:
                cmds.waitCursor(state=False)
            except Exception:
                pass
        _SKIN_OPERATIONS._set_add_influence_busy(False)
