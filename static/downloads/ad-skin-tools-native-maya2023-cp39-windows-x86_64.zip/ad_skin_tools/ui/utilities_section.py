"""Canonical one-pass composition for Mirror and Transfer Utilities."""

import maya.cmds as cmds


STATUS_HEIGHT = 72

_TOOL_WINDOW = None
_SKIN_OPERATIONS = None
_MIRROR_UI = None
_TRANSFER_UI = None


def install(
    tool_window_module,
    skin_operations_module,
    mirror_ui_module,
    transfer_ui_module,
) -> None:
    """Own the final Utilities builder after feature modules are configured."""

    global _TOOL_WINDOW, _SKIN_OPERATIONS, _MIRROR_UI, _TRANSFER_UI

    _TOOL_WINDOW = tool_window_module
    _SKIN_OPERATIONS = skin_operations_module
    _MIRROR_UI = mirror_ui_module
    _TRANSFER_UI = transfer_ui_module


def build_section() -> None:
    """Build Mirror and Transfer inside one stable Maya layout pass."""

    if not all((_TOOL_WINDOW, _SKIN_OPERATIONS, _MIRROR_UI, _TRANSFER_UI)):
        raise RuntimeError("Utilities UI was not configured before show().")

    cmds.frameLayout(
        _MIRROR_UI.CTRL_UTILITIES_FRAME,
        label="Utilities",
        collapsable=True,
        collapse=False,
        marginWidth=6,
        marginHeight=4,
    )
    cmds.columnLayout(adjustableColumn=True, rowSpacing=3)

    _build_mirror_controls()
    cmds.separator(style="in", height=8)
    _TRANSFER_UI._build_transfer_controls()
    _reserve_status_height(_TRANSFER_UI.CTRL_STATUS)

    cmds.setParent("..")
    cmds.setParent("..")
    _MIRROR_UI._sync_axis_controls()
    _MIRROR_UI._sync_mirror_mesh_field()
    _MIRROR_UI._sync_register_pairing_button()
    _MIRROR_UI._sync_side_marker_fields()


def _build_mirror_controls() -> None:
    """Build the canonical Mirror controls without opening a second frame."""

    _MIRROR_UI._build_title_row()
    _MIRROR_UI._build_mirror_mesh_row()

    _TOOL_WINDOW._label_control_row(
        "Mirror Across",
        lambda: cmds.radioButtonGrp(
            _MIRROR_UI.CTRL_AXIS,
            numberOfRadioButtons=3,
            labelArray3=_MIRROR_UI._AXIS_ORDER,
            select=1,
            onCommand1=lambda *_: _MIRROR_UI._on_axis_changed(),
            onCommand2=lambda *_: _MIRROR_UI._on_axis_changed(),
            onCommand3=lambda *_: _MIRROR_UI._on_axis_changed(),
        ),
    )
    _TOOL_WINDOW._label_control_row(
        "Direction",
        lambda: cmds.radioButtonGrp(
            _MIRROR_UI.CTRL_DIRECTION,
            numberOfRadioButtons=2,
            labelArray2=_MIRROR_UI._AXIS_DIRECTIONS["YZ"],
            select=1,
            onCommand1=lambda *_: _MIRROR_UI._on_direction_changed(),
            onCommand2=lambda *_: _MIRROR_UI._on_direction_changed(),
        ),
    )
    _MIRROR_UI._build_center_row()
    _TOOL_WINDOW._label_control_row(
        "Tolerance",
        lambda: cmds.floatField(
            _MIRROR_UI.CTRL_TOLERANCE,
            value=_MIRROR_UI._DEFAULT_TOLERANCE,
            minValue=1.0e-8,
            precision=6,
            changeCommand=lambda *_: _MIRROR_UI._invalidate_preview(),
        ),
    )
    _TOOL_WINDOW._label_control_row(
        "Side Markers",
        _MIRROR_UI._build_side_marker_fields,
    )

    _SKIN_OPERATIONS._named_button_row(
        [
            (
                _MIRROR_UI.CTRL_PREVIEW,
                "Preview Pairing",
                lambda *_: _MIRROR_UI.preview_pairing(),
            ),
            (
                _MIRROR_UI.CTRL_REGISTER_PAIRING,
                "Register Pairing",
                lambda *_: _MIRROR_UI.register_pairing(),
            ),
            (
                _MIRROR_UI.CTRL_MIRROR,
                "Mirror Skin Weights",
                lambda *_: _MIRROR_UI.apply_mirror(),
            ),
        ],
        height=36,
    )
    cmds.text(
        _MIRROR_UI.CTRL_STATUS,
        label="",
        align="left",
        wordWrap=True,
        height=STATUS_HEIGHT,
        visible=False,
    )


def _reserve_status_height(control_name: str) -> None:
    """Keep status geometry stable while its label and visibility change."""

    if cmds.text(control_name, exists=True):
        cmds.text(
            control_name,
            edit=True,
            height=STATUS_HEIGHT,
        )
