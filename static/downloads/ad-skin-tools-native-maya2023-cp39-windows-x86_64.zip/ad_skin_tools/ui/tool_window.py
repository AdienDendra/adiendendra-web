"""Maya workspace shell, shared UI state, and canonical mesh context loading."""

import builtins
import traceback

import maya.cmds as cmds

from ad_skin_tools.core.selection import get_selected_mesh_object
from ad_skin_tools.core.skin_cluster import SkinClusterAdapter, SkinClusterError


WINDOW_NAME = "ADSkinWeightsToolWorkspace"
WINDOW_LABEL = "AD Skin Tool"
WINDOW_WIDTH = 340
WINDOW_HEIGHT = 665

BUTTON_HEIGHT = 28
ROW_HEIGHT = 26
LABEL_WIDTH = 108
CONTROL_GAP = 6
BUTTON_GAP = 4

CTRL_MAIN_SCROLL = "adSkin_mainScroll"
CTRL_MAIN_COLUMN = "adSkin_mainColumn"
CTRL_SKIN_MENU = "adSkin_skinClusterMenu"
CTRL_MESH_LABEL = "adSkin_meshLabel"
CTRL_MODE_LABEL = "adSkin_modeLabel"
CTRL_JOINT_LABEL = "adSkin_jointCountLabel"
CTRL_JOINT_LIST = "adSkin_jointList"
CTRL_BIND_BUTTON = "adSkin_bindAutomaticSurfaceButton"
CTRL_BIND_PROGRESS = "adSkin_bindAutomaticSurfaceProgress"
CTRL_BIND_STATUS = "adSkin_bindAutomaticSurfaceStatus"

_STATE = {
    "mesh_shape": None,
    "mesh_transform": None,
    "skin_cluster": None,
    "has_skin_cluster": False,
    "joints": [],
    "joint_display_to_path": {},
    "joint_path_to_display": {},
    "busy": False,
}

_CONTEXT_CHANGE_CALLBACK = None
_TOOL_HELP_CALLBACK = None
_LICENSE_CALLBACK = None
_JOINT_COUNT_CALLBACK = None
_SECTION_BUILDERS = {
    "mesh_context": None,
    "joints": None,
    "utilities": None,
}
_SKIN_OPERATION_CALLBACKS = {
    "set_joint_list": None,
    "set_bind_busy": None,
    "set_skin_cluster_items": None,
}


def configure_window(label, width, height) -> None:
    """Configure the canonical workspace label and initial dimensions."""

    global WINDOW_LABEL, WINDOW_WIDTH, WINDOW_HEIGHT

    if not isinstance(label, str) or not label:
        raise TypeError("Window label must be a non-empty string.")
    for name, value in (("width", width), ("height", height)):
        if not isinstance(value, int) or value <= 0:
            raise TypeError("Window {} must be a positive integer.".format(name))

    WINDOW_LABEL = label
    WINDOW_WIDTH = width
    WINDOW_HEIGHT = height


def configure_section_builders(mesh_context, joints, utilities) -> None:
    """Configure the three top-level workspace sections explicitly."""

    builders = {
        "mesh_context": mesh_context,
        "joints": joints,
        "utilities": utilities,
    }
    for name, builder in builders.items():
        if not callable(builder):
            raise TypeError("Section builder '{}' must be callable.".format(name))
    _SECTION_BUILDERS.update(builders)


def configure_skin_operation_callbacks(
    set_joint_list,
    set_bind_busy,
    set_skin_cluster_items,
) -> None:
    """Configure callbacks owned by the shared skin-operation controller."""

    callbacks = {
        "set_joint_list": set_joint_list,
        "set_bind_busy": set_bind_busy,
        "set_skin_cluster_items": set_skin_cluster_items,
    }
    for name, callback in callbacks.items():
        if not callable(callback):
            raise TypeError(
                "Skin-operation callback '{}' must be callable.".format(name)
            )
    _SKIN_OPERATION_CALLBACKS.update(callbacks)


def configure_tool_help_callback(callback) -> None:
    """Configure the callback used by the Tool Help header button."""

    global _TOOL_HELP_CALLBACK
    if not callable(callback):
        raise TypeError("Tool Help callback must be callable.")
    _TOOL_HELP_CALLBACK = callback


def configure_license_callback(callback) -> None:
    """Configure the callback used by the License header button."""

    global _LICENSE_CALLBACK
    if not callable(callback):
        raise TypeError("License callback must be callable.")
    _LICENSE_CALLBACK = callback


def configure_joint_count_callback(callback) -> None:
    """Configure the callback that refreshes the Listed Joints value."""

    global _JOINT_COUNT_CALLBACK
    if not callable(callback):
        raise TypeError("Joint-count callback must be callable.")
    _JOINT_COUNT_CALLBACK = callback


def configure_context_change_callback(callback=None) -> None:
    """Set the observer notified after the loaded skin context changes."""

    global _CONTEXT_CHANGE_CALLBACK
    if callback is not None and not callable(callback):
        raise TypeError("Context-change callback must be callable or None.")
    _CONTEXT_CHANGE_CALLBACK = callback


def _notify_context_changed() -> None:
    callback = _CONTEXT_CHANGE_CALLBACK
    if callback is not None:
        callback()


def show(auto_refresh=False):
    """Create the workspace after feature modules install their final builders."""

    _delete_existing_workspace()
    cmds.workspaceControl(
        WINDOW_NAME,
        label=WINDOW_LABEL,
        retain=False,
        floating=True,
        initialWidth=WINDOW_WIDTH,
        initialHeight=WINDOW_HEIGHT,
    )
    cmds.setParent(WINDOW_NAME)

    cmds.scrollLayout(
        CTRL_MAIN_SCROLL,
        childResizable=True,
        verticalScrollBarThickness=16,
        horizontalScrollBarThickness=0,
    )
    cmds.columnLayout(
        CTRL_MAIN_COLUMN,
        adjustableColumn=True,
        rowSpacing=5,
        columnAttach=("both", 5),
    )

    _build_header()
    _build_skin_cluster_section()
    _build_joints_section()
    _build_initial_bind_section()

    cmds.setParent("..")
    cmds.setParent("..")

    if auto_refresh:
        load_skin_weight(silent=True)


def _delete_existing_workspace():
    if cmds.workspaceControl(WINDOW_NAME, exists=True):
        cmds.deleteUI(WINDOW_NAME)
    try:
        if cmds.workspaceControlState(WINDOW_NAME, exists=True):
            cmds.workspaceControlState(WINDOW_NAME, remove=True)
    except Exception:
        pass


def _build_header():
    _button_row(
        [
            ("Tool Help", lambda *_: show_help()),
            ("License", lambda *_: show_license()),
        ]
    )


def _build_skin_cluster_section():
    _configured_section_builder("mesh_context")()


def _build_joints_section():
    _configured_section_builder("joints")()


def _build_initial_bind_section():
    _configured_section_builder("utilities")()


def _configured_section_builder(name):
    builder = _SECTION_BUILDERS.get(name)
    if builder is None:
        raise RuntimeError(
            "UI section '{}' was not configured before show().".format(name)
        )
    return builder


def _configured_skin_operation_callback(name):
    callback = _SKIN_OPERATION_CALLBACKS.get(name)
    if callback is None:
        raise RuntimeError(
            "Skin-operation callback '{}' was not configured before use.".format(name)
        )
    return callback


def _configured_tool_help_callback():
    if _TOOL_HELP_CALLBACK is None:
        raise RuntimeError("Tool Help callback was not configured before use.")
    return _TOOL_HELP_CALLBACK


def _configured_license_callback():
    if _LICENSE_CALLBACK is None:
        raise RuntimeError("License callback was not configured before use.")
    return _LICENSE_CALLBACK


def _create_bind_progress_bar():
    try:
        cmds.progressBar(
            CTRL_BIND_PROGRESS,
            maxValue=100,
            progress=0,
            isIndeterminate=True,
            visible=False,
            height=12,
        )
    except TypeError:
        cmds.progressBar(
            CTRL_BIND_PROGRESS,
            maxValue=100,
            progress=50,
            visible=False,
            height=12,
        )


def load_skin_weight(silent=False):
    """Load one selected polygon mesh and its current skin context."""

    try:
        _require_not_busy()
        mesh_selection = get_selected_mesh_object()
        mesh_shape = mesh_selection.mesh_shape
        mesh_transform = mesh_selection.mesh_transform

        try:
            adapter = SkinClusterAdapter.from_mesh(mesh_shape)
            skin_cluster = adapter.skin_cluster
            joints = adapter.influences()
            has_skin = True
        except SkinClusterError:
            skin_cluster = None
            joints = []
            has_skin = False

        _STATE.update(
            {
                "mesh_shape": mesh_shape,
                "mesh_transform": mesh_transform,
                "skin_cluster": skin_cluster,
                "has_skin_cluster": has_skin,
                "joints": builtins.list(joints),
            }
        )

        _set_option_menu_items(
            CTRL_SKIN_MENU,
            [skin_cluster if skin_cluster else "<no skinCluster>"],
        )
        _set_joint_list(_STATE["joints"])
        _update_joint_count_label()

        if has_skin:
            _info("Loaded the selected mesh and existing skinCluster.")
        else:
            _info("Loaded an unskinned mesh. Add joints to bind.")
    except Exception as exc:
        if not silent:
            _show_error(exc)

    _notify_context_changed()


def refresh_from_selection(silent=False):
    load_skin_weight(silent=silent)


def _sync_loaded_skin_context():
    """Refresh the loaded skinCluster and influence list after an operation."""

    mesh_shape = _STATE.get("mesh_shape")
    if not mesh_shape or not cmds.objExists(mesh_shape):
        raise RuntimeError("Loaded mesh no longer exists.")

    adapter = SkinClusterAdapter.from_mesh(mesh_shape)
    joints = adapter.influences()
    _STATE.update(
        {
            "skin_cluster": adapter.skin_cluster,
            "has_skin_cluster": True,
            "joints": builtins.list(joints),
        }
    )
    _set_option_menu_items(CTRL_SKIN_MENU, [adapter.skin_cluster])
    _set_joint_list(joints)
    _update_joint_count_label()
    _notify_context_changed()


def _set_bind_busy(busy, status=""):
    return _configured_skin_operation_callback("set_bind_busy")(busy, status)


def show_help():
    return _configured_tool_help_callback()()


def show_license():
    return _configured_license_callback()()


def _require_not_busy():
    if _STATE.get("busy"):
        raise RuntimeError("An AD Skin Tool operation is already running.")


def _require_loaded_mesh():
    if not _STATE.get("mesh_shape"):
        raise RuntimeError("No mesh loaded. Select a mesh and click Load Mesh.")


def _require_unskinned_mesh():
    _require_loaded_mesh()
    if _STATE.get("has_skin_cluster"):
        raise RuntimeError(
            "This mesh already has a skinCluster.\n\n"
            "Initial object binding is only available for an unskinned mesh."
        )


def _set_option_menu_items(control_name, items):
    return _configured_skin_operation_callback("set_skin_cluster_items")(
        control_name,
        items,
    )


def _set_joint_list(joints):
    return _configured_skin_operation_callback("set_joint_list")(joints)


def _update_joint_count_label():
    if _JOINT_COUNT_CALLBACK is None:
        raise RuntimeError("Joint-count callback was not configured before use.")
    return _JOINT_COUNT_CALLBACK()


def _joint_exists_in_list(joint, joint_list):
    normalized = _normalize_joint_path(joint)
    return any(
        _normalize_joint_path(existing) == normalized
        for existing in joint_list
    )


def _normalize_joint_path(joint):
    matches = cmds.ls(joint, long=True, type="joint") or []
    return matches[0] if matches else joint


def _unique_joint_paths(joints):
    result = []
    seen = set()
    for joint in joints:
        normalized = _normalize_joint_path(joint)
        if normalized in seen:
            continue
        seen.add(normalized)
        result.append(normalized)
    return result


def _make_unique_joint_label(joint, all_joints):
    joint_parts = _dag_parts(joint)
    if not joint_parts:
        return joint

    for depth in range(1, len(joint_parts) + 1):
        label = "|".join(joint_parts[-depth:])
        count = sum(
            1
            for other_joint in all_joints
            if "|".join(_dag_parts(other_joint)[-depth:]) == label
        )
        if count == 1:
            return label
    return joint


def _dag_parts(node):
    return [part for part in str(node).split("|") if part]


def _label_control_row(label, control_builder, height=ROW_HEIGHT):
    layout = cmds.formLayout(height=height)
    label_control = cmds.text(
        label=label,
        align="left",
        width=LABEL_WIDTH,
    )
    control = control_builder()
    cmds.formLayout(
        layout,
        edit=True,
        attachForm=[
            (label_control, "left", 0),
            (label_control, "top", 2),
            (label_control, "bottom", 2),
            (control, "right", 0),
            (control, "top", 2),
            (control, "bottom", 2),
        ],
        attachControl=[(control, "left", CONTROL_GAP, label_control)],
    )
    cmds.setParent("..")
    return control


def _button_row(buttons, height=BUTTON_HEIGHT, gap=BUTTON_GAP):
    layout = cmds.formLayout(numberOfDivisions=100, height=height)
    count = len(buttons)
    if count == 0:
        cmds.setParent("..")
        return layout

    for index, (label, callback) in enumerate(buttons):
        left_position = int(index * 100 / count)
        right_position = int((index + 1) * 100 / count)
        button = cmds.button(
            label=label,
            height=height,
            command=callback,
        )
        cmds.formLayout(
            layout,
            edit=True,
            attachForm=[
                (button, "top", 1),
                (button, "bottom", 1),
            ],
            attachPosition=[
                (
                    button,
                    "left",
                    0 if index == 0 else gap // 2,
                    left_position,
                ),
                (
                    button,
                    "right",
                    0 if index == count - 1 else gap // 2,
                    right_position,
                ),
            ],
        )

    cmds.setParent("..")
    return layout


def _info(message):
    cmds.inViewMessage(
        assistMessage=message,
        position="topCenter",
        fade=True,
    )


def _show_error(exc):
    traceback.print_exc()
    cmds.warning(str(exc))
    cmds.confirmDialog(
        title="AD Skin Tool Error",
        message=str(exc),
        button=["OK"],
    )
