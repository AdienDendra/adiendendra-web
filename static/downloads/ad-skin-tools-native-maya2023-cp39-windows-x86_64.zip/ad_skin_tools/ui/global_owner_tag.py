"""Global Owner state and final joint-list presentation/context actions."""

import os

import maya.cmds as cmds

_STATE_OWNER = "global_owner_joint"
_STATE_MESH = "global_owner_mesh_shape"
_GLOBAL_OWNER_TEXT_COLOR = (1.0, 0.78, 0.15)
_LOCKED_ICON_PATH = os.path.normpath(
    os.path.join(
        os.path.dirname(__file__),
        "..",
        "resources",
        "lock_yellow.png",
    )
).replace("\\", "/")

_TOOL_WINDOW = None
_JOINT_LIST = None
_SELECT_ALL_JOINTS_CALLBACK = None


def configure(
    tool_window_module,
    joint_list_module,
    select_all_joints_in_scene_callback,
) -> None:
    """Attach dependencies and initialize Global Owner state."""

    global _TOOL_WINDOW, _JOINT_LIST, _SELECT_ALL_JOINTS_CALLBACK

    if not callable(select_all_joints_in_scene_callback):
        raise TypeError("Select-all-joints callback must be callable.")

    _TOOL_WINDOW = tool_window_module
    _JOINT_LIST = joint_list_module
    _SELECT_ALL_JOINTS_CALLBACK = select_all_joints_in_scene_callback
    state = _state()
    state.setdefault(_STATE_OWNER, None)
    state.setdefault(_STATE_MESH, None)

def render_joint_list_overlays(joints) -> None:
    """Overlay Global Owner and production lock visuals on canonical rows."""

    _normalize_global_owner_state(joints)
    _render_global_owner_text(joints)
    _render_locked_icons(joints)


def global_owner_joint():
    """Return the valid Global Owner for the currently loaded mesh."""

    joints = list(_state().get("joints", []))
    _normalize_global_owner_state(joints)
    return _state().get(_STATE_OWNER)


def set_selected_as_global_owner() -> None:
    def action():
        _require_editable()
        selected = list(_JOINT_LIST.selected_joint_paths())
        if len(selected) != 1:
            raise RuntimeError(
                "Select exactly one joint in the list before setting Global Owner."
            )

        joint = selected[0]
        joints = list(_state().get("joints", []))
        if joint not in joints:
            raise RuntimeError("The selected joint is no longer in the UI list.")

        _state()[_STATE_OWNER] = joint
        _state()[_STATE_MESH] = _state().get("mesh_shape")
        _JOINT_LIST.set_joint_list(joints)
        _JOINT_LIST.select_joint_paths([joint])
        _TOOL_WINDOW._info("Global Owner: {}".format(_short_name(joint)))

    _run_action(action)


def clear_global_owner() -> None:
    def action():
        _require_editable()
        if not _state().get(_STATE_OWNER):
            cmds.warning("No Global Owner is currently set.")
            return

        _state()[_STATE_OWNER] = None
        _state()[_STATE_MESH] = None
        _JOINT_LIST.set_joint_list(list(_state().get("joints", [])))
        _TOOL_WINDOW._info("Global Owner cleared.")

    _run_action(action)


def select_all_pending_joints() -> None:
    def action():
        _TOOL_WINDOW._require_not_busy()
        _TOOL_WINDOW._require_loaded_mesh()
        pending = _JOINT_LIST.pending_joint_paths()
        if not pending:
            cmds.warning("No pending joints are available in the list.")
            return
        _JOINT_LIST.select_joint_paths(pending)
        _TOOL_WINDOW._info(
            "Selected all {} pending joint(s) in the list.".format(len(pending))
        )

    _run_action(action)


def select_all_joints_in_scene() -> None:
    if _SELECT_ALL_JOINTS_CALLBACK is None:
        raise RuntimeError("Select-all-joints callback is not configured.")
    return _SELECT_ALL_JOINTS_CALLBACK()


def populate_joint_context_menu(menu, *_args) -> None:
    """Build the final production menu without a second insertion patch."""

    cmds.popupMenu(menu, edit=True, deleteAllItems=True)
    groups = (
        (
            ("Lock Selected", lambda: _JOINT_LIST.lock_selected_joints(True), True),
            ("Unlock Selected", lambda: _JOINT_LIST.lock_selected_joints(False), True),
        ),
        (
            (
                "Lock Inverse Selected",
                lambda: _JOINT_LIST.lock_selected_joints(True, inverse=True),
                True,
            ),
            (
                "Unlock Inverse Selected",
                lambda: _JOINT_LIST.lock_selected_joints(False, inverse=True),
                True,
            ),
        ),
        (
            ("Select All Pending Joints", select_all_pending_joints, True),
            (
                "Remove Selected Pending Joints",
                _JOINT_LIST.remove_selected_joints,
                True,
            ),
            (
                "Remove Inverse Selected Pending Joints",
                _JOINT_LIST.remove_inverse_selected_joints,
                True,
            ),
            (
                "Remove All Pending Joints",
                _JOINT_LIST.remove_all_joints,
                True,
            ),
        ),
        (
            ("Select Vertices", _JOINT_LIST.select_vertices, True),
            ("Select All Joints In The Scene", select_all_joints_in_scene, True),
            ("Select Joint In The Scene", _JOINT_LIST.select_joints_in_scene, True),
        ),
        (
            (
                "Set As Global Owner",
                set_selected_as_global_owner,
                _global_owner_is_editable(),
            ),
            (
                "Clear Global Owner",
                clear_global_owner,
                bool(_global_owner_is_editable() and global_owner_joint()),
            ),
        ),
    )

    for group_index, group in enumerate(groups):
        if group_index:
            cmds.menuItem(divider=True, parent=menu)
        for label, callback, enabled in group:
            _menu_item(menu, label, callback, enabled=enabled)


def _menu_item(menu, label, callback, enabled=True):
    return cmds.menuItem(
        label=label,
        parent=menu,
        enable=bool(enabled),
        command=lambda *_: callback(),
    )


def _global_owner_is_editable() -> bool:
    state = _state()
    return bool(
        state.get("mesh_shape")
        and not state.get("busy")
        and not state.get("has_skin_cluster")
    )


def _require_editable() -> None:
    _TOOL_WINDOW._require_not_busy()
    _TOOL_WINDOW._require_unskinned_mesh()


def _normalize_global_owner_state(joints) -> None:
    state = _state()
    joint = state.get(_STATE_OWNER)
    valid = bool(
        joint
        and state.get("mesh_shape")
        and state.get(_STATE_MESH) == state.get("mesh_shape")
        and joint in joints
        and cmds.objExists(joint)
    )
    if not valid:
        state[_STATE_OWNER] = None
        state[_STATE_MESH] = None


def _render_global_owner_text(joints) -> None:
    joint = _state().get(_STATE_OWNER)
    if not joint or joint not in joints:
        return
    item_id = _state().get("joint_path_to_item", {}).get(joint)
    control = _TOOL_WINDOW.CTRL_JOINT_LIST
    if not item_id or not _JOINT_LIST._tree_item_exists(control, item_id):
        return
    cmds.treeView(
        control,
        edit=True,
        textColor=(item_id,) + _GLOBAL_OWNER_TEXT_COLOR,
    )


def _render_locked_icons(joints) -> None:
    if not os.path.isfile(_LOCKED_ICON_PATH):
        return
    control = _TOOL_WINDOW.CTRL_JOINT_LIST
    path_to_item = _state().get("joint_path_to_item", {})
    for joint in joints:
        if not _JOINT_LIST.joint_is_locked(joint):
            continue
        item_id = path_to_item.get(joint)
        if item_id and _JOINT_LIST._tree_item_exists(control, item_id):
            cmds.treeView(
                control,
                edit=True,
                image=(item_id, 1, _LOCKED_ICON_PATH),
            )


def _run_action(callback) -> None:
    try:
        callback()
    except Exception as exc:
        _TOOL_WINDOW._show_error(exc)


def _state():
    return _TOOL_WINDOW._STATE


def _short_name(path):
    return str(path).rsplit("|", 1)[-1]
