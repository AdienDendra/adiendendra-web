"""Skin Weight Visual, ephemeral colors, and live joint selection."""

import maya.api.OpenMaya as om
import maya.cmds as cmds
from maya import OpenMayaUI as omui

from ad_skin_tools.core.compat import ensure_numpy, import_qt_modules
from ad_skin_tools.core.skin_cluster import SkinClusterAdapter
from ad_skin_tools.licensing import gate
from ad_skin_tools.ui import qt_helpers, skin_weight_color_session
from ad_skin_tools.ui.skin_weight_ramps import (
    MODE_OFF,
    MODE_ORDER,
    MODE_TOOLTIPS,
    RAMPS,
    VALID_MODES,
)

np = ensure_numpy()

_MODE_KEY = "skin_weight_mode"
_PREVIEW_KEY = "skin_weight_preview_joint"
_REFRESH_KEY = "skin_weight_mode_refresh"
_LIVE_STATE_KEY = "skin_weight_live_joint_selection"
_CONTROLS_NAME = "adSkinWeightModeControls"
_LIVE_CONTROLS_NAME = "adSkinWeightLiveSelectionControls"

_TOOL_WINDOW = None
_JOINT_LIST = None
_SKIN_OPERATIONS = None
_QT = None
_CONTROLS = None
_BUTTONS = {}
_BUTTON_GROUP = None
_LIVE_CONTROLS = None
_LIVE_LABEL = None
_LIVE_BUTTONS = {}
_LIVE_BUTTON_GROUP = None
_CONNECTED_BUTTONS = []
_SCRIPT_JOBS = []
_SCENE_CALLBACKS = []
_SELECTION_JOB = None
_REFRESH_QUEUED = False
_LICENSED = False


def install(tool_window_module, joint_list_module, skin_operations_module=None):
    """Install visual controls and all live runtime callbacks once."""

    global _TOOL_WINDOW, _JOINT_LIST, _SKIN_OPERATIONS
    _TOOL_WINDOW = tool_window_module
    _JOINT_LIST = joint_list_module
    _SKIN_OPERATIONS = skin_operations_module

    state = _state()
    state[_MODE_KEY] = MODE_OFF
    state[_PREVIEW_KEY] = None
    state.setdefault(_LIVE_STATE_KEY, True)
    state[_REFRESH_KEY] = request_refresh

    controls_installed = _install_controls()
    if controls_installed:
        _install_live_controls()
    _install_tree_callback()
    _connect_operation_buttons()
    _install_script_jobs()
    _install_scene_callbacks()
    _install_selection_job()
    _set_button_state(MODE_OFF)
    _set_live_button_state(_live_enabled())
    _set_live_controls_enabled(False)
    return controls_installed


def shutdown(*_):
    """Remove preview data and every persistent callback owned by this module."""

    global _CONTROLS, _BUTTONS, _BUTTON_GROUP, _CONNECTED_BUTTONS
    global _LIVE_CONTROLS, _LIVE_LABEL, _LIVE_BUTTONS, _LIVE_BUTTON_GROUP
    global _SCRIPT_JOBS, _SCENE_CALLBACKS, _SELECTION_JOB, _REFRESH_QUEUED

    _deactivate()
    _remove_script_jobs()
    _remove_scene_callbacks()
    _remove_selection_job()
    _CONTROLS = None
    _BUTTONS = {}
    _BUTTON_GROUP = None
    _LIVE_CONTROLS = None
    _LIVE_LABEL = None
    _LIVE_BUTTONS = {}
    _LIVE_BUTTON_GROUP = None
    _CONNECTED_BUTTONS = []
    _SCRIPT_JOBS = []
    _SCENE_CALLBACKS = []
    _SELECTION_JOB = None
    _REFRESH_QUEUED = False


def set_mode(mode):
    """Activate one visual preset or restore normal mesh display."""

    if _TOOL_WINDOW is None or mode not in VALID_MODES:
        return
    if mode == MODE_OFF:
        _deactivate()
        _set_live_controls_enabled(False)
        return
    if not gate.require(gate.SKIN_WEIGHT_VISUAL):
        _deactivate()
        return

    previous_mode = _state().get(_MODE_KEY, MODE_OFF)
    try:
        if _live_enabled():
            _sync_scene_selection(update_preview=False)
        joint = _require_single_selected_bound_joint()
        _activate(mode, joint)
        _set_live_controls_enabled(True)
        if _live_enabled():
            _sync_scene_selection(update_preview=True)
    except Exception as exc:
        if previous_mode == MODE_OFF:
            _deactivate()
        else:
            _set_button_state(previous_mode)
        _TOOL_WINDOW._show_error(exc)


def set_live_selection(enabled) -> None:
    """Store the artist preference without changing the active visual mode."""

    if _TOOL_WINDOW is None:
        return
    _state()[_LIVE_STATE_KEY] = bool(enabled)
    _set_live_button_state(enabled)
    if enabled and _mode_is_active():
        _sync_scene_selection(update_preview=True)


def set_licensed_enabled(enabled, allow_license_prompt=False) -> None:
    """Disable non-Off visual modes and clean colors when access locks."""

    global _LICENSED
    _LICENSED = bool(enabled)
    if not _LICENSED:
        _deactivate()
    for mode, button in _BUTTONS.items():
        try:
            button.setEnabled(
                mode == MODE_OFF
                or _LICENSED
                or bool(allow_license_prompt)
            )
        except RuntimeError:
            pass


def request_refresh(*_):
    """Coalesce selection, operation, Undo, and Redo refreshes."""

    global _REFRESH_QUEUED
    if not _mode_is_active() or _REFRESH_QUEUED:
        return
    _REFRESH_QUEUED = True
    try:
        cmds.evalDeferred(_deferred_refresh)
    except Exception as exc:
        _REFRESH_QUEUED = False
        cmds.warning(
            "Skin Weight Visual could not queue a safe refresh: {}".format(exc)
        )


def refresh(*_):
    """Read current influence weights and repaint the ephemeral color session."""

    if not _mode_is_active():
        return

    state = _state()
    mode = state.get(_MODE_KEY, MODE_OFF)
    mesh_shape = state.get("mesh_shape")
    mesh_transform = state.get("mesh_transform")
    joint = state.get(_PREVIEW_KEY)
    if not all((mesh_shape, mesh_transform, joint)):
        _deactivate()
        return
    if joint not in set(state.get("bound_joint_paths", set())):
        _deactivate()
        return
    if not all(cmds.objExists(node) for node in (mesh_shape, mesh_transform, joint)):
        _deactivate()
        return

    try:
        adapter = SkinClusterAdapter.from_mesh(mesh_shape)
        rgb = _map_weights_to_rgb(adapter.influence_weights(joint), mode)
        skin_weight_color_session.set_colors(mesh_shape, mesh_transform, rgb)
    except Exception as exc:
        cmds.warning("Skin Weight Visual refresh failed: {}".format(exc))


def _activate(mode, joint):
    state = _state()
    mesh_shape = state.get("mesh_shape")
    mesh_transform = state.get("mesh_transform")
    skin_cluster = state.get("skin_cluster")
    if not all((mesh_shape, mesh_transform, skin_cluster)):
        raise RuntimeError(
            "Skin Weight Visual requires a loaded mesh with an existing skinCluster."
        )
    for node in (mesh_shape, mesh_transform, skin_cluster, joint):
        if not cmds.objExists(node):
            raise RuntimeError(
                "Skin Weight Visual could not resolve the loaded skin context."
            )

    adapter = SkinClusterAdapter.from_mesh(mesh_shape)
    rgb = _map_weights_to_rgb(adapter.influence_weights(joint), mode)
    skin_weight_color_session.set_colors(mesh_shape, mesh_transform, rgb)
    state[_MODE_KEY] = mode
    state[_PREVIEW_KEY] = joint
    _set_button_state(mode)


def _deferred_refresh():
    global _REFRESH_QUEUED
    _REFRESH_QUEUED = False
    refresh()


def _map_weights_to_rgb(weights, mode):
    values = np.clip(
        np.asarray(weights, dtype=np.float64).reshape(-1),
        0.0,
        1.0,
    )
    ramp = RAMPS[mode]
    positions = np.asarray([point[0] for point in ramp], dtype=np.float64)
    colors = np.asarray([point[1] for point in ramp], dtype=np.float64)
    return np.column_stack(
        [
            np.interp(values, positions, colors[:, channel])
            for channel in range(3)
        ]
    )


def _deactivate():
    if _TOOL_WINDOW is not None:
        _state()[_MODE_KEY] = MODE_OFF
        _state()[_PREVIEW_KEY] = None
    _set_button_state(MODE_OFF)
    _set_live_controls_enabled(False)
    skin_weight_color_session.cleanup()


def _require_single_selected_bound_joint():
    try:
        selected = list(_JOINT_LIST.selected_joint_paths())
    except Exception:
        selected = []
    if len(selected) != 1:
        raise RuntimeError(
            "Skin Weight Visual requires exactly one selected bound influence."
        )

    joint = selected[0]
    if joint not in set(_state().get("bound_joint_paths", set())):
        raise RuntimeError(
            "The selected joint is pending and has no skin weights to display."
        )
    if not cmds.objExists(joint):
        raise RuntimeError(
            "The selected bound influence no longer exists in the scene."
        )
    return joint


def _install_controls():
    global _QT, _CONTROLS, _BUTTONS, _BUTTON_GROUP
    try:
        QtWidgets, QtGui, QtCore, binding = import_qt_modules()
        _QT = (QtWidgets, QtGui, QtCore, binding)
        label_widget = qt_helpers.wrap_instance(
            omui.MQtUtil.findControl(_TOOL_WINDOW.CTRL_JOINT_LABEL),
            QtWidgets.QWidget,
            binding,
        )
        container, layout, index = qt_helpers.find_managing_layout(label_widget)
        if layout is None:
            return False

        qt_helpers.remove_named_child(
            container,
            layout,
            QtWidgets.QWidget,
            _CONTROLS_NAME,
        )
        controls, buttons, group = _build_mode_controls(
            container,
            QtWidgets,
            QtGui,
            QtCore,
        )
        layout.insertWidget(index + 1, controls)
        _CONTROLS = controls
        _BUTTONS = buttons
        _BUTTON_GROUP = group
        return True
    except Exception:
        _CONTROLS = None
        _BUTTONS = {}
        _BUTTON_GROUP = None
        return False


def _build_mode_controls(container, QtWidgets, QtGui, QtCore):
    controls = QtWidgets.QWidget(container)
    controls.setObjectName(_CONTROLS_NAME)
    row = QtWidgets.QHBoxLayout(controls)
    row.setContentsMargins(0, 0, 0, 0)
    row.setSpacing(0)
    row.addWidget(QtWidgets.QLabel("Skin Weight Visual:", controls))
    row.addSpacing(3)

    group = QtWidgets.QButtonGroup(controls)
    group.setExclusive(True)
    buttons = {}
    for mode in MODE_ORDER:
        button = QtWidgets.QToolButton(controls)
        button.setCheckable(True)
        button.setAutoRaise(True)
        button.setFixedSize(22, 22)
        button.setToolTip(MODE_TOOLTIPS[mode])
        button.setIcon(_icon(mode, QtGui, QtCore))
        button.setIconSize(QtCore.QSize(18, 18))
        button.clicked.connect(
            lambda _checked=False, value=mode: set_mode(value)
        )
        group.addButton(button)
        row.addWidget(button)
        buttons[mode] = button
    row.addStretch(1)
    return controls, buttons, group


def _install_live_controls() -> bool:
    global _LIVE_CONTROLS, _LIVE_LABEL
    global _LIVE_BUTTONS, _LIVE_BUTTON_GROUP

    if _QT is None or _CONTROLS is None:
        return False
    QtWidgets, _QtGui, _QtCore, _binding = _QT
    container, layout, visual_index = qt_helpers.find_managing_layout(_CONTROLS)
    if layout is None:
        return False

    qt_helpers.remove_named_child(
        container,
        layout,
        QtWidgets.QWidget,
        _LIVE_CONTROLS_NAME,
    )
    controls = QtWidgets.QWidget(container)
    controls.setObjectName(_LIVE_CONTROLS_NAME)
    row = QtWidgets.QHBoxLayout(controls)
    row.setContentsMargins(0, 0, 0, 0)
    row.setSpacing(2)

    label = QtWidgets.QLabel("Live Joint Selection:", controls)
    row.addWidget(label)
    row.addSpacing(3)

    group = QtWidgets.QButtonGroup(controls)
    group.setExclusive(True)
    buttons = {}
    for enabled, text in ((True, "On"), (False, "Off")):
        button = QtWidgets.QToolButton(controls)
        button.setText(text)
        button.setCheckable(True)
        button.setAutoRaise(True)
        button.setFixedSize(30, 20)
        button.setToolTip(
            "Follow the last selected listed bound joint in the Maya viewport."
            if enabled
            else "Keep Skin Weight Visual controlled only from the joint list."
        )
        button.clicked.connect(
            lambda _checked=False, value=enabled: set_live_selection(value)
        )
        group.addButton(button)
        row.addWidget(button)
        buttons[enabled] = button
    row.addStretch(1)
    layout.insertWidget(visual_index + 1, controls)

    _LIVE_CONTROLS = controls
    _LIVE_LABEL = label
    _LIVE_BUTTONS = buttons
    _LIVE_BUTTON_GROUP = group
    return True


def _install_tree_callback():
    control = _TOOL_WINDOW.CTRL_JOINT_LIST
    if not cmds.treeView(control, exists=True):
        return
    try:
        cmds.treeView(
            control,
            edit=True,
            selectCommand=_tree_selection_changed,
        )
    except Exception:
        pass


def _tree_selection_changed(item_id, selected):
    try:
        allowed = bool(
            _JOINT_LIST._allow_tree_selection_change(item_id, selected)
        )
    except Exception:
        allowed = True
    if not allowed:
        return False

    if bool(selected) and _mode_is_active():
        joint = _state().get("joint_item_to_path", {}).get(item_id)
        if joint in set(_state().get("bound_joint_paths", set())):
            _state()[_PREVIEW_KEY] = joint
            request_refresh()
    return True


def _connect_operation_buttons():
    global _CONNECTED_BUTTONS
    if _QT is None:
        return

    from ad_skin_tools.ui import component_section, skin_operations

    QtWidgets, _QtGui, _QtCore, binding = _QT
    connected = []
    for name in (
        _TOOL_WINDOW.CTRL_BIND_BUTTON,
        skin_operations.CTRL_ADD_INFLUENCE_BUTTON,
        component_section.CTRL_FLOOD_BUTTON,
        component_section.CTRL_SMOOTH_BUTTON,
    ):
        button = qt_helpers.wrap_instance(
            omui.MQtUtil.findControl(name),
            QtWidgets.QPushButton,
            binding,
        )
        if button is None:
            continue
        try:
            button.clicked.connect(request_refresh)
            connected.append(button)
        except Exception:
            pass

    load_button = None
    if _SKIN_OPERATIONS is not None:
        load_button = qt_helpers.wrap_instance(
            omui.MQtUtil.findControl(_SKIN_OPERATIONS.CTRL_LOAD_MESH_BUTTON),
            QtWidgets.QPushButton,
            binding,
        )
    if load_button is not None:
        load_button.clicked.connect(lambda *_: _deactivate())
        connected.append(load_button)
    _CONNECTED_BUTTONS = connected


def _install_script_jobs():
    global _SCRIPT_JOBS
    _remove_script_jobs()
    _SCRIPT_JOBS = []
    parent = _TOOL_WINDOW.WINDOW_NAME
    for event_name, callback in (
        ("ToolChanged", _tool_changed),
        ("Undo", request_refresh),
        ("Redo", request_refresh),
    ):
        try:
            _SCRIPT_JOBS.append(
                cmds.scriptJob(
                    event=(event_name, callback),
                    parent=parent,
                    protected=True,
                )
            )
        except Exception:
            pass
    try:
        _SCRIPT_JOBS.append(
            cmds.scriptJob(
                uiDeleted=(parent, shutdown),
                runOnce=True,
            )
        )
    except Exception:
        pass


def _remove_script_jobs():
    for job in list(_SCRIPT_JOBS):
        try:
            if cmds.scriptJob(exists=job):
                cmds.scriptJob(kill=job, force=True)
        except Exception:
            pass


def _install_scene_callbacks():
    global _SCENE_CALLBACKS
    _remove_scene_callbacks()
    _SCENE_CALLBACKS = []
    for message in (
        om.MSceneMessage.kBeforeNew,
        om.MSceneMessage.kBeforeOpen,
        om.MSceneMessage.kBeforeSave,
    ):
        try:
            _SCENE_CALLBACKS.append(
                om.MSceneMessage.addCallback(message, _before_scene_change)
            )
        except Exception:
            pass


def _remove_scene_callbacks():
    for callback_id in list(_SCENE_CALLBACKS):
        try:
            om.MMessage.removeCallback(callback_id)
        except Exception:
            pass


def _install_selection_job() -> None:
    global _SELECTION_JOB
    _remove_selection_job()
    if _TOOL_WINDOW is None:
        return
    try:
        _SELECTION_JOB = cmds.scriptJob(
            event=("SelectionChanged", _on_scene_selection_changed),
            parent=_TOOL_WINDOW.WINDOW_NAME,
            protected=True,
        )
    except Exception:
        _SELECTION_JOB = None


def _remove_selection_job() -> None:
    global _SELECTION_JOB
    if _SELECTION_JOB is not None:
        try:
            if cmds.scriptJob(exists=_SELECTION_JOB):
                cmds.scriptJob(kill=_SELECTION_JOB, force=True)
        except Exception:
            pass
    _SELECTION_JOB = None


def _on_scene_selection_changed(*_):
    if _live_is_operational():
        _sync_scene_selection(update_preview=True)


def _sync_scene_selection(update_preview):
    joint = _last_valid_selected_scene_joint()
    if joint is None:
        return None
    _JOINT_LIST.select_joint_paths([joint])
    _show_joint_in_list(joint)
    if update_preview and _mode_is_active():
        _state()[_PREVIEW_KEY] = joint
        request_refresh()
    return joint


def _last_valid_selected_scene_joint():
    selected = _selected_scene_joints()
    if not selected:
        return None
    state = _state()
    listed = state.get("joint_path_to_item", {})
    bound = set(state.get("bound_joint_paths", set()))
    for joint in reversed(selected):
        try:
            normalized = _TOOL_WINDOW._normalize_joint_path(joint)
        except Exception:
            normalized = str(joint)
        if normalized in listed and normalized in bound:
            return normalized
    return None


def _selected_scene_joints():
    try:
        selected = cmds.ls(
            orderedSelection=True,
            long=True,
            type="joint",
        ) or []
    except Exception:
        selected = []
    if selected:
        return selected
    return cmds.ls(selection=True, long=True, type="joint") or []


def _show_joint_in_list(joint) -> None:
    control = _TOOL_WINDOW.CTRL_JOINT_LIST
    item_id = _state().get("joint_path_to_item", {}).get(joint)
    if not item_id or not cmds.treeView(control, exists=True):
        return
    try:
        if not cmds.treeView(control, query=True, itemExists=item_id):
            return
        cmds.treeView(control, edit=True, showItem=item_id)
    except Exception:
        pass


def _before_scene_change(*_):
    _deactivate()


def _tool_changed(*_):
    if _mode_is_active() and _is_skin_paint_context(_current_context()):
        _deactivate()


def _is_skin_paint_context(context):
    if not context:
        return False
    try:
        context_class = cmds.contextInfo(context, c=True)
    except Exception:
        context_class = ""
    text = "{} {}".format(context, context_class).casefold()
    return "artattrskin" in text or (
        "skin" in text and "paint" in text and "context" in text
    )


def _current_context():
    try:
        return cmds.currentCtx()
    except Exception:
        return None


def _set_button_state(mode):
    for value, button in _BUTTONS.items():
        qt_helpers.set_checked_silently(button, value == mode)


def _set_live_button_state(enabled) -> None:
    for value, button in _LIVE_BUTTONS.items():
        qt_helpers.set_checked_silently(button, value == bool(enabled))


def _set_live_controls_enabled(enabled) -> None:
    for button in _LIVE_BUTTONS.values():
        try:
            button.setEnabled(bool(enabled))
        except RuntimeError:
            pass


def _icon(mode, QtGui, QtCore):
    pixmap = QtGui.QPixmap(18, 18)
    colors = getattr(QtCore.Qt, "GlobalColor", QtCore.Qt)
    pixmap.fill(colors.transparent)

    painter = QtGui.QPainter(pixmap)
    try:
        hints = getattr(QtGui.QPainter, "RenderHint", QtGui.QPainter)
        painter.setRenderHint(hints.Antialiasing, True)
        rect = pixmap.rect().adjusted(1, 1, -2, -2)
        if mode == MODE_OFF:
            painter.fillRect(rect, QtGui.QColor(235, 235, 235))
            painter.setPen(QtGui.QPen(QtGui.QColor(210, 30, 30), 2.0))
            painter.drawLine(rect.bottomLeft(), rect.topRight())
        else:
            gradient = QtGui.QLinearGradient(
                rect.left(),
                0,
                rect.right(),
                0,
            )
            for position, rgb in RAMPS[mode]:
                gradient.setColorAt(
                    position,
                    QtGui.QColor.fromRgbF(*rgb),
                )
            painter.fillRect(rect, gradient)
        painter.setPen(QtGui.QPen(QtGui.QColor(30, 30, 30), 1.0))
        painter.drawRect(rect)
    finally:
        painter.end()
    return QtGui.QIcon(pixmap)


def _live_is_operational() -> bool:
    return bool(
        _TOOL_WINDOW is not None
        and not _state().get("busy")
        and _live_enabled()
        and _mode_is_active()
    )


def _live_enabled() -> bool:
    return bool(
        _TOOL_WINDOW is not None
        and _state().get(_LIVE_STATE_KEY, True)
    )


def _mode_is_active():
    return bool(
        _TOOL_WINDOW is not None
        and _state().get(_MODE_KEY, MODE_OFF) != MODE_OFF
    )


def _state():
    return _TOOL_WINDOW._STATE
