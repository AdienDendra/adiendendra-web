"""Asynchronous Maya adapter for the local licensing service and gate."""

from __future__ import annotations

import queue
import threading
from typing import Callable, Optional

import maya.cmds as cmds
import maya.utils as maya_utils

from ad_skin_tools.licensing import gate
from ad_skin_tools.licensing.network import LicensingApiError
from ad_skin_tools.licensing.service import (
    LicenseStatus,
    LicensingService,
    LicensingStateError,
    create_default_service,
)


_SERVICE = None  # type: Optional[LicensingService]
_QUEUE = None
_WORKER = None
_GENERATION = 0
_BUSY = False
_OPERATION_LABEL = ""
_NOTICE = ""
_UI_MODULES = {}
_RELEASE_CHECK_STARTED = False


def install(service: Optional[LicensingService] = None) -> None:
    """Install one service, one worker, and the central action gate."""

    shutdown()
    global _SERVICE, _QUEUE, _WORKER, _GENERATION
    _SERVICE = service or create_default_service()
    _QUEUE = queue.Queue()
    _GENERATION += 1
    generation = _GENERATION
    _WORKER = threading.Thread(
        target=_worker_loop,
        args=(generation, _QUEUE),
        name="ADSkinToolsLicensing",
        daemon=True,
    )
    _WORKER.start()
    gate.configure(_authorize, _handle_denied)


def configure_ui(
    *,
    tool_window,
    skin_operations,
    mirror_ui,
    transfer_ui,
    skin_weight_mode,
    license_dialog,
) -> None:
    """Connect controls after feature modules have installed their builders."""

    previous_skin_operations = _UI_MODULES.get("skin_operations")
    if previous_skin_operations is not None:
        previous_skin_operations.unregister_common_enabled_callback(
            _apply_protected_enabled
        )
    _UI_MODULES.clear()
    _UI_MODULES.update({
        "tool_window": tool_window,
        "skin_operations": skin_operations,
        "mirror_ui": mirror_ui,
        "transfer_ui": transfer_ui,
        "skin_weight_mode": skin_weight_mode,
        "license_dialog": license_dialog,
    })
    skin_operations.register_common_enabled_callback(
        _apply_protected_enabled
    )


def shutdown() -> None:
    """Invalidate callbacks and stop accepting work during reload."""

    global _SERVICE, _QUEUE, _WORKER, _GENERATION
    global _BUSY, _OPERATION_LABEL, _NOTICE, _RELEASE_CHECK_STARTED
    skin_operations = _UI_MODULES.get("skin_operations")
    if skin_operations is not None:
        skin_operations.unregister_common_enabled_callback(
            _apply_protected_enabled
        )
    _UI_MODULES.clear()
    gate.reset()
    _GENERATION += 1
    work_queue = _QUEUE
    _QUEUE = None
    if work_queue is not None:
        try:
            work_queue.put_nowait(None)
        except queue.Full:
            pass
    _WORKER = None
    _SERVICE = None
    _BUSY = False
    _OPERATION_LABEL = ""
    _NOTICE = ""
    _RELEASE_CHECK_STARTED = False


def status() -> LicenseStatus:
    if _SERVICE is None:
        raise LicensingStateError("License checking is not ready.")
    return _SERVICE.status()


def notice() -> str:
    return _NOTICE


def is_busy() -> bool:
    return _BUSY


def operation_label() -> str:
    return _OPERATION_LABEL


def start_trial() -> bool:
    """Queue the only operation allowed to start the trial clock."""

    return _submit("Starting trial...", _require_service().start_trial)


def activate(license_key: str) -> bool:
    service = _require_service()
    return _submit(
        "Activating license...",
        lambda: service.activate(license_key),
    )


def retry() -> bool:
    return _submit("Checking license...", _require_service().retry)


def deactivate() -> bool:
    return _submit(
        "Deactivating this device...",
        _require_service().deactivate_paid,
    )


def reset_local_state() -> None:
    global _NOTICE
    try:
        _require_service().reset_local_state()
        _NOTICE = "Local license data was reset."
    except LicensingStateError as exc:
        _NOTICE = exc.safe_message
    refresh_ui()


def queue_validation_if_due() -> bool:
    service = _require_service()
    if not service.should_validate():
        return False
    return _submit(
        "Checking license...",
        service.validate_paid,
        silent=True,
    )


def queue_release_check() -> bool:
    """Check once per controller session when the License window is opened."""

    global _RELEASE_CHECK_STARTED
    if _RELEASE_CHECK_STARTED or _QUEUE is None:
        return False
    _RELEASE_CHECK_STARTED = True
    try:
        _QUEUE.put_nowait(
            ("release", _require_service().check_releases, True)
        )
    except (queue.Full, LicensingStateError):
        _RELEASE_CHECK_STARTED = False
        return False
    return True


def refresh_ui() -> None:
    """Refresh License and protected controls on Maya's main thread."""

    tool_window = _UI_MODULES.get("tool_window")
    base_enabled = True
    if tool_window is not None:
        base_enabled = not bool(tool_window._STATE.get("busy"))
    _apply_protected_enabled(base_enabled)
    license_dialog = _UI_MODULES.get("license_dialog")
    if license_dialog is not None:
        try:
            license_dialog.refresh()
        except Exception:
            pass


def _authorize(action: str) -> gate.GateDecision:
    decision = _require_service().authorize(action)
    if decision.request_validation:
        queue_validation_if_due()
    return decision


def _handle_denied(_action: str, _decision: gate.GateDecision) -> None:
    # Re-evaluate every protected control at the denial boundary. This keeps
    # visual modes cleaned up when a trial expires during an open Maya session,
    # while the still-clickable controls remain a route to recovery.
    refresh_ui()
    license_dialog = _UI_MODULES.get("license_dialog")
    if license_dialog is not None:
        license_dialog.show()


def _apply_protected_enabled(base_enabled: bool) -> None:
    service = _SERVICE
    if service is None:
        licensed = False
        promptable = False
    else:
        try:
            current_status = service.status()
            licensed = current_status.access_allowed
            promptable = not current_status.access_allowed
        except Exception:
            licensed = False
            promptable = False
    enabled = bool(base_enabled and (licensed or promptable))

    tool_window = _UI_MODULES.get("tool_window")
    skin_operations = _UI_MODULES.get("skin_operations")
    mirror_ui = _UI_MODULES.get("mirror_ui")
    transfer_ui = _UI_MODULES.get("transfer_ui")
    if all((tool_window, skin_operations, mirror_ui, transfer_ui)):
        controls = (
            tool_window.CTRL_BIND_BUTTON,
            skin_operations.CTRL_ADD_INFLUENCE_BUTTON,
            "adSkin_floodSelectedToJointButton",
            "adSkin_smoothSelectedComponentsButton",
            mirror_ui.CTRL_PREVIEW,
            mirror_ui.CTRL_REGISTER_PAIRING,
            mirror_ui.CTRL_MIRROR,
            transfer_ui.CTRL_PREVIEW,
            transfer_ui.CTRL_APPLY,
        )
        for control in controls:
            if cmds.button(control, exists=True):
                cmds.button(control, edit=True, enable=enabled)

    skin_weight_mode = _UI_MODULES.get("skin_weight_mode")
    if skin_weight_mode is not None:
        skin_weight_mode.set_licensed_enabled(
            licensed,
            allow_license_prompt=promptable,
        )


def _submit(
    label: str,
    operation: Callable[[], LicenseStatus],
    *,
    silent: bool = False,
) -> bool:
    global _BUSY, _OPERATION_LABEL, _NOTICE
    if _BUSY or _QUEUE is None:
        if not silent:
            _NOTICE = "Another license request is already running."
            refresh_ui()
        return False
    _BUSY = True
    _OPERATION_LABEL = label
    _NOTICE = ""
    refresh_ui()
    try:
        _QUEUE.put_nowait(("license", operation, bool(silent)))
    except queue.Full:
        _BUSY = False
        _OPERATION_LABEL = ""
        if not silent:
            _NOTICE = "Another license request is already running."
        refresh_ui()
        return False
    return True


def _worker_loop(generation: int, work_queue) -> None:
    while True:
        task = work_queue.get()
        if task is None or generation != _GENERATION:
            return
        kind, operation, silent = task
        if kind == "release":
            actions = None
            try:
                actions = operation()
            except Exception:
                pass

            def finish_release(
                expected_generation=generation,
                release_actions=actions,
            ):
                _finish_release_check(
                    expected_generation,
                    release_actions,
                )

            try:
                maya_utils.executeDeferred(finish_release)
            except Exception:
                return
            continue

        message = ""
        try:
            operation()
        except (LicensingApiError, LicensingStateError) as exc:
            message = getattr(exc, "safe_message", str(exc))
        except Exception:
            message = "The license request could not be completed."

        def finish(
            expected_generation=generation,
            error_message=message,
            quiet=silent,
        ):
            _finish_request(expected_generation, error_message, quiet)

        try:
            maya_utils.executeDeferred(finish)
        except Exception:
            return


def _finish_request(generation: int, message: str, silent: bool) -> None:
    if generation != _GENERATION:
        return
    global _BUSY, _OPERATION_LABEL, _NOTICE
    _BUSY = False
    _OPERATION_LABEL = ""
    if message and not silent:
        _NOTICE = message
    refresh_ui()


def _finish_release_check(generation: int, actions) -> None:
    if generation != _GENERATION or actions is None:
        return
    if not isinstance(actions, tuple) or len(actions) != 2:
        return
    license_dialog = _UI_MODULES.get("license_dialog")
    if license_dialog is not None:
        license_dialog.configure_release_actions(
            update_action=actions[0],
            upgrade_action=actions[1],
        )


def _require_service() -> LicensingService:
    if _SERVICE is None:
        raise LicensingStateError("License checking is not ready.")
    return _SERVICE
