"""Shared operation controls, mesh-context helpers, and busy-state UI."""

import maya.cmds as cmds

from ad_skin_tools.ui import joint_list


CTRL_LOAD_MESH_BUTTON = "adSkin_loadMeshButton"
CTRL_ADD_INFLUENCE_BUTTON = "adSkin_addInfluenceButton"

_TOOL_WINDOW = None
_COMMON_ENABLE_CALLBACKS = []


def install(tool_window_module) -> None:
    """Configure canonical mesh loading and shared operation UI services."""

    global _TOOL_WINDOW

    _TOOL_WINDOW = tool_window_module
    joint_list.configure(tool_window_module)
    tool_window_module.configure_skin_operation_callbacks(
        set_joint_list=joint_list.set_joint_list,
        set_bind_busy=_set_bind_busy,
        set_skin_cluster_items=_set_skin_cluster_field_items,
    )


def register_common_enabled_callback(callback) -> None:
    """Register one feature-owned enabled-state contributor."""

    if callback not in _COMMON_ENABLE_CALLBACKS:
        _COMMON_ENABLE_CALLBACKS.append(callback)


def unregister_common_enabled_callback(callback) -> None:
    """Remove one previously registered enabled-state contributor."""

    try:
        _COMMON_ENABLE_CALLBACKS.remove(callback)
    except ValueError:
        pass


def _build_skin_cluster_section() -> None:
    """Compatibility builder replaced by mesh_context_display during install."""

    cmds.frameLayout(
        label="Mesh / Skin Context",
        collapsable=True,
        collapse=False,
        marginWidth=6,
        marginHeight=6,
    )
    cmds.columnLayout(adjustableColumn=True, rowSpacing=5)
    _TOOL_WINDOW._label_control_row(
        "Skin Cluster",
        lambda: cmds.textField(
            _TOOL_WINDOW.CTRL_SKIN_MENU,
            text="<no skinCluster>",
            editable=False,
        ),
    )
    cmds.text(
        _TOOL_WINDOW.CTRL_MESH_LABEL,
        label="Mesh: <none>",
        align="left",
    )
    cmds.text(
        _TOOL_WINDOW.CTRL_MODE_LABEL,
        label="",
        visible=False,
        manage=False,
    )
    cmds.text(
        _TOOL_WINDOW.CTRL_JOINT_LABEL,
        label="Joints: 0",
        align="left",
    )
    _named_button_row(
        [
            (
                CTRL_LOAD_MESH_BUTTON,
                "Load Mesh",
                lambda *_: _TOOL_WINDOW.load_skin_weight(),
            )
        ],
        height=30,
    )
    cmds.setParent("..")
    cmds.setParent("..")


def _empty_operation_sections() -> None:
    return None


def _set_skin_cluster_field_items(control_name, items) -> None:
    value = items[0] if items else "<no skinCluster>"
    if cmds.textField(control_name, exists=True):
        cmds.textField(control_name, edit=True, text=str(value))


def _refresh_mesh_context_labels() -> None:
    if _TOOL_WINDOW is None:
        return
    state = _state()
    _set_text_field(
        _TOOL_WINDOW.CTRL_SKIN_MENU,
        state.get("skin_cluster") or "<no skinCluster>",
    )
    mesh_transform = state.get("mesh_transform")
    mesh_label = _short_dag_name(mesh_transform) if mesh_transform else "<none>"
    _set_text(
        _TOOL_WINDOW.CTRL_MESH_LABEL,
        "Mesh: {}".format(mesh_label),
    )


def _set_bind_busy(busy, status="") -> None:
    _set_operation_busy(
        control=_TOOL_WINDOW.CTRL_BIND_BUTTON,
        busy=busy,
        busy_label="Binding...",
        idle_label="Bind Skin",
        status=status,
    )


def _set_add_influence_busy(busy, status="") -> None:
    _set_operation_busy(
        control=CTRL_ADD_INFLUENCE_BUTTON,
        busy=busy,
        busy_label="Adding...",
        idle_label="Add Influence",
        status=status,
    )


def _set_operation_busy(control, busy, busy_label, idle_label, status=""):
    busy = bool(busy)
    _set_common_enabled(not busy)
    _state()["busy"] = busy
    if cmds.button(control, exists=True):
        cmds.button(
            control,
            edit=True,
            label=busy_label if busy else idle_label,
        )
    _set_progress_status(busy, status)


def _set_common_enabled(enabled) -> None:
    """Enable canonical controls, then explicit feature contributors."""

    from ad_skin_tools.ui import component_section, smoothing_controls

    enabled = bool(enabled)
    smoothing_controls.set_enabled(enabled)
    for control in (
        _TOOL_WINDOW.CTRL_BIND_BUTTON,
        CTRL_ADD_INFLUENCE_BUTTON,
        component_section.CTRL_FLOOD_BUTTON,
        component_section.CTRL_SMOOTH_BUTTON,
    ):
        if cmds.button(control, exists=True):
            cmds.button(control, edit=True, enable=enabled)
    if cmds.treeView(_TOOL_WINDOW.CTRL_JOINT_LIST, exists=True):
        cmds.treeView(
            _TOOL_WINDOW.CTRL_JOINT_LIST,
            edit=True,
            enable=enabled,
        )

    for callback in tuple(_COMMON_ENABLE_CALLBACKS):
        callback(enabled)


def _set_progress_status(busy, status) -> None:
    busy = bool(busy)
    if cmds.progressBar(_TOOL_WINDOW.CTRL_BIND_PROGRESS, exists=True):
        kwargs = {"edit": True, "visible": busy}
        try:
            cmds.progressBar(
                _TOOL_WINDOW.CTRL_BIND_PROGRESS,
                isIndeterminate=busy,
                **kwargs
            )
        except TypeError:
            cmds.progressBar(
                _TOOL_WINDOW.CTRL_BIND_PROGRESS,
                progress=50 if busy else 0,
                **kwargs
            )
    if cmds.text(_TOOL_WINDOW.CTRL_BIND_STATUS, exists=True):
        cmds.text(
            _TOOL_WINDOW.CTRL_BIND_STATUS,
            edit=True,
            label=status if busy else "",
            visible=busy,
        )
    _refresh()


def _named_button_row(buttons, height=28, gap=4):
    layout = cmds.formLayout(numberOfDivisions=100, height=height)
    count = len(buttons)
    for index, (name, label, callback) in enumerate(buttons):
        left_position = int(index * 100 / count)
        right_position = int((index + 1) * 100 / count)
        button = cmds.button(
            name,
            label=label,
            height=height,
            command=callback,
        )
        cmds.formLayout(
            layout,
            edit=True,
            attachForm=[
                (button, "top", 1),
                (button, "bottom", 1),
            ],
            attachPosition=[
                (
                    button,
                    "left",
                    0 if index == 0 else gap // 2,
                    left_position,
                ),
                (
                    button,
                    "right",
                    0 if index == count - 1 else gap // 2,
                    right_position,
                ),
            ],
        )
    cmds.setParent("..")
    return layout


def _set_text_field(control, value) -> None:
    if cmds.textField(control, exists=True):
        cmds.textField(control, edit=True, text=str(value))


def _set_text(control, value) -> None:
    if cmds.text(control, exists=True):
        cmds.text(control, edit=True, label=str(value))


def _short_dag_name(node) -> str:
    return str(node).rsplit("|", 1)[-1]


def _refresh() -> None:
    try:
        cmds.refresh(force=True)
    except Exception:
        pass


def _state():
    return _TOOL_WINDOW._STATE
