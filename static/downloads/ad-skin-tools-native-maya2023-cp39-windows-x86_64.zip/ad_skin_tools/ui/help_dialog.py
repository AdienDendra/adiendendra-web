"""Tool Help, online documentation, and environment diagnostics UI."""

import webbrowser

import maya.cmds as cmds

from ad_skin_tools.core.compat import environment_report
from ad_skin_tools.ui.qt import import_qt_modules


WINDOW_NAME = "ADSkinWeightsToolHelpWindow"
DOCUMENTATION_URL = "https://adiendendra.com/en/documentation/ad-skin-tools/"
WINDOW_WIDTH = 340
WINDOW_HEIGHT = 540
CONTENT_WIDTH = 300

_HELP_SECTIONS = (
    (
        "Mesh / Skin Context",
        "Select one polygon mesh or one of its components, then click Load Mesh. "
        "The loaded mesh and its skinCluster become the working context for all "
        "operations. Skin Weight Visual displays the selected influence weights "
        "directly on the loaded mesh.",
    ),
    (
        "Joints / Influences",
        "Add scene joints to the influence list before binding or editing. Bind "
        "Skin creates the initial skinCluster on an unskinned mesh. Add Influence "
        "adds selected pending joints and assigns their natural surface regions. "
        "Flood edits the regions owned by selected bound influences, while Smooth "
        "averages the current weights. Blend and Iterations are shared by these "
        "operations; Iterations 0 keeps supported operations in hard mode.",
    ),
    (
        "Utilities",
        "Mirror transfers weights between registered symmetrical vertex and "
        "influence pairs. Preview Pairing first, register the valid result, then "
        "apply Mirror Skin Weights. Transfer uses registered source and target "
        "meshes: run Preview Transfer to validate the correspondence and target "
        "scope before applying weights. Object and component target scopes are "
        "handled separately.",
    ),
)


def show() -> None:
    """Open the standalone Tool Help window."""

    _delete_existing_window()
    window = cmds.window(
        WINDOW_NAME,
        title="AD Skin Tool - Help",
        widthHeight=(WINDOW_WIDTH, WINDOW_HEIGHT),
        sizeable=True,
    )
    cmds.scrollLayout(
        childResizable=True,
        verticalScrollBarThickness=16,
        horizontalScrollBarThickness=0,
    )
    cmds.columnLayout(
        adjustableColumn=True,
        rowSpacing=6,
        columnAttach=("both", 8),
        width=WINDOW_WIDTH - 16,
    )

    cmds.text(
        label="AD Skin Tool",
        align="left",
        font="boldLabelFont",
        height=24,
    )
    cmds.text(
        label=(
            "Quick reference for the main tool sections. Detailed workflows and "
            "tutorials are available in the online documentation."
        ),
        align="left",
        wordWrap=True,
        width=CONTENT_WIDTH,
        recomputeSize=True,
    )

    for title, description in _HELP_SECTIONS:
        _build_help_section(title, description)

    _build_documentation_section()
    _build_environment_section()

    cmds.showWindow(window)
    cmds.window(
        window,
        edit=True,
        widthHeight=(WINDOW_WIDTH, WINDOW_HEIGHT),
    )
def open_documentation() -> None:
    """Open the AD Skin Tools documentation in the system web browser."""

    try:
        cmds.showHelp(DOCUMENTATION_URL, absolute=True)
    except Exception:
        webbrowser.open(DOCUMENTATION_URL)


def copy_diagnostics() -> None:
    """Copy the current environment report to the system clipboard."""

    qt_widgets, _, _, _ = import_qt_modules()
    application = qt_widgets.QApplication.instance()
    if application is None:
        raise RuntimeError("Qt application is unavailable.")
    application.clipboard().setText(environment_report())
    cmds.inViewMessage(
        assistMessage="AD Skin Tools diagnostics copied to the clipboard.",
        position="topCenter",
        fade=True,
    )


def _delete_existing_window() -> None:
    if cmds.window(WINDOW_NAME, exists=True):
        cmds.deleteUI(WINDOW_NAME, window=True)


def _build_help_section(title: str, description: str) -> None:
    cmds.separator(style="in", height=8)
    cmds.text(
        label=title,
        align="left",
        font="boldLabelFont",
        height=22,
    )
    cmds.text(
        label=description,
        align="left",
        wordWrap=True,
        width=CONTENT_WIDTH,
        recomputeSize=True,
    )


def _build_documentation_section() -> None:
    cmds.separator(style="in", height=8)
    cmds.text(
        label="Documentation & Tutorials",
        align="left",
        font="boldLabelFont",
        height=22,
    )
    cmds.text(
        label=DOCUMENTATION_URL,
        align="left",
        wordWrap=True,
        width=CONTENT_WIDTH,
        recomputeSize=True,
    )
    cmds.button(
        label="Open Online Documentation",
        height=30,
        command=lambda *_: open_documentation(),
    )


def _build_environment_section() -> None:
    cmds.separator(style="in", height=8)
    cmds.text(
        label="Environment / Diagnostics",
        align="left",
        font="boldLabelFont",
        height=22,
    )
    cmds.scrollField(
        text=environment_report(),
        editable=False,
        wordWrap=True,
        height=132,
    )
    cmds.button(
        label="Copy Diagnostics",
        height=30,
        command=lambda *_: copy_diagnostics(),
    )
