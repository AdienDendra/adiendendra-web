"""Visible-row scene selection and natural numeric joint sorting."""

import re

import maya.cmds as cmds


_HIDDEN_ITEM_IDS_KEY = "joint_search_hidden_item_ids"
_NUMERIC_TOKEN_PATTERN = re.compile(r"(\d+)")

_TOOL_WINDOW = None
_JOINT_LIST = None


def install(tool_window_module, joint_list_module) -> None:
    """Install presentation behaviour without changing solver joint order."""

    global _TOOL_WINDOW, _JOINT_LIST
    _TOOL_WINDOW = tool_window_module
    _JOINT_LIST = joint_list_module


def visible_joint_paths():
    """Return existing UI rows in their current visible display order."""

    _require_installed()
    state = _state()
    hidden_item_ids = set(state.get(_HIDDEN_ITEM_IDS_KEY, set()))
    path_to_item = state.get("joint_path_to_item", {})
    control = _TOOL_WINDOW.CTRL_JOINT_LIST

    visible = []
    for joint in state.get("joint_display_order", []):
        item_id = path_to_item.get(joint)
        if not item_id or item_id in hidden_item_ids:
            continue
        if not _JOINT_LIST._tree_item_exists(control, item_id):
            continue
        visible.append(joint)
    return visible


def select_all_visible_joints_in_scene() -> None:
    """Select exactly the rows currently visible through Search and Pin."""

    def action():
        _TOOL_WINDOW._require_not_busy()
        _TOOL_WINDOW._require_loaded_mesh()

        visible = visible_joint_paths()
        if not visible:
            cmds.warning(
                "No visible joints are available in the current Search/Pin view."
            )
            return

        existing = []
        for joint in visible:
            matches = cmds.ls(joint, long=True, type="joint") or []
            if matches:
                existing.append(matches[0])

        if not existing:
            cmds.warning(
                "Visible joints in the current view no longer exist in the Maya scene."
            )
            return

        _JOINT_LIST.select_joint_paths(existing)
        cmds.select(existing, replace=True)
        _TOOL_WINDOW._info(
            "Selected all {} visible joint(s) in the UI and Maya scene.".format(
                len(existing)
            )
        )

    _run_action(action)


def sort_display_order(joints, display_labels, bound=None):
    """Sort presentation labels naturally while preserving solver list order."""

    _require_installed()
    mode = _state().get("joint_sort_mode", _JOINT_LIST.SORT_A_TO_Z)
    bound = set(
        bound if bound is not None else _JOINT_LIST.bound_joint_paths()
    )

    def label_key(joint):
        display = str(display_labels[joint])
        path = str(joint)
        return (
            _natural_key(display),
            _natural_key(path),
            display,
            path,
        )

    if mode == _JOINT_LIST.SORT_Z_TO_A:
        return sorted(joints, key=label_key, reverse=True)
    if mode == _JOINT_LIST.SORT_PENDING_JOINTS:
        return sorted(
            joints,
            key=lambda joint: (
                0 if joint not in bound else 1,
                *label_key(joint),
            ),
        )
    return sorted(joints, key=label_key)


def _natural_key(value):
    """Tokenize digit runs as integers with deterministic zero-padding ties."""

    tokens = []
    for token in _NUMERIC_TOKEN_PATTERN.split(str(value)):
        if not token:
            continue
        if token.isdigit():
            tokens.append((1, int(token), len(token), token))
        else:
            tokens.append((0, token.casefold(), token))
    return tuple(tokens)


def _run_action(callback) -> None:
    try:
        callback()
    except Exception as exc:
        _TOOL_WINDOW._show_error(exc)


def _state():
    return _TOOL_WINDOW._STATE


def _require_installed() -> None:
    if _TOOL_WINDOW is None or _JOINT_LIST is None:
        raise RuntimeError("Joint view behaviour is not installed.")
