"""Explicit production composition for the AD Skin Tool UI."""

import maya.cmds as cmds


def _install_ui(
    tool_window,
    joint_list,
    joint_view_behavior,
    global_owner_tag,
    skin_operations,
    smoothing_bind_section,
    component_section,
    mesh_context_display,
    utilities_section,
    help_dialog,
    license_dialog,
    license_controller,
    skin_weight_mode,
    mirror_ui,
    transfer_ui,
    transfer_ui_integration,
):
    """Install canonical pre-build UI hooks in one documented order."""

    for shutdown in (
        transfer_ui_integration.shutdown,
        transfer_ui.shutdown,
        mirror_ui.shutdown,
    ):
        try:
            shutdown()
        except Exception:
            pass

    tool_window.configure_context_change_callback(None)
    tool_window.configure_tool_help_callback(help_dialog.show)
    tool_window.configure_license_callback(license_dialog.show)
    skin_operations.install(tool_window)
    mesh_context_display.install(tool_window, skin_operations)
    tool_window.configure_joint_count_callback(
        mesh_context_display.refresh_listed_joint_count
    )
    tool_window.configure_context_change_callback(
        mesh_context_display.refresh_context_labels
    )
    joint_view_behavior.install(tool_window, joint_list)
    global_owner_tag.configure(
        tool_window,
        joint_list,
        joint_view_behavior.select_all_visible_joints_in_scene,
    )
    joint_list.configure_presentation_callbacks(
        render_overlay=global_owner_tag.render_joint_list_overlays,
        populate_context_menu=global_owner_tag.populate_joint_context_menu,
        sort_display_order=joint_view_behavior.sort_display_order,
    )
    smoothing_bind_section.install(tool_window, skin_operations)
    component_section.install(tool_window, skin_operations)
    mirror_ui.install(tool_window, skin_operations)
    transfer_ui.install(tool_window, skin_operations)
    transfer_ui_integration.install(transfer_ui)
    utilities_section.install(
        tool_window,
        skin_operations,
        mirror_ui,
        transfer_ui,
    )
    license_controller.configure_ui(
        tool_window=tool_window,
        skin_operations=skin_operations,
        mirror_ui=mirror_ui,
        transfer_ui=transfer_ui,
        skin_weight_mode=skin_weight_mode,
        license_dialog=license_dialog,
    )
    tool_window.configure_window(
        label="AD Skin Tool",
        width=420,
        height=720,
    )
    tool_window.configure_section_builders(
        mesh_context=mesh_context_display.build_section,
        joints=smoothing_bind_section.build_section,
        utilities=utilities_section.build_section,
    )


def _install_post_show_ui(
    tool_window,
    joint_list,
    joint_search,
    joint_drag_selection,
    skin_weight_mode,
    skin_operations,
    mesh_context_display,
    transfer_ui,
    license_controller,
):
    """Install Qt integrations that require live Maya controls."""

    joint_search.install(tool_window)
    _install_joint_label_guard(tool_window)
    joint_drag_selection.install(
        tool_window.CTRL_JOINT_LIST,
        selection_pruner=joint_search.prune_hidden_selection,
    )
    skin_weight_mode.install(tool_window, joint_list, skin_operations)
    mesh_context_display.align_visual_controls(
        skin_weight_mode,
        skin_weight_mode,
    )
    transfer_ui.install_post_show()
    license_controller.refresh_ui()
    license_controller.queue_validation_if_due()


def _install_joint_label_guard(tool_window) -> None:
    control = tool_window.CTRL_JOINT_LIST
    if cmds.treeView(control, exists=True):
        cmds.treeView(
            control,
            edit=True,
            editLabelCommand=_reject_joint_label_edit,
        )


def _reject_joint_label_edit(_item_id, _new_label):
    return ""


def show(auto_refresh=False) -> None:
    """Compose all production UI integrations and show the workspace once."""

    from ad_skin_tools.mirror import ui as mirror_ui
    from ad_skin_tools.transfer import ui as transfer_ui
    from ad_skin_tools.transfer import ui_integration as transfer_ui_integration
    from ad_skin_tools.ui import (
        component_section,
        global_owner_tag,
        help_dialog,
        joint_drag_selection,
        joint_list,
        joint_search,
        joint_view_behavior,
        mesh_context_display,
        license_controller,
        license_dialog,
        skin_operations,
        skin_weight_mode,
        smoothing_bind_section,
        tool_window,
        utilities_section,
    )

    try:
        license_controller.shutdown()
    except Exception:
        pass
    try:
        skin_weight_mode.shutdown()
    except Exception:
        pass
    try:
        joint_drag_selection.uninstall()
    except Exception:
        pass

    license_controller.install()
    license_dialog.install(license_controller)

    _install_ui(
        tool_window,
        joint_list,
        joint_view_behavior,
        global_owner_tag,
        skin_operations,
        smoothing_bind_section,
        component_section,
        mesh_context_display,
        utilities_section,
        help_dialog,
        license_dialog,
        license_controller,
        skin_weight_mode,
        mirror_ui,
        transfer_ui,
        transfer_ui_integration,
    )
    tool_window.show(auto_refresh=auto_refresh)
    _install_post_show_ui(
        tool_window,
        joint_list,
        joint_search,
        joint_drag_selection,
        skin_weight_mode,
        skin_operations,
        mesh_context_display,
        transfer_ui,
        license_controller,
    )
