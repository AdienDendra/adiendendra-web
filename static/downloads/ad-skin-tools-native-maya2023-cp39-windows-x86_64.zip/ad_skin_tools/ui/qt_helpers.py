"""Small Qt compatibility helpers shared by AD Skin Tool UI modules."""

from ad_skin_tools.ui.qt import import_qt_test, wrap_instance


def find_managing_layout(widget):
    """Return ``(container, layout, index)`` for a managed Qt widget."""

    child = widget
    parent = widget.parentWidget() if widget is not None else None
    while parent is not None:
        layout = parent.layout()
        if layout is not None:
            index = layout.indexOf(child)
            if index >= 0:
                return parent, layout, index
        child = parent
        parent = parent.parentWidget()
    return None, None, -1


def remove_named_child(container, layout, widget_type, object_name):
    """Detach and schedule deletion of one named direct/descendant widget."""

    if container is None:
        return None
    widget = container.findChild(widget_type, object_name)
    if widget is None:
        return None
    try:
        layout.removeWidget(widget)
    except Exception:
        pass
    widget.hide()
    widget.deleteLater()
    return widget


def set_checked_silently(button, checked):
    """Change a live checkable widget without emitting connected signals.

    PySide can keep a Python wrapper alive after Maya has deleted the
    underlying C++ widget. Treat that stale wrapper as unavailable so UI
    teardown can continue cleaning preview data and callbacks.
    """

    if button is None:
        return False

    try:
        previous = button.blockSignals(True)
    except RuntimeError:
        return False

    try:
        button.setChecked(bool(checked))
    except RuntimeError:
        return False
    finally:
        try:
            button.blockSignals(previous)
        except RuntimeError:
            pass

    return True
