"""Simple non-modal License window for artists using Maya."""

from __future__ import annotations

from datetime import datetime
from typing import Optional
import webbrowser

import maya.cmds as cmds

from ad_skin_tools.licensing.release import (
    BUY_URL,
    INSTALLED_VERSION,
    ReleaseAction,
    format_version,
    validate_release_action,
)
from ad_skin_tools.licensing.service import TRIAL_ACTIVE, TRIAL_EXPIRED


WINDOW_NAME = "ADSkinToolsLicenseWindow"
WINDOW_WIDTH = 340
WINDOW_HEIGHT = 420
CTRL_STATUS_TITLE = "adSkinLicenseStatusTitle"
CTRL_STATUS_MESSAGE = "adSkinLicenseStatusMessage"
CTRL_BUSY_MESSAGE = "adSkinLicenseBusyMessage"
CTRL_START_TRIAL = "adSkinLicenseStartTrial"
CTRL_KEY_FIELD = "adSkinLicenseKeyField"
CTRL_ACTIVATE = "adSkinLicenseActivate"
CTRL_RETRY = "adSkinLicenseRetry"
CTRL_DEACTIVATE = "adSkinLicenseDeactivate"
CTRL_RESET = "adSkinLicenseReset"
CTRL_BUY = "adSkinLicenseBuy"
CTRL_RELEASE_ROW = "adSkinLicenseReleaseRow"
CTRL_UPDATE = "adSkinLicenseUpdate"
CTRL_UPGRADE = "adSkinLicenseUpgrade"

_CONTROLLER = None
_UPDATE_ACTION = None  # type: Optional[ReleaseAction]
_UPGRADE_ACTION = None  # type: Optional[ReleaseAction]


def install(controller_module) -> None:
    global _CONTROLLER, _UPDATE_ACTION, _UPGRADE_ACTION
    _CONTROLLER = controller_module
    _UPDATE_ACTION = None
    _UPGRADE_ACTION = None


def configure_release_actions(
    *,
    update_action: Optional[ReleaseAction] = None,
    upgrade_action: Optional[ReleaseAction] = None,
) -> None:
    """Apply already-validated notification actions from the controller."""

    global _UPDATE_ACTION, _UPGRADE_ACTION
    _UPDATE_ACTION = (
        validate_release_action(update_action)
        if update_action is not None
        else None
    )
    _UPGRADE_ACTION = (
        validate_release_action(upgrade_action)
        if upgrade_action is not None
        else None
    )
    refresh()


def show() -> None:
    """Open or raise the License window without starting a trial."""

    _require_controller()
    if cmds.window(WINDOW_NAME, exists=True):
        cmds.showWindow(WINDOW_NAME)
        refresh()
        _CONTROLLER.queue_release_check()
        return

    window = cmds.window(
        WINDOW_NAME,
        title="AD Skin Tool - License",
        sizeable=True,
        widthHeight=(WINDOW_WIDTH, WINDOW_HEIGHT),
    )
    cmds.columnLayout(
        adjustableColumn=True,
        rowSpacing=8,
        columnAttach=("both", 12),
    )
    cmds.text(
        label="AD Skin Tools {}".format(format_version(INSTALLED_VERSION)),
        align="left",
        font="boldLabelFont",
        height=24,
    )
    cmds.separator(style="in", height=8)
    cmds.text(
        CTRL_STATUS_TITLE,
        label="License status",
        align="left",
        font="boldLabelFont",
        height=22,
    )
    cmds.text(
        CTRL_STATUS_MESSAGE,
        label="",
        align="left",
        wordWrap=True,
        height=54,
    )
    cmds.text(
        CTRL_BUSY_MESSAGE,
        label="",
        align="left",
        wordWrap=True,
        height=22,
        visible=False,
        manage=False,
    )
    cmds.button(
        CTRL_START_TRIAL,
        label="Start 48-Hour Trial",
        height=32,
        command=lambda *_: _CONTROLLER.start_trial(),
    )
    cmds.separator(style="in", height=8)
    cmds.text(label="License Key", align="left")
    cmds.textField(CTRL_KEY_FIELD, text="", height=28)
    cmds.button(
        CTRL_ACTIVATE,
        label="Activate License",
        height=32,
        command=lambda *_: _activate_entered_key(),
    )
    _button_row(
        (
            (CTRL_RETRY, "Retry Now", lambda *_: _CONTROLLER.retry()),
            (
                CTRL_DEACTIVATE,
                "Deactivate This Device",
                lambda *_: _confirm_deactivate(),
            ),
        )
    )
    cmds.button(
        CTRL_RESET,
        label="Reset Local License Data",
        height=28,
        command=lambda *_: _confirm_reset(),
        visible=False,
        manage=False,
    )
    cmds.separator(style="in", height=8)
    cmds.button(
        CTRL_BUY,
        label="Buy License",
        height=30,
        command=lambda *_: _open_url(BUY_URL),
    )
    _button_row(
        (
            (CTRL_UPDATE, "Update", lambda *_: _open_release(_UPDATE_ACTION)),
            (CTRL_UPGRADE, "Upgrade", lambda *_: _open_release(_UPGRADE_ACTION)),
        ),
        name=CTRL_RELEASE_ROW,
    )
    cmds.showWindow(window)
    cmds.window(
        window,
        edit=True,
        widthHeight=(WINDOW_WIDTH, WINDOW_HEIGHT),
    )
    refresh()
    _CONTROLLER.queue_release_check()


def refresh() -> None:
    if _CONTROLLER is None or not cmds.window(WINDOW_NAME, exists=True):
        return
    status = _CONTROLLER.status()
    busy = _CONTROLLER.is_busy()
    notice = _CONTROLLER.notice()
    message = notice or status.message
    if status.expires_at_epoch is not None:
        message = "{}\nAvailable until {} local time.".format(
            message,
            _format_local_time(status.expires_at_epoch),
        )

    cmds.text(CTRL_STATUS_TITLE, edit=True, label=status.title)
    cmds.text(CTRL_STATUS_MESSAGE, edit=True, label=message)
    _set_visible(CTRL_BUSY_MESSAGE, busy, cmds.text)
    if busy:
        cmds.text(
            CTRL_BUSY_MESSAGE,
            edit=True,
            label=_CONTROLLER.operation_label(),
        )

    trial_visible = status.can_start_trial or status.state in {
        TRIAL_ACTIVE,
        TRIAL_EXPIRED,
    }
    trial_label = "Start 48-Hour Trial"
    if status.state == TRIAL_ACTIVE:
        trial_label = "Trial Active"
    elif status.state == TRIAL_EXPIRED:
        trial_label = "48-Hour Trial Ended"
    _edit_button(
        CTRL_START_TRIAL,
        label=trial_label,
        enabled=status.can_start_trial and not busy,
        visible=trial_visible,
    )
    _edit_button(CTRL_ACTIVATE, enabled=status.can_activate and not busy)
    if cmds.textField(CTRL_KEY_FIELD, exists=True):
        cmds.textField(
            CTRL_KEY_FIELD,
            edit=True,
            enable=status.can_activate and not busy,
        )
    _edit_button(
        CTRL_RETRY,
        enabled=status.can_retry and not busy,
        visible=status.can_retry,
    )
    _edit_button(
        CTRL_DEACTIVATE,
        enabled=status.can_deactivate and not busy,
        visible=status.can_deactivate,
    )
    _edit_button(
        CTRL_RESET,
        enabled=status.can_reset and not busy,
        visible=status.can_reset,
    )
    _edit_button(
        CTRL_UPDATE,
        label=_UPDATE_ACTION.label if _UPDATE_ACTION else "Update",
        enabled=_UPDATE_ACTION is not None and not busy,
        visible=_UPDATE_ACTION is not None,
    )
    _edit_button(
        CTRL_UPGRADE,
        label=_UPGRADE_ACTION.label if _UPGRADE_ACTION else "Upgrade",
        enabled=_UPGRADE_ACTION is not None and not busy,
        visible=_UPGRADE_ACTION is not None,
    )
    _layout_release_actions()


def _activate_entered_key() -> None:
    value = cmds.textField(CTRL_KEY_FIELD, query=True, text=True)
    if _CONTROLLER.activate(value):
        cmds.textField(CTRL_KEY_FIELD, edit=True, text="")


def _confirm_deactivate() -> None:
    response = cmds.confirmDialog(
        title="Deactivate This Device",
        message=(
            "Deactivate this computer?\n\n"
            "This frees one device slot. You can activate it again later."
        ),
        button=["Deactivate", "Cancel"],
        defaultButton="Cancel",
        cancelButton="Cancel",
        dismissString="Cancel",
        icon="warning",
    )
    if response == "Deactivate":
        _CONTROLLER.deactivate()


def _confirm_reset() -> None:
    response = cmds.confirmDialog(
        title="Reset Local License Data",
        message=(
            "Reset the local license data on this computer?\n\n"
            "This does not restart or extend a trial. You will need to start "
            "or activate again."
        ),
        button=["Reset", "Cancel"],
        defaultButton="Cancel",
        cancelButton="Cancel",
        dismissString="Cancel",
        icon="warning",
    )
    if response == "Reset":
        _CONTROLLER.reset_local_state()


def _button_row(buttons, *, name=None) -> None:
    values = {"numberOfDivisions": 100, "height": 32}
    layout = (
        cmds.formLayout(name, **values)
        if name is not None
        else cmds.formLayout(**values)
    )
    count = len(buttons)
    for index, (name, label, callback) in enumerate(buttons):
        button = cmds.button(name, label=label, height=30, command=callback)
        left = int(index * 100 / count)
        right = int((index + 1) * 100 / count)
        cmds.formLayout(
            layout,
            edit=True,
            attachForm=[(button, "top", 1), (button, "bottom", 1)],
            attachPosition=[
                (button, "left", 0 if index == 0 else 2, left),
                (button, "right", 0 if index == count - 1 else 2, right),
            ],
        )
    cmds.setParent("..")


def _layout_release_actions() -> None:
    """Use the full row for one offer and split it only for two offers."""

    if not cmds.formLayout(CTRL_RELEASE_ROW, exists=True):
        return

    visible_buttons = []
    if _UPDATE_ACTION is not None:
        visible_buttons.append(CTRL_UPDATE)
    if _UPGRADE_ACTION is not None:
        visible_buttons.append(CTRL_UPGRADE)

    _set_visible(CTRL_RELEASE_ROW, bool(visible_buttons), cmds.formLayout)
    if not visible_buttons:
        return

    count = len(visible_buttons)
    positions = []
    for index, button in enumerate(visible_buttons):
        left = int(index * 100 / count)
        right = int((index + 1) * 100 / count)
        positions.extend(
            [
                (button, "left", 0 if index == 0 else 2, left),
                (button, "right", 0 if index == count - 1 else 2, right),
            ]
        )
    cmds.formLayout(
        CTRL_RELEASE_ROW,
        edit=True,
        attachPosition=positions,
    )


def _edit_button(
    control: str,
    *,
    enabled: bool,
    visible: Optional[bool] = None,
    label: Optional[str] = None,
) -> None:
    if not cmds.button(control, exists=True):
        return
    values = {"edit": True, "enable": bool(enabled)}
    if visible is not None:
        values.update({"visible": bool(visible), "manage": bool(visible)})
    if label is not None:
        values["label"] = label
    cmds.button(control, **values)


def _set_visible(control: str, visible: bool, command) -> None:
    if command(control, exists=True):
        command(
            control,
            edit=True,
            visible=bool(visible),
            manage=bool(visible),
        )


def _open_release(action: Optional[ReleaseAction]) -> None:
    if action is not None:
        _open_url(action.url)


def _open_url(url: str) -> None:
    if not webbrowser.open(url, new=2):
        cmds.confirmDialog(
            title="Open Web Page",
            message="Open this page in your browser:\n\n{}".format(url),
            button=["OK"],
        )


def _format_local_time(epoch: int) -> str:
    return datetime.fromtimestamp(epoch).astimezone().strftime("%Y-%m-%d %H:%M")


def _require_controller() -> None:
    if _CONTROLLER is None:
        raise RuntimeError("License UI is not configured.")
