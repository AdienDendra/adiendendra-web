"""Flood and Smooth UI operations."""

import builtins

import maya.cmds as cmds

from ad_skin_tools.components import flood
from ad_skin_tools.components import smooth
from ad_skin_tools.licensing import gate
from ad_skin_tools.ui import global_owner_tag
from ad_skin_tools.ui import joint_list
from ad_skin_tools.ui import smoothing_controls


CTRL_FLOOD_BUTTON = "adSkin_floodSelectedToJointButton"
CTRL_SMOOTH_BUTTON = "adSkin_smoothSelectedComponentsButton"
CTRL_COMPONENT_STATUS = "adSkin_componentOperationStatus"

_TOOL_WINDOW = None
_SKIN_OPERATIONS = None


def install(
    tool_window_module,
    skin_operations_module,
) -> None:
    global _TOOL_WINDOW, _SKIN_OPERATIONS

    _TOOL_WINDOW = tool_window_module
    _SKIN_OPERATIONS = skin_operations_module


def build_section() -> None:
    cmds.frameLayout(
        label="Component",
        collapsable=True,
        collapse=False,
        marginWidth=6,
        marginHeight=6,
    )
    cmds.columnLayout(adjustableColumn=True, rowSpacing=7)

    _SKIN_OPERATIONS._named_button_row(
        [
            (
                CTRL_FLOOD_BUTTON,
                "Flood",
                lambda *_: apply_component_flood(),
            ),
            (
                CTRL_SMOOTH_BUTTON,
                "Smooth",
                lambda *_: apply_component_smooth(),
            ),
        ],
        height=38,
    )
    cmds.text(
        CTRL_COMPONENT_STATUS,
        label="",
        align="left",
        wordWrap=True,
        visible=False,
    )

    cmds.setParent("..")
    cmds.setParent("..")


@gate.protected(gate.FLOOD)
def apply_component_flood() -> None:
    wait_cursor_active = False

    try:
        _TOOL_WINDOW._require_not_busy()
        _TOOL_WINDOW._require_loaded_mesh()
        if not _TOOL_WINDOW._STATE.get("has_skin_cluster"):
            raise RuntimeError(
                "Flood requires an existing skinCluster.\n\n"
                "Use Bind Skin first."
            )

        selected_rows = builtins.list(joint_list.selected_joint_paths())
        if not selected_rows:
            raise RuntimeError(
                "Select at least one target joint in the UI influence list."
            )

        bound = joint_list.bound_joint_paths(refresh=True)
        targets = [joint for joint in selected_rows if joint in bound]
        ignored_pending = [
            joint for joint in selected_rows if joint not in bound
        ]
        if not targets:
            raise RuntimeError(
                "No bound Flood target is selected.\n\n"
                "Select an existing bound influence. Use Add Influence for "
                "pending joints."
            )

        locked_targets = [
            joint for joint in targets if joint_list.joint_is_locked(joint)
        ]
        if locked_targets:
            raise RuntimeError(
                "Unlock the selected Flood target influence(s):\n{}".format(
                    "\n".join(locked_targets)
                )
            )

        values = smoothing_controls.query_values()
        scope = flood.collect_flood_scope(
            mesh_shape=_TOOL_WINDOW._STATE["mesh_shape"],
            mesh_transform=_TOOL_WINDOW._STATE["mesh_transform"],
        )

        if scope.whole_object:
            response = cmds.confirmDialog(
                title="Flood Bound Regions",
                message=(
                    "Flood the natural regions of {} selected bound "
                    "influence(s) on the entire loaded mesh?\n\n"
                    "Blend: {:.3f}\n"
                    "Iterations: {}\n\n"
                    "Only regions owned by the selected bound influences "
                    "will be updated. Locked influence values remain unchanged."
                ).format(
                    len(targets),
                    values.blend,
                    values.iterations,
                ),
                button=["Yes", "Cancel"],
                defaultButton="Yes",
                cancelButton="Cancel",
                dismissString="Cancel",
            )
            if response != "Yes":
                return

        mode_label = "whole-mesh regions" if scope.whole_object else "selection"
        status = "Resolving Flood ownership for {}...".format(mode_label)
        if values.iterations > 0:
            status = (
                "Resolving Flood ownership and smoothing with Blend {:.3f}, "
                "Iterations {}..."
            ).format(values.blend, values.iterations)

        _set_flood_busy(True, status)
        cmds.waitCursor(state=True)
        wait_cursor_active = True
        cmds.refresh(force=True)

        result = flood.flood_skin_weights(
            scope=scope,
            target_joints=targets,
            blend=values.blend,
            iterations=values.iterations,
            global_owner_joint=global_owner_tag.global_owner_joint(),
            ignored_pending_joints=ignored_pending,
        )

        joint_list.select_joint_paths(result.target_joints)
        flood.print_flood_report(result)

        suffixes = []
        if result.ignored_pending_joints:
            suffixes.append(
                "{} pending joint(s) ignored; use Add Influence for them."
                .format(len(result.ignored_pending_joints))
            )
        if result.skipped_empty_vertex_ids:
            suffixes.append(
                "{} empty vertex/vertices skipped.".format(
                    len(result.skipped_empty_vertex_ids)
                )
            )
        if result.skipped_locked_vertex_ids:
            suffixes.append(
                "{} fully locked vertex/vertices skipped.".format(
                    len(result.skipped_locked_vertex_ids)
                )
            )
        if result.ignored_component_count:
            suffixes.append(
                "{} other component(s) ignored.".format(
                    result.ignored_component_count
                )
            )
        suffix = " " + " ".join(suffixes) if suffixes else ""

        mode = "entire mesh" if result.whole_object else "selection"
        if result.assigned_vertex_count == 0:
            _TOOL_WINDOW._info(
                "Flood found no vertices owned by the selected target "
                "influence(s) in {}.{}".format(mode, suffix)
            )
            return

        if result.iterations == 0:
            operation = "hard Flood"
        else:
            operation = "Flood with Blend {:.3f}, Iterations {}".format(
                result.blend,
                result.iterations,
            )
        _TOOL_WINDOW._info(
            (
                "Flood complete: {} of {} assigned vertices changed in {} "
                "across {} target influence(s); {}.{}"
            ).format(
                result.flooded_vertex_count,
                result.assigned_vertex_count,
                mode,
                result.target_count,
                operation,
                suffix,
            )
        )
    except Exception as exc:
        _TOOL_WINDOW._show_error(exc)
    finally:
        if wait_cursor_active:
            try:
                cmds.waitCursor(state=False)
            except Exception:
                pass
        _set_flood_busy(False)


@gate.protected(gate.SMOOTH)
def apply_component_smooth() -> None:
    wait_cursor_active = False

    try:
        _TOOL_WINDOW._require_not_busy()
        _TOOL_WINDOW._require_loaded_mesh()
        if not _TOOL_WINDOW._STATE.get("has_skin_cluster"):
            raise RuntimeError(
                "Component Smooth requires an existing skinCluster.\n\n"
                "Use Bind Skin first."
            )

        values = smoothing_controls.query_values()
        if values.iterations < 1:
            raise RuntimeError(
                "Component Smooth requires Iterations 1 or higher."
            )

        scope = smooth.collect_smooth_scope(
            mesh_shape=_TOOL_WINDOW._STATE["mesh_shape"],
            mesh_transform=_TOOL_WINDOW._STATE["mesh_transform"],
        )

        if scope.whole_object:
            response = cmds.confirmDialog(
                title="Smooth Entire Mesh",
                message=(
                    "Smooth all current skin weights on the loaded mesh?\n\n"
                    "Blend: {:.3f}\n"
                    "Iterations: {}\n"
                    "Locked influences will remain unchanged."
                ).format(values.blend, values.iterations),
                button=["Yes", "Cancel"],
                defaultButton="Yes",
                cancelButton="Cancel",
                dismissString="Cancel",
            )
            if response != "Yes":
                return

        _set_smooth_busy(
            True,
            "Smoothing selected skin weights...",
        )
        cmds.waitCursor(state=True)
        wait_cursor_active = True
        cmds.refresh(force=True)

        result = smooth.smooth_skin_weights(
            scope=scope,
            blend=values.blend,
            iterations=values.iterations,
        )

        smooth.print_component_smooth_report(result)

        mode = "entire mesh" if result.whole_object else "selection"
        suffixes = []
        if result.skipped_empty_vertex_ids:
            suffixes.append(
                "{} empty vertex/vertices skipped.".format(
                    len(result.skipped_empty_vertex_ids)
                )
            )
        if result.skipped_locked_vertex_ids:
            suffixes.append(
                "{} fully locked vertex/vertices skipped.".format(
                    len(result.skipped_locked_vertex_ids)
                )
            )
        suffix = " " + " ".join(suffixes) if suffixes else ""

        _TOOL_WINDOW._info(
            (
                "Smooth complete: {} of {} vertices changed in {}. "
                "Blend {:.3f}, Iterations {}.{}"
            ).format(
                result.smoothed_vertex_count,
                result.selected_vertex_count,
                mode,
                result.blend,
                result.iterations,
                suffix,
            )
        )
    except Exception as exc:
        _TOOL_WINDOW._show_error(exc)
    finally:
        if wait_cursor_active:
            try:
                cmds.waitCursor(state=False)
            except Exception:
                pass
        _set_smooth_busy(False)


def _set_flood_busy(busy: bool, status: str = "") -> None:
    _set_component_busy(
        busy=busy,
        active_control=CTRL_FLOOD_BUTTON,
        active_label="Flooding..." if busy else "Flood",
        status=status,
    )


def _set_smooth_busy(busy: bool, status: str = "") -> None:
    _set_component_busy(
        busy=busy,
        active_control=CTRL_SMOOTH_BUTTON,
        active_label="Smoothing..." if busy else "Smooth",
        status=status,
    )


def _set_component_busy(
    busy: bool,
    active_control: str,
    active_label: str,
    status: str,
) -> None:
    if _TOOL_WINDOW is None:
        return
    _SKIN_OPERATIONS._set_common_enabled(not busy)
    _TOOL_WINDOW._STATE["busy"] = bool(busy)

    if cmds.button(active_control, exists=True):
        cmds.button(
            active_control,
            edit=True,
            enable=not busy,
            label=active_label,
        )

    if cmds.text(CTRL_COMPONENT_STATUS, exists=True):
        cmds.text(
            CTRL_COMPONENT_STATUS,
            edit=True,
            label=status if busy else "",
            visible=bool(busy),
        )

    try:
        cmds.refresh(force=True)
    except Exception:
        pass


def show_help() -> None:
    cmds.confirmDialog(
        title="AD Skin Tool",
        message=(
            "Shared Smoothing\n"
            "Blend and Iterations are shared by Bind Skin, Add Influence, Flood, "
            "and Smooth. Blend controls how far each positive iteration moves "
            "weights toward the connected-neighbour average. Iterations is the "
            "exact number of repetitions, with no hidden multiplier. Iterations 0 "
            "keeps Bind Skin, Add Influence, and Flood in hard mode. Smooth requires "
            "at least 1 iteration.\n\n"
            "Flood\n"
            "Select one or more existing bound influences in the list. Pending "
            "joints are ignored when at least one bound influence is selected; use "
            "Add Influence to bind pending joints. With the loaded mesh object "
            "selected, Flood updates only the natural regions owned by the selected "
            "bound influences. With vertices, edges, or faces selected, one target "
            "claims the full selected scope, while multiple targets divide that "
            "scope through Region ownership. Soft Selection blends the initial "
            "Flood and scales smoothing movement through the falloff. Locked target "
            "influences must be unlocked; other locked influence values remain "
            "unchanged.\n\n"
            "Smooth\n"
            "Soft Selection multiplies Blend per vertex, so the hard selected area "
            "receives the full Blend value and the falloff area receives less. Select "
            "the loaded mesh object to smooth the entire mesh. Locked influence "
            "values remain unchanged."
        ),
        button=["OK"],
    )
