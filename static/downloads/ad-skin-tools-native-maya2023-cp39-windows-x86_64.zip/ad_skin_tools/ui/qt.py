"""Canonical PySide and Shiboken compatibility boundary."""


def import_qt_modules():
    """Return the available Qt modules and their PySide binding name."""

    try:
        from PySide6 import QtWidgets, QtGui, QtCore
        return QtWidgets, QtGui, QtCore, "PySide6"
    except ImportError:
        pass

    try:
        from PySide2 import QtWidgets, QtGui, QtCore
        return QtWidgets, QtGui, QtCore, "PySide2"
    except ImportError as exc:
        raise RuntimeError(
            "Could not import PySide6 or PySide2 from Maya Python."
        ) from exc


def wrap_instance(pointer, base_class, binding_name):
    """Wrap a Maya UI pointer with the active PySide binding."""

    if not pointer:
        return None
    if binding_name == "PySide6":
        from shiboken6 import wrapInstance
    else:
        from shiboken2 import wrapInstance
    return wrapInstance(int(pointer), base_class)


def import_qt_test(binding_name):
    """Return the QtTest module matching the active PySide binding."""

    if binding_name == "PySide6":
        from PySide6 import QtTest
    else:
        from PySide2 import QtTest
    return QtTest
