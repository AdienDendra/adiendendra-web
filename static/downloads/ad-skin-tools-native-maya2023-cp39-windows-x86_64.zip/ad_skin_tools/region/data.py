"""Platform-neutral data contracts for Region ownership solving."""

from dataclasses import dataclass
from typing import Mapping, Tuple

import numpy as np


@dataclass(frozen=True)
class MeshOwnershipContext:
    """Immutable scene snapshot consumed by Region algorithms."""

    mesh_shape: str
    mesh_transform: str
    influences: Tuple[str, ...]
    influence_uuids: Tuple[str, ...]
    vertex_positions: np.ndarray
    influence_positions: np.ndarray
    adjacency: Tuple[Tuple[int, ...], ...]
    face_count: int
    edge_count: int
    scene_capture_seconds: float
    adjacency_seconds: float
    elapsed_seconds: float

    @property
    def vertex_count(self) -> int:
        return int(self.vertex_positions.shape[0])

    @property
    def influence_count(self) -> int:
        return int(self.influence_positions.shape[0])


@dataclass(frozen=True)
class SecondarySurfaceCapture:
    """Maya face data required by the secondary-surface solver."""

    anchor_vertex_ids: Tuple[int, ...]
    incident_face_ids: Mapping[int, Tuple[int, ...]]
    queried_face_ids: Tuple[int, ...]
    face_normals: Mapping[int, np.ndarray]
    anchor_query_seconds: float
    normal_query_seconds: float


@dataclass(frozen=True)
class ClosedLoopCapture:
    """Maya edge-loop queries consumed by closed-loop consensus."""

    discovered_loops: Tuple[
        Tuple[int, Tuple[int, ...], Tuple[int, ...]],
        ...,
    ]
    boundary_edge_ids: Tuple[int, ...]
    unresolved_seed_edge_ids: Tuple[int, ...]
    open_loop_seed_edge_ids: Tuple[int, ...]
    edge_scan_seconds: float
    loop_query_seconds: float
    maya_polyselect_call_count: int
