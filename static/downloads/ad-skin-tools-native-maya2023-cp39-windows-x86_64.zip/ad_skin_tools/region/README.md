# Region Ownership Pipeline

This package owns the production blocking architecture used by **Bind Skin**, **Add Influence**, and Region-based **Flood** workflows.

1. `mesh_context.py`
   - captures mesh positions, joint pivots, and vertex adjacency once
2. `exact_distance_ties.py`
   - resolves exact closest-distance ties deterministically
3. `closest_region_ownership.py`
   - assigns the closest joint
   - builds connected owner regions
   - separates primary and secondary regions
4. `secondary_surface_facing.py`
   - queries secondary-region anchor vertices
   - protects co-primary and ambiguous secondary regions
   - classifies detached secondary regions
5. `unique_boundary_assignment.py`
   - inspects detached secondary regions only
   - reassigns the whole connected region when exactly one raw external owner touches it
   - when several raw owners touch it, requires every region vertex to agree on one unique second-closest influence that also touches the boundary
   - preserves zero-contact regions, exact runner-up ties, and regions whose vertices disagree
6. `global_owner_assignment.py`
   - applies an explicitly tagged Global Owner after local Region assignment
   - preserves local assignment when no Global Owner is tagged
7. `closed_loop_ownership.py`
   - scans mesh edges once
   - discovers loops only from ownership-boundary edges
   - applies two-owner aggregate-distance consensus
   - preserves supported opposite pairs
   - preserves exact ties, multi-owner loops, and conflicting proposals
8. `ownership_pipeline.py`
   - produces one final hard-owner map without writing skin weights

The local detached-region rule uses only mesh connectivity, the immutable raw
closest-owner map, exact point-to-joint distances, and the existing surface-facing
result. It does not use joint hierarchy, names, orientation, bone segments,
thresholds, majority voting, or anatomical grouping.

`core/smoothed_automatic_bind.py` consumes the final owner map, optionally runs
the shared smoothing solver, creates one skinCluster, and writes one final weight
matrix.
