"""Production ownership pipeline for Bind Skin and Add Influence."""

from ad_skin_tools.region.closest_region_ownership import (
    DEFAULT_DISTANCE_CHUNK_SIZE,
    ClosestRegionOwnershipResult,
    solve_closest_region_ownership,
    solve_closest_region_ownership_from_context,
)
from ad_skin_tools.region.closed_loop_ownership import (
    ClosedLoopOwnershipResult,
    resolve_closed_loop_ownership,
    resolve_closed_loop_ownership_from_capture,
)
from ad_skin_tools.region.data import (
    ClosedLoopCapture,
    MeshOwnershipContext,
    SecondarySurfaceCapture,
)
from ad_skin_tools.region.global_owner_assignment import (
    GlobalOwnerAssignmentResult,
    assign_detached_to_global_owner,
)
from ad_skin_tools.region.ownership_pipeline import (
    OwnershipPipelineResult,
    solve_ownership_pipeline,
)
from ad_skin_tools.region.secondary_surface_facing import (
    SecondarySurfaceFacingResult,
    classify_secondary_surface_facing,
    classify_secondary_surface_facing_from_capture,
    secondary_surface_anchor_vertex_ids,
)
from ad_skin_tools.region.unique_boundary_assignment import (
    UniqueBoundaryAssignmentResult,
    UniqueBoundaryRegionAssignment,
    assign_detached_to_unique_boundary,
)


__all__ = [
    "DEFAULT_DISTANCE_CHUNK_SIZE",
    "ClosestRegionOwnershipResult",
    "ClosedLoopCapture",
    "ClosedLoopOwnershipResult",
    "GlobalOwnerAssignmentResult",
    "MeshOwnershipContext",
    "OwnershipPipelineResult",
    "SecondarySurfaceCapture",
    "SecondarySurfaceFacingResult",
    "UniqueBoundaryAssignmentResult",
    "UniqueBoundaryRegionAssignment",
    "assign_detached_to_global_owner",
    "assign_detached_to_unique_boundary",
    "classify_secondary_surface_facing",
    "classify_secondary_surface_facing_from_capture",
    "resolve_closed_loop_ownership",
    "resolve_closed_loop_ownership_from_capture",
    "secondary_surface_anchor_vertex_ids",
    "solve_closest_region_ownership",
    "solve_closest_region_ownership_from_context",
    "solve_ownership_pipeline",
]
