"""Compatibility facade for the Maya Region scene-capture adapter."""

from typing import Sequence

from ad_skin_tools.region.data import MeshOwnershipContext


def build_mesh_ownership_context(
    mesh: str,
    joints: Sequence[str],
) -> MeshOwnershipContext:
    """Capture positions and adjacency through the canonical Maya adapter."""

    from ad_skin_tools.maya.region_capture import (
        build_mesh_ownership_context as capture_context,
    )

    return capture_context(mesh=mesh, joints=joints)
