"""UI command boundary for production automatic surface binding."""

from typing import Optional, Sequence

from ad_skin_tools.core.smoothed_automatic_bind import (
    AutomaticSurfaceBindOptions,
    AutomaticSurfaceBindResult,
    bind_object_automatic_surface as _bind_object_automatic_surface,
    print_automatic_surface_report,
)


def bind_object_automatic_surface(
    mesh: str,
    joints: Sequence[str],
    options: Optional[AutomaticSurfaceBindOptions] = None,
) -> AutomaticSurfaceBindResult:
    """Bind one unskinned mesh using final ownership and optional smoothing."""

    return _bind_object_automatic_surface(
        mesh=mesh,
        joints=joints,
        options=options,
    )


def print_report(result: AutomaticSurfaceBindResult) -> None:
    """Print the concise production Bind Skin summary."""

    print_automatic_surface_report(result)
