"""Undoable skin-weight matrix writes for Maya."""

import os
import tempfile

import maya.api.OpenMaya as om
import maya.cmds as cmds

from ad_skin_tools.core.compat import ensure_numpy
from ad_skin_tools.core.skin_cluster import SkinClusterAdapter
from ad_skin_tools.core.weight_contract import (
    WEIGHT_MATERIAL_TOLERANCE,
    prepare_weights_for_write,
    validate_stored_weight_rows,
    writable_influence_columns,
)


np = ensure_numpy()
COMMAND_NAME = "adSkinSetWeightMatrixAtomic"


def maya_useNewAPI():
    pass


def apply_undoable_weights(
    skin_cluster,
    mesh_shape,
    vertex_ids,
    before_weights,
    after_weights,
    locked_columns=(),
    enforce_write_contract=False,
    operation_name="Skin weight operation",
):
    """Write one skin-weight matrix through Maya's undo queue."""

    vertex_ids = np.asarray(vertex_ids, dtype=np.int32)
    before_weights = np.asarray(before_weights, dtype=np.float64)
    after_weights = np.asarray(after_weights, dtype=np.float64)

    if before_weights.shape != after_weights.shape:
        raise RuntimeError("Undoable weight matrices do not have matching shapes.")
    if before_weights.ndim != 2:
        raise RuntimeError("Undoable weight matrices must be two-dimensional.")
    if before_weights.shape[0] != vertex_ids.size:
        raise RuntimeError("Undoable weight row count does not match vertex count.")

    locked_columns = np.asarray(tuple(locked_columns), dtype=np.int32)

    _ensure_plugin_loaded()

    descriptor, payload_path = tempfile.mkstemp(
        prefix="ad_skin_weights_",
        suffix=".npz",
    )
    os.close(descriptor)

    try:
        np.savez_compressed(
            payload_path,
            skin_cluster=np.asarray(str(skin_cluster)),
            mesh_shape=np.asarray(str(mesh_shape)),
            vertex_ids=vertex_ids,
            before_weights=before_weights,
            after_weights=after_weights,
            locked_columns=locked_columns,
            enforce_write_contract=np.asarray(bool(enforce_write_contract)),
            operation_name=np.asarray(str(operation_name)),
        )
        getattr(cmds, COMMAND_NAME)(payload_path)
    finally:
        try:
            if os.path.exists(payload_path):
                os.remove(payload_path)
        except Exception:
            pass


def _ensure_plugin_loaded():
    plugin_path = os.path.abspath(__file__)
    plugin_name = os.path.splitext(os.path.basename(plugin_path))[0]

    try:
        loaded = bool(
            cmds.pluginInfo(
                plugin_name,
                query=True,
                loaded=True,
            )
        )
    except Exception:
        loaded = False

    if loaded and not _command_exists():
        raise RuntimeError(
            "The previous AD Skin Tool weight command is still loaded. "
            "Restart Maya before testing the updated weight command."
        )
    if not loaded:
        cmds.loadPlugin(plugin_path, quiet=True)


def _command_exists():
    return hasattr(cmds, COMMAND_NAME)


class _SetWeightMatrixCommand(om.MPxCommand):
    def __init__(self):
        super(_SetWeightMatrixCommand, self).__init__()
        self._skin_cluster = None
        self._mesh_shape = None
        self._vertex_ids = None
        self._before_weights = None
        self._after_weights = None
        self._locked_columns = np.empty(0, dtype=np.int32)
        self._enforce_write_contract = False
        self._operation_name = "Skin weight operation"
        self._initial_write_complete = False

    @staticmethod
    def creator():
        return _SetWeightMatrixCommand()

    def doIt(self, args):
        try:
            payload_path = args.asString(0)
        except (IndexError, RuntimeError, TypeError) as exc:
            raise RuntimeError(
                "{} requires one weight payload path.\n\n{}".format(
                    COMMAND_NAME,
                    exc,
                )
            )

        with np.load(payload_path, allow_pickle=False) as payload:
            self._skin_cluster = str(payload["skin_cluster"].item())
            self._mesh_shape = str(payload["mesh_shape"].item())
            self._vertex_ids = np.asarray(
                payload["vertex_ids"],
                dtype=np.int32,
            ).copy()
            self._before_weights = np.asarray(
                payload["before_weights"],
                dtype=np.float64,
            ).copy()
            self._after_weights = np.asarray(
                payload["after_weights"],
                dtype=np.float64,
            ).copy()
            if "locked_columns" in payload:
                self._locked_columns = np.asarray(
                    payload["locked_columns"],
                    dtype=np.int32,
                ).copy()
            if "enforce_write_contract" in payload:
                self._enforce_write_contract = bool(
                    payload["enforce_write_contract"].item()
                )
            if "operation_name" in payload:
                self._operation_name = str(
                    payload["operation_name"].item()
                )

        self.redoIt()

    def redoIt(self):
        if self._initial_write_complete or not self._enforce_write_contract:
            self._write_command_weights(self._after_weights)
            self._initial_write_complete = True
            return

        self._write_with_contract()
        self._initial_write_complete = True

    def undoIt(self):
        self._write_command_weights(self._before_weights)

    def isUndoable(self):
        return True

    def _write(self, weights, influence_columns=None):
        adapter = SkinClusterAdapter(
            skin_cluster=self._skin_cluster,
            mesh_shape=self._mesh_shape,
        )
        matrix = np.asarray(weights, dtype=np.float64)
        if influence_columns is not None:
            columns = np.asarray(influence_columns, dtype=np.int32)
            matrix = matrix[:, columns]
        adapter.set_weights(
            self._vertex_ids,
            matrix,
            normalize=False,
            influence_indices=influence_columns,
        )

    def _write_command_weights(self, weights):
        if not self._enforce_write_contract:
            self._write(weights)
            return
        columns = self._writable_columns(weights)
        if columns.size:
            self._write(weights, columns)

    def _writable_columns(self, weights):
        influence_count = int(np.asarray(weights).shape[1])
        return writable_influence_columns(
            influence_count,
            self._locked_columns,
        )

    def _write_with_contract(self):
        adapter = SkinClusterAdapter(
            skin_cluster=self._skin_cluster,
            mesh_shape=self._mesh_shape,
        )
        normalize_mode = int(
            cmds.getAttr(self._skin_cluster + ".normalizeWeights")
        )
        maintain_maximum = bool(
            cmds.getAttr(self._skin_cluster + ".maintainMaxInfluences")
        )
        maximum = int(
            cmds.getAttr(self._skin_cluster + ".maxInfluences")
        )
        settings = (
            "normalizeWeights={}, maintainMaxInfluences={}, "
            "maxInfluences={}".format(
                normalize_mode,
                maintain_maximum,
                maximum,
            )
        )
        candidate = prepare_weights_for_write(
            self._after_weights,
            locked_columns=self._locked_columns,
            normalize_rows=normalize_mode != 0,
            maintain_max_influences=maintain_maximum,
            max_influences=maximum,
            label=self._operation_name,
        )

        write_attempted = False
        try:
            write_attempted = True
            self._write_command_weights(candidate)
            actual = np.asarray(
                adapter.get_weights(self._vertex_ids).weights,
                dtype=np.float64,
            )
            validate_stored_weight_rows(
                actual_weights=actual,
                expected_weights=candidate,
                vertex_ids=self._vertex_ids,
                locked_columns=self._locked_columns,
                require_normalized=normalize_mode != 0,
                maintain_max_influences=maintain_maximum,
                max_influences=maximum,
                label=self._operation_name,
                settings_description=settings,
            )
        except Exception as exc:
            if not write_attempted:
                raise
            try:
                self._restore_before_weights(adapter)
            except Exception as rollback_exc:
                raise RuntimeError(
                    "{}\n{} rollback also failed: {}".format(
                        exc,
                        self._operation_name,
                        rollback_exc,
                    )
                )
            raise

        # Redo must reproduce what Maya accepted, not an idealized candidate.
        self._after_weights = actual.copy()

    def _restore_before_weights(self, adapter):
        self._write_command_weights(self._before_weights)
        restored = np.asarray(
            adapter.get_weights(self._vertex_ids).weights,
            dtype=np.float64,
        )
        if restored.shape != self._before_weights.shape:
            raise RuntimeError("restored weight shape is inconsistent")
        difference = np.abs(restored - self._before_weights)
        if difference.size and float(np.max(difference)) > WEIGHT_MATERIAL_TOLERANCE:
            raise RuntimeError(
                "restored weights differ from the original by {:.12g}".format(
                    float(np.max(difference))
                )
            )


def initializePlugin(plugin_object):
    plugin = om.MFnPlugin(
        plugin_object,
        "AD Skin Tool",
        "1.1.0",
        "Any",
    )
    plugin.registerCommand(
        COMMAND_NAME,
        _SetWeightMatrixCommand.creator,
    )


def uninitializePlugin(plugin_object):
    plugin = om.MFnPlugin(plugin_object)
    plugin.deregisterCommand(COMMAND_NAME)
