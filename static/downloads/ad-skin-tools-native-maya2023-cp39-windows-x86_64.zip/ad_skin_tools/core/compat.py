import sys

import maya.cmds as cmds
import maya.api.OpenMaya as om

from ad_skin_tools.runtime.compatibility import ensure_numpy
from ad_skin_tools.runtime.environment import (
    maya_api_version,
    maya_version,
    python_version_tuple,
)
from ad_skin_tools.runtime.platform import machine_architecture, operating_system
from ad_skin_tools.ui.qt import import_qt_modules


def get_rich_selection_list(default_to_active=True):
    """
    API-safe rich selection reader.

    Maya API 2.0 returns MRichSelection directly in newer signatures.
    Some versions/signatures differ, so we try a few safe options.
    """
    try:
        rich_selection = om.MGlobal.getRichSelection(default_to_active)
        return rich_selection.getSelection()

    except TypeError:
        pass

    try:
        rich_selection = om.MGlobal.getRichSelection()
        return rich_selection.getSelection()

    except Exception:
        return om.MGlobal.getActiveSelectionList()


def environment_report() -> str:
    """
    Useful for debugging user machines.
    """
    qt_name = "Not checked"
    qt_version = "Not checked"

    try:
        _, _, qt_core, qt_name = import_qt_modules()
        qt_version = qt_core.qVersion()
    except Exception:
        qt_name = "Unavailable"
        qt_version = "Unavailable"

    np_version = "Unavailable"

    try:
        np = ensure_numpy()
        np_version = np.__version__
    except Exception:
        pass

    return (
        f"Maya: {cmds.about(version=True)}\n"
        f"Maya API: {maya_api_version()}\n"
        f"Python: {sys.version}\n"
        f"Qt: {qt_name} {qt_version}\n"
        f"NumPy: {np_version}\n"
        f"OS: {operating_system()}\n"
        f"Architecture: {machine_architecture()}"
    )
