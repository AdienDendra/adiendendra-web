"""Deterministic input and write contracts for skin-weight matrices."""

from typing import Optional, Sequence

import numpy as np


WEIGHT_MATERIAL_TOLERANCE = 1.0e-6


def writable_influence_columns(influence_count, locked_columns=()):
    """Return physical influence columns that a locked write may modify."""

    locked_mask = _locked_column_mask(locked_columns, int(influence_count))
    return np.where(~locked_mask)[0].astype(np.int32)


def canonicalize_existing_weights(
    weights,
    row_ids: Optional[Sequence[int]] = None,
    influence_names: Optional[Sequence[str]] = None,
    label: str = "Existing skin weights",
    tolerance: float = WEIGHT_MATERIAL_TOLERANCE,
):
    """Return a working copy with negative numerical dust set to zero.

    Positive values are not redistributed here. Row normalization belongs to
    the write boundary, where lock and skinCluster settings are available.
    """

    matrix = _validated_matrix(weights, label)
    tolerance = _validated_tolerance(tolerance)
    rows = _validated_row_ids(row_ids, matrix.shape[0])
    names = _validated_influence_names(influence_names, matrix.shape[1])

    material = np.argwhere(matrix < -tolerance)
    if material.size:
        row, column = material[0]
        raise RuntimeError(
            "{} contain a material negative weight at vertex {}, "
            "influence {}: {:.17g}.".format(
                label,
                int(rows[int(row)]),
                names[int(column)],
                float(matrix[int(row), int(column)]),
            )
        )

    result = matrix.copy()
    result[result < 0.0] = 0.0
    return result


def prepare_weights_for_write(
    weights,
    locked_columns: Sequence[int] = (),
    normalize_rows: bool = True,
    maintain_max_influences: bool = False,
    max_influences: int = 0,
    label: str = "Skin weights",
    tolerance: float = WEIGHT_MATERIAL_TOLERANCE,
):
    """Return deterministic rows that respect lock and skinCluster policy."""

    result = canonicalize_existing_weights(
        weights,
        label=label,
        tolerance=tolerance,
    )
    locked_mask = _locked_column_mask(locked_columns, result.shape[1])
    max_influences = int(max_influences)

    if maintain_max_influences:
        if max_influences < 1:
            raise RuntimeError(
                "{} require maxInfluences to be at least 1.".format(label)
            )
        _prune_to_maximum(
            result,
            locked_mask,
            max_influences,
            label,
        )

    if normalize_rows:
        _normalize_rows_preserving_locks(
            result,
            locked_mask,
            label,
            _validated_tolerance(tolerance),
        )

    if not np.all(np.isfinite(result)):
        raise RuntimeError(
            "Prepared {} contain non-finite values.".format(label)
        )

    return result


def validate_stored_weight_rows(
    actual_weights,
    expected_weights,
    vertex_ids: Optional[Sequence[int]] = None,
    locked_columns: Sequence[int] = (),
    require_normalized: bool = True,
    maintain_max_influences: bool = False,
    max_influences: int = 0,
    label: str = "Skin weights",
    settings_description: str = "",
    tolerance: float = WEIGHT_MATERIAL_TOLERANCE,
):
    """Validate material behavior while accepting harmless Maya rounding."""

    actual = np.asarray(actual_weights, dtype=np.float64)
    expected = _validated_matrix(expected_weights, "Expected {}".format(label))
    tolerance = _validated_tolerance(tolerance)
    if actual.ndim != 2 or actual.shape[1] < 1:
        raise RuntimeError(
            "Stored {} must be a two-dimensional matrix.{}".format(
                label,
                _settings_suffix(settings_description),
            )
        )
    if actual.shape != expected.shape:
        raise RuntimeError(
            "Stored {} shape differs from the calculated weights: {} != {}.{}"
            .format(
                label,
                actual.shape,
                expected.shape,
                _settings_suffix(settings_description),
            )
        )

    rows = _validated_row_ids(vertex_ids, actual.shape[0])
    locked_mask = _locked_column_mask(locked_columns, actual.shape[1])
    non_finite_rows = np.where(~np.all(np.isfinite(actual), axis=1))[0]
    if non_finite_rows.size:
        first_row = int(non_finite_rows[0])
        bad_columns = np.where(~np.isfinite(actual[first_row]))[0]
        raise RuntimeError(
            "Stored {} contain non-finite values. First vertex IDs: {}. "
            "First non-finite influence columns: {}. {}.{}".format(
                label,
                rows[non_finite_rows[:20]].tolist(),
                bad_columns[:20].tolist(),
                _row_diagnostics(
                    expected,
                    actual,
                    first_row,
                    locked_mask,
                ),
                _settings_suffix(settings_description),
            )
        )
    material_negative = np.where(
        np.any(actual < -tolerance, axis=1)
    )[0]
    if material_negative.size:
        raise RuntimeError(
            "Stored {} contain material negative weights. First vertex IDs: "
            "{}.{}".format(
                label,
                rows[material_negative[:20]].tolist(),
                _settings_suffix(settings_description),
            )
        )

    if require_normalized:
        row_sums = np.sum(actual, axis=1, dtype=np.float64)
        bad_rows = np.where(np.abs(row_sums - 1.0) > tolerance)[0]
        if bad_rows.size:
            raise RuntimeError(
                "Stored {} are not normalized. First vertex IDs: {}. "
                "First row sums: {}.{}".format(
                    label,
                    rows[bad_rows[:20]].tolist(),
                    row_sums[bad_rows[:20]].tolist(),
                    _settings_suffix(settings_description),
                )
            )

    if locked_mask.any():
        locked_difference = np.abs(
            actual[:, locked_mask] - expected[:, locked_mask]
        )
        bad_locked_rows = np.where(
            np.any(locked_difference > tolerance, axis=1)
        )[0]
        if bad_locked_rows.size:
            first_row = int(bad_locked_rows[0])
            raise RuntimeError(
                "Stored {} materially changed locked influences. Maximum "
                "locked difference: {:.12g}. First vertex IDs: {}. {}.{}"
                .format(
                    label,
                    float(np.max(locked_difference)),
                    rows[bad_locked_rows[:20]].tolist(),
                    _row_diagnostics(
                        expected,
                        actual,
                        first_row,
                        locked_mask,
                    ),
                    _settings_suffix(settings_description),
                )
            )

    if maintain_max_influences:
        active_counts = np.count_nonzero(actual > tolerance, axis=1)
        bad_rows = np.where(active_counts > int(max_influences))[0]
        if bad_rows.size:
            raise RuntimeError(
                "Stored {} exceed maxInfluences. First vertex IDs: {}. "
                "First active counts: {}.{}".format(
                    label,
                    rows[bad_rows[:20]].tolist(),
                    active_counts[bad_rows[:20]].tolist(),
                    _settings_suffix(settings_description),
                )
            )

    differences = np.abs(actual - expected)
    bad_rows = np.where(np.any(differences > tolerance, axis=1))[0]
    if bad_rows.size:
        worst_flat = int(np.argmax(differences))
        worst_row, worst_column = np.unravel_index(
            worst_flat,
            differences.shape,
        )
        raise RuntimeError(
            "Stored {} materially differ from the calculated weights. "
            "Maximum difference: {:.12g} at vertex {}, influence column {}. "
            "First vertex IDs: {}. {}.{}".format(
                label,
                float(differences[worst_row, worst_column]),
                int(rows[worst_row]),
                int(worst_column),
                rows[bad_rows[:20]].tolist(),
                _row_diagnostics(
                    expected,
                    actual,
                    int(worst_row),
                    locked_mask,
                ),
                _settings_suffix(settings_description),
            )
        )

    return actual


def _normalize_rows_preserving_locks(
    matrix,
    locked_mask,
    label,
    tolerance,
):
    unlocked_mask = ~locked_mask
    locked_mass = np.sum(matrix[:, locked_mask], axis=1, dtype=np.float64)
    excessive = np.where(locked_mass > 1.0 + tolerance)[0]
    if excessive.size:
        raise RuntimeError(
            "{} have locked weight mass greater than 1.0. First rows: {}."
            .format(label, excessive[:20].tolist())
        )

    unlocked_mass = np.sum(
        matrix[:, unlocked_mask],
        axis=1,
        dtype=np.float64,
    )
    available = np.maximum(0.0, 1.0 - locked_mass)
    missing = np.where(
        (available > tolerance) & (unlocked_mass <= tolerance)
    )[0]
    if missing.size:
        raise RuntimeError(
            "{} cannot fill the normalized unlocked weight mass. First rows: "
            "{}.".format(label, missing[:20].tolist())
        )

    scalable = (available > tolerance) & (unlocked_mass > tolerance)
    if np.any(scalable):
        matrix[np.ix_(scalable, unlocked_mask)] *= (
            available[scalable] / unlocked_mass[scalable]
        )[:, np.newaxis]
    matrix[np.ix_(~scalable, unlocked_mask)] = 0.0


def _prune_to_maximum(matrix, locked_mask, maximum, label):
    unlocked_columns = np.where(~locked_mask)[0]
    locked_columns = np.where(locked_mask)[0]

    for row_index in range(matrix.shape[0]):
        row = matrix[row_index]
        locked_active = locked_columns[row[locked_columns] > 0.0]
        if locked_active.size > maximum:
            raise RuntimeError(
                "{} row {} has {} locked influences, exceeding "
                "maxInfluences {}.".format(
                    label,
                    row_index,
                    int(locked_active.size),
                    maximum,
                )
            )

        slots = maximum - int(locked_active.size)
        positive = unlocked_columns[row[unlocked_columns] > 0.0]
        if positive.size <= slots:
            continue
        order = np.lexsort((positive, -row[positive]))
        keep = positive[order[:slots]]
        keep_mask = np.zeros(row.size, dtype=bool)
        keep_mask[keep] = True
        row[unlocked_columns[~keep_mask[unlocked_columns]]] = 0.0


def _validated_matrix(weights, label):
    matrix = np.asarray(weights, dtype=np.float64)
    if matrix.ndim != 2 or matrix.shape[1] < 1:
        raise RuntimeError("{} must be a two-dimensional matrix.".format(label))
    if not np.all(np.isfinite(matrix)):
        raise RuntimeError("{} contain non-finite values.".format(label))
    return matrix


def _locked_column_mask(values, influence_count):
    columns = np.asarray(tuple(values), dtype=np.int32)
    if columns.ndim != 1:
        raise RuntimeError("Locked influence columns must be one-dimensional.")
    if columns.size and (
        np.any(columns < 0)
        or np.any(columns >= int(influence_count))
        or np.unique(columns).size != columns.size
    ):
        raise RuntimeError("Locked influence columns are invalid.")
    result = np.zeros(int(influence_count), dtype=bool)
    result[columns] = True
    return result


def _validated_row_ids(values, row_count):
    if values is None:
        return np.arange(int(row_count), dtype=np.int64)
    rows = np.asarray(tuple(values), dtype=np.int64)
    if rows.shape != (int(row_count),):
        raise RuntimeError("Weight row ID mapping is inconsistent.")
    return rows


def _validated_influence_names(values, influence_count):
    if values is None:
        return tuple(
            "column {}".format(index)
            for index in range(int(influence_count))
        )
    names = tuple(str(value) for value in values)
    if len(names) != int(influence_count):
        raise RuntimeError("Weight influence name mapping is inconsistent.")
    return names


def _validated_tolerance(value):
    tolerance = float(value)
    if not np.isfinite(tolerance) or tolerance <= 0.0:
        raise RuntimeError("Weight tolerance must be finite and positive.")
    return tolerance


def _settings_suffix(description):
    return " Settings: {}".format(description) if description else ""


def _row_diagnostics(expected, actual, row_index, locked_mask):
    expected_row = expected[int(row_index)]
    actual_row = actual[int(row_index)]
    unlocked_mask = ~locked_mask
    return (
        "Expected/actual row sums: {:.12g}/{:.12g}; active influences: "
        "{}/{}; locked mass: {:.12g}/{:.12g}; unlocked mass: "
        "{:.12g}/{:.12g}".format(
            float(np.sum(expected_row, dtype=np.float64)),
            float(np.sum(actual_row, dtype=np.float64)),
            int(np.count_nonzero(expected_row > 0.0)),
            int(np.count_nonzero(actual_row > 0.0)),
            float(np.sum(expected_row[locked_mask], dtype=np.float64)),
            float(np.sum(actual_row[locked_mask], dtype=np.float64)),
            float(np.sum(expected_row[unlocked_mask], dtype=np.float64)),
            float(np.sum(actual_row[unlocked_mask], dtype=np.float64)),
        )
    )
