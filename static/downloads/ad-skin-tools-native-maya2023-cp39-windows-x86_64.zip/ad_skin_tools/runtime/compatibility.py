"""Runtime dependency checks shared across AD Skin Tools."""

from ad_skin_tools.runtime.environment import maya_version, python_version_tuple


def ensure_numpy():
    """Return the target runtime's NumPy or raise customer-safe guidance."""

    try:
        import numpy as np
        return np
    except ImportError as exc:
        major = maya_version()
        pyver = ".".join(str(v) for v in python_version_tuple())

        raise RuntimeError(
            "The NumPy runtime required by AD Skin Tools is unavailable.\n\n"
            f"Maya version: {major}\n"
            f"Python version: {pyver}\n\n"
            "Reinstall the complete customer archive for this exact Maya, "
            "operating-system, and CPU target. Do not modify Maya with pip."
        ) from exc
