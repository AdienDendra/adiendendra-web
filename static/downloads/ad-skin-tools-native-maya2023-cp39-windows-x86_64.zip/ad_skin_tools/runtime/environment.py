"""Running Maya and Python environment information."""

import re
import sys

import maya.cmds as cmds


def maya_version() -> int:
    """Return the running Maya major version."""

    version_text = cmds.about(version=True)
    match = re.search(r"\d{4}", version_text)

    if not match:
        return 0

    return int(match.group(0))


def maya_api_version() -> int:
    """Return the running Maya API version, or zero when unavailable."""

    try:
        return int(cmds.about(apiVersion=True))
    except Exception:
        return 0


def python_version_tuple():
    """Return the running Python version as a three-item tuple."""

    return sys.version_info[:3]
