"""Platform facts used by runtime and future native loaders."""

import platform as _platform
import sys


WINDOWS = "windows"
LINUX = "linux"
MACOS = "macos"
UNKNOWN = "unknown"


def operating_system() -> str:
    """Return the canonical operating-system name for this Maya process."""

    value = sys.platform.lower()
    if value.startswith("win"):
        return WINDOWS
    if value.startswith("linux"):
        return LINUX
    if value == "darwin":
        return MACOS
    return UNKNOWN


def machine_architecture() -> str:
    """Return the normalized machine architecture, or ``unknown``."""

    return _platform.machine().strip().lower() or UNKNOWN
